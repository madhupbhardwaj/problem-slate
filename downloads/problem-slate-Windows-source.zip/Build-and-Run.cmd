@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo Install the free .NET 10 SDK for Windows from https://dotnet.microsoft.com/download/dotnet/10.0
  echo Then run this file again. Administrator access is not required to build the app.
  pause
  exit /b 1
)
dotnet publish ProblemSlate.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:DebugType=None -o dist\win-x64
if errorlevel 1 (
  echo Build failed. Copy the error above when requesting help.
  pause
  exit /b 1
)
echo Built dist\win-x64\problem-slate.exe
start "" "%~dp0dist\win-x64\problem-slate.exe"
