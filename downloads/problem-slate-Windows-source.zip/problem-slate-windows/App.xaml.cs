using System.IO;
using System.Windows;
namespace ProblemSlate;
public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        if (e.Args.Contains("--smoke-test"))
        {
            ShutdownMode = ShutdownMode.OnExplicitShutdown;
            try { var test = new MainWindow(); test.RunSmokeTests(); File.WriteAllText("smoke-test-result.txt", "PASS: grid rendering, tool defaults, theme remapping, clear/no-op undo, point erasure, document/image roundtrip, resize undo, invalid color metadata."); Shutdown(0); }
            catch (Exception ex) { File.WriteAllText("smoke-test-result.txt", ex.ToString()); Shutdown(1); }
            return;
        }
        MainWindow = new MainWindow(); MainWindow.Show();
    }
}
