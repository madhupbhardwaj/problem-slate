using System.ComponentModel;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Win32;

namespace ProblemSlate;

public sealed record Picture(byte[] Png, double X, double Y, double Width, double Height);
public sealed record Document(int Version, double Width, double Height, bool Dark, bool Grid, byte[] Ink, List<Picture> Pictures);

public partial class MainWindow : Window
{
    static readonly Guid OriginalColor = new("fb43d289-e617-4d0e-b427-39526f917c36");
    static readonly string[] ImageExtensions = { ".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff" };
    internal const double MinZoom = .1, MaxZoom = 4;
    readonly List<Document> undo = new(), redo = new();
    readonly List<Picture> pictures = new();
    readonly List<(Color Color, Ellipse Ring, Ellipse Dot)> swatches = new();
    // Each drawing tool remembers its own size, so switching tools never loses a chosen width.
    readonly Dictionary<string, double> toolSizes = new() { ["Pen"] = 4, ["Chisel"] = 12, ["Highlighter"] = 28, ["Eraser"] = 36 };
    readonly DispatcherTimer recoveryTimer = new() { Interval = TimeSpan.FromSeconds(2) };
    readonly string recoveryPath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "problem-slate", "Recovery.wslate");
    Task recoveryWork = Task.CompletedTask;
    Document? pending;
    string tool = "Pen";
    Color color = Colors.Black;
    string? filePath;
    bool ready, dirty, restoring, panning, dragging, resizing, spacePan, recovered;
    int selected = -1;
    Point start;
    double startHorizontal, startVertical;
    Picture? startPicture;
    double zoom = 1;
    Brush accent = new SolidColorBrush(Color.FromRgb(0x16, 0xc5, 0xcf));

    public MainWindow()
    {
        InitializeComponent();
        if (TryFindResource("Accent") is Brush brush) accent = brush;
        foreach (var hex in new[] { "#000000", "#8e8e93", "#0095ff", "#d32ee8", "#ff404a", "#ff952b", "#ffdb00", "#28cd53" })
        {
            var c = (Color)ColorConverter.ConvertFromString(hex);
            var ring = new Ellipse { Width = 30, Height = 30, Stroke = accent, StrokeThickness = 2, Visibility = Visibility.Hidden };
            var dot = new Ellipse { Width = 22, Height = 22, Fill = new SolidColorBrush(c), Stroke = new SolidColorBrush(Color.FromRgb(85, 85, 85)), StrokeThickness = 1 };
            var face = new Grid(); face.Children.Add(ring); face.Children.Add(dot);
            var button = new Button { Width = 40, Height = 36, Padding = new Thickness(0), Margin = new Thickness(0, 0, 4, 4), Background = Brushes.Transparent, BorderBrush = Brushes.Transparent, HorizontalContentAlignment = HorizontalAlignment.Center, Content = face, Tag = c, ToolTip = hex };
            button.Click += (_, _) => SetColor((Color)button.Tag);
            swatches.Add((c, ring, dot));
            Swatches.Children.Add(button);
        }
        ready = true;
        Ink.Strokes.StrokesChanged += (_, _) => { if (!restoring) ScheduleRecovery(); };
        PreviewKeyUp += (_, e) => { if (e.Key == Key.Space && spacePan) { FinishGesture(); spacePan = false; ConfigureInk(); e.Handled = true; } };
        recoveryTimer.Tick += (_, _) => { recoveryTimer.Stop(); QueueRecovery(); };
        if (!Environment.GetCommandLineArgs().Contains("--smoke-test") && File.Exists(recoveryPath))
        {
            try
            {
                Restore(ReadDocument(recoveryPath));
                // An empty recovered board is just a fresh board; only flag real work as unsaved.
                recovered = dirty = Ink.Strokes.Count > 0 || pictures.Count > 0;
            }
            catch (Exception ex) { Status.Text = "Recovery could not be read: " + ex.Message; }
        }
        ConfigureInk(); ApplyBackground(); UpdateTitle();
    }

    Color DisplayColor(Color source) => DarkBox.IsChecked == true && source.R == 0 && source.G == 0 && source.B == 0 ? Colors.White : source;
    static string Hex(Color value) => $"#{value.R:X2}{value.G:X2}{value.B:X2}";
    bool IsDrawingTool => tool is "Pen" or "Chisel" or "Highlighter";

    void ConfigureInk()
    {
        if (!ready) return;
        bool marker = tool == "Highlighter", chisel = tool == "Chisel";
        var tip = Matrix.Identity;
        if (chisel || marker) tip.Rotate(AngleSlider.Value);
        double size = SizeSlider.Value;
        Ink.DefaultDrawingAttributes = new DrawingAttributes {
            Color = DisplayColor(color), Width = marker ? Math.Max(18, size) : size,
            Height = marker ? Math.Max(8, size * .45) : chisel ? Math.Max(1, size * .23) : size,
            StylusTip = chisel || marker ? StylusTip.Rectangle : StylusTip.Ellipse,
            StylusTipTransform = tip, FitToCurve = true, IgnorePressure = PressureBox.IsChecked != true || marker,
            IsHighlighter = marker
        };
        Ink.EditingMode = spacePan || tool is "Pan" or "Select" ? InkCanvasEditingMode.None : tool == "Eraser" ? InkCanvasEditingMode.EraseByPoint : InkCanvasEditingMode.Ink;
        Ink.EditingModeInverted = spacePan || tool is "Pan" or "Select" ? InkCanvasEditingMode.None : InkCanvasEditingMode.EraseByPoint;
        Ink.EraserShape = new EllipseStylusShape(Math.Max(20, size), Math.Max(20, size));
        Ink.Cursor = spacePan || tool == "Pan" ? Cursors.Hand : tool == "Select" ? Cursors.Arrow : Cursors.Pen;
        foreach (Button b in Tools.Children)
        {
            bool active = (string)b.Tag == tool;
            b.Background = new SolidColorBrush(active ? Color.FromRgb(0x17, 0x3a, 0x3d) : Color.FromRgb(0x1f, 0x1f, 0x1f));
            b.BorderBrush = active ? accent : new SolidColorBrush(Color.FromRgb(0x2c, 0x2c, 0x2c));
        }
        foreach (Button b in Presets.Children)
        {
            bool active = Math.Abs(double.Parse((string)b.Tag) - size) < .5;
            b.Background = new SolidColorBrush(active ? Color.FromRgb(0x17, 0x3a, 0x3d) : Color.FromRgb(0x26, 0x26, 0x26));
            b.BorderBrush = active ? accent : new SolidColorBrush(Color.FromRgb(0x34, 0x34, 0x34));
        }
        foreach (var swatch in swatches)
        {
            swatch.Ring.Visibility = swatch.Color == color ? Visibility.Visible : Visibility.Hidden;
            swatch.Dot.Fill = new SolidColorBrush(DisplayColor(swatch.Color));
        }
        CustomSwatch.Background = new SolidColorBrush(color);
        SizeValue.Text = $"{size:0} px"; AngleValue.Text = $"{AngleSlider.Value:0}°";
        AnglePanel.Visibility = chisel || marker ? Visibility.Visible : Visibility.Collapsed;
        Hint.Text = spacePan || tool == "Pan" ? "Drag to move around the board"
            : tool == "Select" ? "Click an image to select · drag its corner to resize · arrows nudge · Delete removes"
            : tool == "Eraser" ? "Erases ink only; images stay · [ ] change size"
            : "Hold Shift for a straight line · Space + drag to pan · [ ] change size";
        UpdatePreview(); RefreshChrome();
    }
    void RefreshChrome()
    {
        UndoButton.IsEnabled = undo.Count > 0; RedoButton.IsEnabled = redo.Count > 0;
        ClearButton.IsEnabled = Ink.Strokes.Count > 0 || pictures.Count > 0;
        BoardInfo.Text = $"{Surface.Width:0} × {Surface.Height:0}";
    }
    void UpdateTitle()
    {
        string name = filePath != null ? System.IO.Path.GetFileNameWithoutExtension(filePath) : recovered ? "Recovered board" : "Untitled board";
        FileLabel.Text = name;
        DirtyDot.Visibility = dirty ? Visibility.Visible : Visibility.Collapsed;
        Title = "problem-slate · " + name + (dirty ? " *" : "");
    }
    void UpdatePreview()
    {
        bool dark = DarkBox.IsChecked == true;
        PreviewFrame.Background = dark ? Brushes.Black : Brushes.White;
        var group = new DrawingGroup();
        using (var dc = group.Open())
        {
            dc.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, 190, 56));
            if (tool == "Eraser")
            {
                double d = Math.Clamp(SizeSlider.Value, 20, 48);
                dc.DrawEllipse(null, new Pen(dark ? Brushes.White : Brushes.Black, 1.2) { DashStyle = DashStyles.Dash }, new Point(95, 28), d / 2, d / 2);
            }
            else
            {
                bool pressure = PressureBox.IsChecked == true && tool is "Pen" or "Chisel";
                var points = new StylusPointCollection();
                for (int i = 0; i <= 48; i++)
                {
                    double t = i / 48.0;
                    points.Add(new StylusPoint(24 + t * 142, 28 - Math.Sin(t * Math.PI * 2) * 9, (float)(pressure ? .25 + .75 * Math.Sin(t * Math.PI) : .5)));
                }
                var attributes = Ink.DefaultDrawingAttributes.Clone();
                double scale = Math.Min(1, 30 / Math.Max(attributes.Width, attributes.Height));
                attributes.Width *= scale; attributes.Height *= scale;
                new Stroke(points, attributes).Draw(dc);
            }
        }
        group.Freeze();
        BrushPreview.Source = new DrawingImage(group);
    }
    void ChooseTool(string name)
    {
        FinishGesture(); tool = name; selected = -1; DrawSelection();
        if (toolSizes.TryGetValue(name, out double size)) SizeSlider.Value = size;
        ConfigureInk();
    }
    void ToolClick(object sender, RoutedEventArgs e) => ChooseTool((string)((Button)sender).Tag);
    void SettingChanged(object sender, RoutedEventArgs e) => ConfigureInk();
    void SizeSliderChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!ready) return;
        if (toolSizes.ContainsKey(tool)) toolSizes[tool] = SizeSlider.Value;
        ConfigureInk();
    }
    void PresetClick(object sender, RoutedEventArgs e) => SizeSlider.Value = double.Parse((string)((Button)sender).Tag);
    internal static double StepSize(double size, int direction)
    {
        double step = size < 10 ? 1 : size < 30 ? 2 : 4;
        return Math.Clamp(Math.Round(size) + step * direction, 1, 60);
    }
    void SetColor(Color value) { color = value; color.A = 255; ColorHex.Text = Hex(color); ConfigureInk(); }
    void CustomColor(object sender, RoutedEventArgs e)
    {
        try { SetColor((Color)ColorConverter.ConvertFromString(ColorHex.Text)); }
        catch { MessageBox.Show(this, "Enter a color such as #2584FF.", "Color"); }
    }
    void ColorHexKey(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) { CustomColor(sender, e); e.Handled = true; } }
    void BackgroundChanged(object sender, RoutedEventArgs e)
    {
        if (!ready) return;
        // Click fires after the checkbox toggles: capture the previous board setting for undo.
        var before = Snapshot();
        before = ReferenceEquals(sender, DarkBox) ? before with { Dark = !before.Dark } : before with { Grid = !before.Grid };
        Remember(before); ApplyBackground(); Changed();
    }
    void ApplyBackground()
    {
        bool dark = DarkBox.IsChecked == true;
        var bg = dark ? Brushes.Black : Brushes.White;
        // The area around the board is tinted so the board edge stays visible when zoomed out.
        Viewport.Background = new SolidColorBrush(dark ? Color.FromRgb(0x17, 0x17, 0x17) : Color.FromRgb(0xdc, 0xdc, 0xd8));
        if (GridBox.IsChecked == true)
        {
            var group = new DrawingGroup();
            group.Children.Add(new GeometryDrawing(bg, null, new RectangleGeometry(new Rect(0, 0, 24, 24))));
            group.Children.Add(new GeometryDrawing(dark ? Brushes.DimGray : Brushes.Black, null, new EllipseGeometry(new Point(12.75, 12.75), .75, .75)));
            Surface.Background = new DrawingBrush(group) { TileMode = TileMode.Tile, ViewportUnits = BrushMappingMode.Absolute, Viewport = new Rect(0, 0, 24, 24), ViewboxUnits = BrushMappingMode.Absolute, Viewbox = new Rect(0, 0, 24, 24), Stretch = Stretch.Fill };
        }
        else Surface.Background = bg;
        foreach (Stroke stroke in Ink.Strokes)
            if (TryOriginalColor(stroke, out var original)) stroke.DrawingAttributes.Color = DisplayColor(original);
        ConfigureInk();
    }
    static bool TryOriginalColor(Stroke stroke, out Color original)
    {
        original = stroke.DrawingAttributes.Color;
        if (!stroke.ContainsPropertyData(OriginalColor))
        {
            stroke.AddPropertyData(OriginalColor, original.ToString());
            return true;
        }
        if (stroke.GetPropertyData(OriginalColor) is not string value) return false;
        try { original = (Color)ColorConverter.ConvertFromString(value); return true; }
        catch { return false; }
    }
    /// <summary>Replaces a freehand stroke with an evenly sampled straight segment between its ends.</summary>
    internal static StylusPointCollection Straighten(StylusPointCollection points)
    {
        var result = new StylusPointCollection(points.Description);
        if (points.Count < 2) { result.Add(points); return result; }
        StylusPoint a = points[0], b = points[points.Count - 1];
        float pressure = (float)points.Average(p => p.PressureFactor);
        double length = Math.Sqrt((b.X - a.X) * (b.X - a.X) + (b.Y - a.Y) * (b.Y - a.Y));
        int steps = Math.Max(1, (int)Math.Ceiling(length / 6));
        for (int i = 0; i <= steps; i++)
        {
            double t = (double)i / steps;
            var p = a; p.X = a.X + (b.X - a.X) * t; p.Y = a.Y + (b.Y - a.Y) * t; p.PressureFactor = pressure;
            result.Add(p);
        }
        return result;
    }
    void StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
    {
        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift) && e.Stroke.StylusPoints.Count > 1) e.Stroke.StylusPoints = Straighten(e.Stroke.StylusPoints);
        e.Stroke.AddPropertyData(OriginalColor, color.ToString());
        Changed();
    }
    void BeginGesture() { if (pending == null && !restoring) pending = Snapshot(); }
    void PenDown(object sender, StylusDownEventArgs e)
    {
        BeginGesture();
        Status.Text = "Pen tablet detected · " + (PressureBox.IsChecked == true ? "pressure enabled" : "fixed width");
        StatusDot.Fill = new SolidColorBrush(Color.FromRgb(0x28, 0xcd, 0x53));
    }
    void PenUp(object sender, StylusEventArgs e) => Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(FinishGesture));
    void PointerDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left && e.ChangedButton != MouseButton.Middle) return;
        if (e.StylusDevice == null) { Status.Text = "Mouse · tablet ready"; StatusDot.Fill = new SolidColorBrush(Color.FromRgb(0x5c, 0x5c, 0x5c)); }
        if (tool == "Pan" || spacePan || e.ChangedButton == MouseButton.Middle)
        {
            panning = true; start = e.GetPosition(Viewport); startHorizontal = Viewport.HorizontalOffset; startVertical = Viewport.VerticalOffset;
            Ink.CaptureMouse(); e.Handled = true; return;
        }
        BeginGesture();
        if (tool != "Select") return;
        start = e.GetPosition(Surface);
        resizing = selected >= 0 && HandleRect(pictures[selected]).Contains(start);
        if (!resizing) selected = pictures.FindLastIndex(p => new Rect(p.X, p.Y, p.Width, p.Height).Contains(start));
        if (selected >= 0) { startPicture = pictures[selected]; dragging = true; Ink.CaptureMouse(); }
        DrawSelection(); e.Handled = true;
    }
    void PointerMove(object sender, MouseEventArgs e)
    {
        if (panning)
        {
            var p = e.GetPosition(Viewport); Viewport.ScrollToHorizontalOffset(startHorizontal - p.X + start.X); Viewport.ScrollToVerticalOffset(startVertical - p.Y + start.Y); e.Handled = true;
        }
        if (!dragging || selected < 0 || startPicture is not Picture original) return;
        var position = e.GetPosition(Surface); var delta = position - start;
        if (resizing)
        {
            double maxWidth = Math.Max(1, Math.Min(Surface.Width - original.X, (Surface.Height - original.Y) * original.Width / original.Height));
            double w = Math.Clamp(original.Width + delta.X, Math.Min(20, maxWidth), maxWidth);
            pictures[selected] = original with { Width = w, Height = w * original.Height / original.Width };
        }
        else pictures[selected] = original with { X = Math.Clamp(original.X + delta.X, 0, Math.Max(0, Surface.Width - original.Width)), Y = Math.Clamp(original.Y + delta.Y, 0, Math.Max(0, Surface.Height - original.Height)) };
        UpdateImageView(selected);
        DrawSelection(); e.Handled = true;
    }
    void UpdateImageView(int index)
    {
        // Reuse the decoded bitmap; only update layout.
        var image = (Image)Images.Children[index]; var current = pictures[index];
        Canvas.SetLeft(image, current.X); Canvas.SetTop(image, current.Y); image.Width = current.Width; image.Height = current.Height;
    }
    void PointerUp(object sender, MouseButtonEventArgs e) => Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(FinishGesture));
    void CaptureLost(object sender, InputEventArgs e) => Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(FinishGesture));
    void FinishGesture()
    {
        dragging = panning = resizing = false; startPicture = null;
        if (Ink.IsMouseCaptured) Ink.ReleaseMouseCapture();
        if (pending is Document before)
        {
            pending = null;
            var after = Snapshot();
            if (!Same(before, after)) { Remember(before); Changed(); }
        }
    }
    void OnDeactivated(object? sender, EventArgs e)
    {
        // Ending edit mode discards any unfinished dynamic stroke and resets input after focus changes.
        Ink.EditingMode = InkCanvasEditingMode.None;
        Ink.ReleaseStylusCapture(); FinishGesture(); spacePan = false; ConfigureInk();
    }
    static bool Same(Document a, Document b) => a.Width == b.Width && a.Height == b.Height && a.Dark == b.Dark && a.Grid == b.Grid && a.Ink.AsSpan().SequenceEqual(b.Ink) && a.Pictures.SequenceEqual(b.Pictures);
    Document Snapshot()
    {
        using var stream = new MemoryStream(); Ink.Strokes.Save(stream);
        return new(1, Surface.Width, Surface.Height, DarkBox.IsChecked == true, GridBox.IsChecked == true, stream.ToArray(), new(pictures));
    }
    void Remember(Document d)
    {
        undo.Add(d); redo.Clear();
        // Bound history; image bytes are immutable and shared by snapshots.
        long bytes = 0;
        for (int i = undo.Count - 1; i >= 0; i--) { bytes += undo[i].Ink.Length + undo[i].Pictures.Sum(p => (long)p.Png.Length); if (bytes > 128L * 1024 * 1024 || undo.Count - i > 60) { undo.RemoveRange(0, i + 1); break; } }
    }
    void Restore(Document d)
    {
        restoring = true;
        try
        {
            // Decode everything before touching the current board.
            var strokes = new StrokeCollection(new MemoryStream(d.Ink));
            var decoded = d.Pictures.Select(p => Decode(p.Png)).ToArray();
            Ink.Strokes.Clear(); Ink.Strokes.Add(strokes);
            Surface.Width = d.Width; Surface.Height = d.Height;
            BoardWidth.Text = d.Width.ToString("0"); BoardHeight.Text = d.Height.ToString("0");
            DarkBox.IsChecked = d.Dark; GridBox.IsChecked = d.Grid;
            pictures.Clear(); pictures.AddRange(d.Pictures); Images.Children.Clear();
            for (int i = 0; i < pictures.Count; i++) AddImageView(pictures[i], decoded[i]);
            selected = -1; DrawSelection(); ApplyBackground();
        }
        finally { restoring = false; }
    }
    void UndoClick(object sender, RoutedEventArgs e) { FinishGesture(); if (undo.Count == 0) return; redo.Add(Snapshot()); var d = undo[^1]; undo.RemoveAt(undo.Count - 1); Restore(d); Changed(); }
    void RedoClick(object sender, RoutedEventArgs e) { FinishGesture(); if (redo.Count == 0) return; undo.Add(Snapshot()); var d = redo[^1]; redo.RemoveAt(redo.Count - 1); Restore(d); Changed(); }
    void Changed() { dirty = true; UpdateTitle(); RefreshChrome(); ScheduleRecovery(); }
    void ScheduleRecovery() { if (!ready || restoring) return; RefreshChrome(); recoveryTimer.Stop(); recoveryTimer.Start(); }
    void QueueRecovery()
    {
        var snapshot = Snapshot();
        recoveryWork = recoveryWork.ContinueWith(_ => { try { WriteDocument(recoveryPath, snapshot); } catch { /* surfaced at final flush */ } }, TaskScheduler.Default);
    }
    static void WriteDocument(string path, Document document)
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(path))!);
        string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try { using (var stream = File.Create(temp)) JsonSerializer.Serialize(stream, document); File.Move(temp, path, true); }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }
    static Document ReadDocument(string path)
    {
        if (new FileInfo(path).Length > 160L * 1024 * 1024) throw new InvalidDataException("Board exceeds 160 MB.");
        using var stream = File.OpenRead(path);
        var d = JsonSerializer.Deserialize<Document>(stream) ?? throw new InvalidDataException("Empty board.");
        if (d.Version != 1 || !double.IsFinite(d.Width) || !double.IsFinite(d.Height) || d.Width < 512 || d.Width > 8192 || d.Height < 512 || d.Height > 8192 || d.Ink == null || d.Pictures == null || d.Pictures.Count > 100) throw new InvalidDataException("Unsupported or invalid Windows board.");
        long total = 0;
        foreach (var p in d.Pictures)
        {
            if (p == null || p.Png == null || p.Png.Length > 25 * 1024 * 1024 || !double.IsFinite(p.X) || !double.IsFinite(p.Y) || !double.IsFinite(p.Width) || !double.IsFinite(p.Height) || p.Width <= 0 || p.Height <= 0 || p.Width > 8192 || p.Height > 8192) throw new InvalidDataException("Invalid image.");
            total += p.Png.Length;
        }
        if (total > 100L * 1024 * 1024) throw new InvalidDataException("Images exceed 100 MB.");
        return d;
    }
    bool Save(bool saveAs = false)
    {
        FinishGesture(); string? target = filePath;
        if (target == null || saveAs)
        {
            var dialog = new SaveFileDialog { Filter = "Windows slate board (*.wslate)|*.wslate", DefaultExt = ".wslate", FileName = target == null ? "Untitled.wslate" : System.IO.Path.GetFileName(target) };
            if (dialog.ShowDialog(this) != true) return false; target = dialog.FileName;
        }
        try { WriteDocument(target, Snapshot()); filePath = target; dirty = false; recovered = false; UpdateTitle(); Status.Text = "Board saved"; return true; }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not save"); return false; }
    }
    bool CanReplace()
    {
        FinishGesture(); if (!dirty) return true;
        var answer = MessageBox.Show(this, "Save this board before continuing?\n\nYes saves it, No discards the changes.", "Unsaved board", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
        return answer == MessageBoxResult.No || answer == MessageBoxResult.Yes && Save();
    }
    void SaveClick(object sender, RoutedEventArgs e) => Save();
    void SaveAsClick(object sender, RoutedEventArgs e) => Save(true);
    void OpenClick(object sender, RoutedEventArgs e)
    {
        if (!CanReplace()) return;
        var dialog = new OpenFileDialog { Filter = "Windows slate board (*.wslate)|*.wslate" }; if (dialog.ShowDialog(this) != true) return;
        try { Restore(ReadDocument(dialog.FileName)); undo.Clear(); redo.Clear(); filePath = dialog.FileName; dirty = recovered = false; UpdateTitle(); ScheduleRecovery(); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not open board"); }
    }
    void NewClick(object sender, RoutedEventArgs e)
    {
        if (!CanReplace()) return;
        Ink.Strokes.Clear(); pictures.Clear(); Images.Children.Clear(); selected = -1; DrawSelection();
        Surface.Width = Surface.Height = 4096; BoardWidth.Text = BoardHeight.Text = "4096";
        filePath = null; undo.Clear(); redo.Clear(); SetZoom(1);
        DarkBox.IsChecked = false; GridBox.IsChecked = true; ApplyBackground();
        dirty = recovered = false; UpdateTitle(); ScheduleRecovery();
        Viewport.ScrollToHome();
    }
    void ClearClick(object sender, RoutedEventArgs e)
    {
        FinishGesture();
        if (Ink.Strokes.Count == 0 && pictures.Count == 0) return;
        Remember(Snapshot()); Ink.Strokes.Clear(); pictures.Clear(); Images.Children.Clear(); selected = -1; DrawSelection(); Changed();
    }
    void ResizeBoard(object sender, RoutedEventArgs e)
    {
        if (!int.TryParse(BoardWidth.Text, out int w) || !int.TryParse(BoardHeight.Text, out int h) || w < 512 || h < 512 || w > 8192 || h > 8192) { MessageBox.Show(this, "Width and height must be between 512 and 8192 pixels.", "Board size"); return; }
        FinishGesture();
        if (Surface.Width == w && Surface.Height == h) { BoardWidth.Text = w.ToString(); BoardHeight.Text = h.ToString(); return; }
        Remember(Snapshot()); Surface.Width = w; Surface.Height = h; BoardWidth.Text = w.ToString(); BoardHeight.Text = h.ToString(); Changed();
    }
    static BitmapSource Decode(byte[] png)
    {
        using var stream = new MemoryStream(png);
        var decoder = BitmapDecoder.Create(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnDemand);
        var frame = decoder.Frames[0];
        if ((long)frame.PixelWidth * frame.PixelHeight > 32_000_000) throw new InvalidDataException("Image exceeds 32 megapixels.");
        var bitmap = new WriteableBitmap(frame);
        bitmap.Freeze(); return bitmap;
    }
    static bool IsImageFile(string? path) => path != null && ImageExtensions.Contains(System.IO.Path.GetExtension(path).ToLowerInvariant());
    static BitmapSource LoadImageFile(string path)
    {
        if (new FileInfo(path).Length > 25L * 1024 * 1024) throw new InvalidDataException("Image exceeds 25 MB.");
        return Decode(File.ReadAllBytes(path));
    }
    void AddImageView(Picture p, BitmapSource bitmap)
    {
        var image = new Image { Source = bitmap, Width = p.Width, Height = p.Height, Stretch = Stretch.Fill };
        RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.HighQuality);
        Canvas.SetLeft(image, p.X); Canvas.SetTop(image, p.Y); Images.Children.Add(image);
    }
    Point VisibleCenter() => Viewport.TranslatePoint(new Point(Viewport.ViewportWidth / 2, Viewport.ViewportHeight / 2), Surface);
    /// <summary>Adds an image centered on <paramref name="center"/> (board coordinates) or on the visible area.</summary>
    void AddPicture(BitmapSource bitmap, Point? center)
    {
        if ((long)bitmap.PixelWidth * bitmap.PixelHeight > 32_000_000) throw new InvalidDataException("Image exceeds 32 megapixels.");
        var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap)); using var stream = new MemoryStream(); encoder.Save(stream); byte[] png = stream.ToArray();
        if (png.Length > 25L * 1024 * 1024 || pictures.Count >= 100 || pictures.Sum(p => (long)p.Png.Length) + png.Length > 100L * 1024 * 1024) throw new InvalidDataException("Image limit: 25 MB each, 100 images and 100 MB total.");
        double scale = Math.Min(1, Math.Min(Math.Min(800, Surface.Width) / bitmap.PixelWidth, Math.Min(800, Surface.Height) / bitmap.PixelHeight));
        double w = bitmap.PixelWidth * scale, h = bitmap.PixelHeight * scale;
        var c = center ?? VisibleCenter();
        double x = Math.Clamp(c.X - w / 2, 0, Math.Max(0, Surface.Width - w));
        double y = Math.Clamp(c.Y - h / 2, 0, Math.Max(0, Surface.Height - h));
        FinishGesture(); Remember(Snapshot()); var picture = new Picture(png, x, y, w, h); pictures.Add(picture); AddImageView(picture, bitmap);
        tool = "Select"; ConfigureInk(); selected = pictures.Count - 1; DrawSelection(); Changed(); Status.Text = "Image added · drag to move, corner to resize";
    }
    void Paste()
    {
        try
        {
            // File-drop data comes first; never paste Explorer's generic file icon.
            if (Clipboard.ContainsFileDropList())
            {
                var path = Clipboard.GetFileDropList().Cast<string?>().FirstOrDefault(IsImageFile);
                if (path == null) { Status.Text = "Copy an image or image file first."; return; }
                AddPicture(LoadImageFile(path), null); return;
            }
            if (Clipboard.ContainsImage() && Clipboard.GetImage() is BitmapSource bitmap) { AddPicture(bitmap, null); return; }
            Status.Text = "Copy an image or image file first.";
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not paste image"); }
    }
    static string[] DroppedImages(IDataObject data) =>
        data.GetDataPresent(DataFormats.FileDrop) && data.GetData(DataFormats.FileDrop) is string[] files ? files.Where(IsImageFile).ToArray() : Array.Empty<string>();
    void OnDragOver(object sender, DragEventArgs e)
    {
        e.Effects = DroppedImages(e.Data).Length > 0 ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }
    void OnDrop(object sender, DragEventArgs e)
    {
        var files = DroppedImages(e.Data); if (files.Length == 0) return;
        e.Handled = true; var point = e.GetPosition(Surface);
        try
        {
            for (int i = 0; i < files.Length; i++) AddPicture(LoadImageFile(files[i]), new Point(point.X + i * 32, point.Y + i * 32));
            Activate();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not add image"); }
    }
    Rect HandleRect(Picture p) => new(p.X + p.Width - 8 / zoom, p.Y + p.Height - 8 / zoom, 16 / zoom, 16 / zoom);
    void DrawSelection()
    {
        Selection.Children.Clear(); if (selected < 0 || selected >= pictures.Count) return;
        var p = pictures[selected];
        var border = new Rectangle { Width = p.Width, Height = p.Height, Stroke = accent, StrokeThickness = 1.5 / zoom, StrokeDashArray = new DoubleCollection { 4, 3 } };
        Canvas.SetLeft(border, p.X); Canvas.SetTop(border, p.Y); Selection.Children.Add(border);
        var r = HandleRect(p); var handle = new Rectangle { Width = r.Width, Height = r.Height, Fill = Brushes.White, Stroke = accent, StrokeThickness = 1.5 / zoom, RadiusX = 3 / zoom, RadiusY = 3 / zoom };
        Canvas.SetLeft(handle, r.X); Canvas.SetTop(handle, r.Y); Selection.Children.Add(handle);
    }
    void DeleteSelection()
    {
        if (selected < 0) return; Remember(Snapshot()); pictures.RemoveAt(selected); Images.Children.RemoveAt(selected); selected = -1; DrawSelection(); Changed();
    }
    void Nudge(double dx, double dy)
    {
        if (selected < 0 || selected >= pictures.Count) return;
        FinishGesture(); var p = pictures[selected];
        var moved = p with { X = Math.Clamp(p.X + dx, 0, Math.Max(0, Surface.Width - p.Width)), Y = Math.Clamp(p.Y + dy, 0, Math.Max(0, Surface.Height - p.Height)) };
        if (moved == p) return;
        Remember(Snapshot()); pictures[selected] = moved; UpdateImageView(selected); DrawSelection(); Changed();
    }
    /// <summary>Zooms while keeping the board point under <paramref name="anchor"/> (viewport coordinates) fixed.</summary>
    void SetZoom(double value, Point? anchor = null)
    {
        FinishGesture();
        var a = anchor ?? new Point(Viewport.ViewportWidth / 2, Viewport.ViewportHeight / 2);
        var boardPoint = Viewport.TranslatePoint(a, Surface);
        zoom = Math.Clamp(value, MinZoom, MaxZoom);
        ZoomTransform.ScaleX = ZoomTransform.ScaleY = zoom; Viewport.UpdateLayout();
        var landed = Surface.TranslatePoint(boardPoint, Viewport);
        Viewport.ScrollToHorizontalOffset(Viewport.HorizontalOffset + landed.X - a.X); Viewport.ScrollToVerticalOffset(Viewport.VerticalOffset + landed.Y - a.Y);
        ZoomLabel.Content = $"{Math.Round(zoom * 100)}%"; DrawSelection();
    }
    void ZoomIn(object sender, RoutedEventArgs e) => SetZoom(zoom * 1.25);
    void ZoomOut(object sender, RoutedEventArgs e) => SetZoom(zoom / 1.25);
    void ZoomReset(object sender, RoutedEventArgs e) => SetZoom(1);
    void ZoomFit(object sender, RoutedEventArgs e)
    {
        if (Viewport.ViewportWidth <= 0 || Viewport.ViewportHeight <= 0) return;
        SetZoom(Math.Min(Viewport.ViewportWidth / Surface.Width, Viewport.ViewportHeight / Surface.Height) * .96);
        Viewport.ScrollToHome();
    }
    void OnWheel(object sender, MouseWheelEventArgs e)
    {
        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) SetZoom(zoom * (e.Delta > 0 ? 1.1 : 1 / 1.1), e.GetPosition(Viewport));
        else if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) Viewport.ScrollToHorizontalOffset(Viewport.HorizontalOffset - e.Delta);
        else Viewport.ScrollToVerticalOffset(Viewport.VerticalOffset - e.Delta);
        e.Handled = true;
    }
    BitmapSource RenderBoard()
    {
        var visual = new DrawingVisual(); using (var dc = visual.RenderOpen())
        {
            dc.PushClip(new RectangleGeometry(new Rect(0, 0, Surface.Width, Surface.Height)));
            dc.DrawRectangle(Surface.Background, null, new Rect(0, 0, Surface.Width, Surface.Height));
            for (int i = 0; i < pictures.Count; i++) { var p = pictures[i]; dc.DrawImage(((Image)Images.Children[i]).Source, new Rect(p.X, p.Y, p.Width, p.Height)); }
            Ink.Strokes.Draw(dc); dc.Pop();
        }
        var bitmap = new RenderTargetBitmap((int)Surface.Width, (int)Surface.Height, 96, 96, PixelFormats.Pbgra32); bitmap.Render(visual);
        bitmap.Freeze(); return bitmap;
    }
    void ExportClick(object sender, RoutedEventArgs e)
    {
        FinishGesture();
        string name = filePath != null ? System.IO.Path.GetFileNameWithoutExtension(filePath) : "Board";
        var dialog = new SaveFileDialog { Filter = "PNG image|*.png", FileName = name + ".png" }; if (dialog.ShowDialog(this) != true) return;
        try
        {
            var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(RenderBoard())); using var stream = File.Create(dialog.FileName); encoder.Save(stream); Status.Text = "PNG exported";
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not export"); }
    }
    void CopyImageClick(object sender, RoutedEventArgs e)
    {
        FinishGesture();
        try { Clipboard.SetImage(RenderBoard()); Status.Text = "Board copied as an image · paste it into any app"; }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not copy board"); }
    }
    void OnKey(object sender, KeyEventArgs e)
    {
        if (Keyboard.FocusedElement is TextBox) return;
        bool ctrl = Keyboard.Modifiers.HasFlag(ModifierKeys.Control), shift = Keyboard.Modifiers.HasFlag(ModifierKeys.Shift);
        if (ctrl)
        {
            switch (e.Key)
            {
                case Key.Z: if (shift) RedoClick(this, e); else UndoClick(this, e); break;
                case Key.Y: RedoClick(this, e); break;
                case Key.S: Save(shift); break;
                case Key.O: OpenClick(this, e); break;
                case Key.N: NewClick(this, e); break;
                case Key.V: Paste(); break;
                case Key.C when shift: CopyImageClick(this, e); break;
                case Key.E when shift: ExportClick(this, e); break;
                case Key.K when shift: ClearClick(this, e); break;
                case Key.OemPlus: case Key.Add: ZoomIn(this, e); break;
                case Key.OemMinus: case Key.Subtract: ZoomOut(this, e); break;
                case Key.D0: case Key.NumPad0: ZoomReset(this, e); break;
                case Key.D9: case Key.NumPad9: ZoomFit(this, e); break;
                default: return;
            }
        }
        else
        {
            double step = shift ? 10 : 1;
            switch (e.Key)
            {
                case Key.Space: if (!spacePan) { FinishGesture(); spacePan = true; ConfigureInk(); } break;
                case Key.Delete: case Key.Back: DeleteSelection(); break;
                case Key.Escape: selected = -1; DrawSelection(); break;
                case Key.Left when selected >= 0: Nudge(-step, 0); break;
                case Key.Right when selected >= 0: Nudge(step, 0); break;
                case Key.Up when selected >= 0: Nudge(0, -step); break;
                case Key.Down when selected >= 0: Nudge(0, step); break;
                case Key.OemOpenBrackets: SizeSlider.Value = StepSize(SizeSlider.Value, -1); break;
                case Key.OemCloseBrackets: SizeSlider.Value = StepSize(SizeSlider.Value, 1); break;
                case Key.P: ChooseTool("Pen"); break;
                case Key.C: ChooseTool("Chisel"); break;
                case Key.H: ChooseTool("Highlighter"); break;
                case Key.E: ChooseTool("Eraser"); break;
                case Key.V: ChooseTool("Select"); break;
                case Key.M: ChooseTool("Pan"); break;
                default: return;
            }
        }
        e.Handled = true;
    }
    void OnClosing(object? sender, CancelEventArgs e)
    {
        if (!CanReplace()) { e.Cancel = true; return; }
        recoveryTimer.Stop(); recoveryWork.GetAwaiter().GetResult();
        try { WriteDocument(recoveryPath, Snapshot()); }
        catch (Exception ex) { MessageBox.Show(this, "Recovery could not be saved: " + ex.Message); }
    }
    internal void RunSmokeTests()
    {
        void Check(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        DarkBox.IsChecked = false; GridBox.IsChecked = true; ApplyBackground();
        var gridVisual = new DrawingVisual();
        using (var dc = gridVisual.RenderOpen()) dc.DrawRectangle(Surface.Background, null, new Rect(0, 0, 48, 48));
        var gridPixels = new RenderTargetBitmap(48, 48, 96, 96, PixelFormats.Pbgra32); gridPixels.Render(gridVisual);
        var pixel = new byte[4]; gridPixels.CopyPixels(new Int32Rect(12, 12, 1, 1), pixel, 4, 0);
        Check(pixel[0] < 230 && pixel[3] == 255, "White board must render a visible dark dot.");
        gridPixels.CopyPixels(new Int32Rect(5, 5, 1, 1), pixel, 4, 0);
        Check(pixel[0] == 255, "Space between dots must remain white.");
        ChooseTool("Chisel"); Check(SizeSlider.Value == 12, "Chisel default size differs from Mac.");
        ChooseTool("Pen"); Check(SizeSlider.Value == 4, "Pen default size differs from Mac.");
        SizeSlider.Value = 9; ChooseTool("Highlighter"); Check(SizeSlider.Value == 28, "Highlighter default size differs from Mac.");
        ChooseTool("Pen"); Check(SizeSlider.Value == 9, "Pen did not remember its size.");
        Check(StepSize(9, 1) == 10 && StepSize(10, 1) == 12 && StepSize(30, 1) == 34 && StepSize(1, -1) == 1 && StepSize(60, 1) == 60, "Size steps are wrong.");
        SizeSlider.Value = 4;
        var wobbly = new StylusPointCollection(new[] { new StylusPoint(10, 10, .2f), new StylusPoint(40, 70, .6f), new StylusPoint(110, 10, .4f) });
        var line = Straighten(wobbly);
        Check(line[0].X == 10 && line[0].Y == 10 && line[line.Count - 1].X == 110 && line.All(p => Math.Abs(p.Y - 10) < 1e-9), "Straight line must join the stroke ends.");
        Check(line.All(p => Math.Abs(p.PressureFactor - .4f) < 1e-4), "Straight line must use even pressure.");
        Ink.Strokes.Clear(); pictures.Clear();
        var black = new Stroke(new StylusPointCollection(new[] { new StylusPoint(50, 50, .2f), new StylusPoint(100, 100, .8f), new StylusPoint(150, 150, .5f) }));
        black.AddPropertyData(OriginalColor, Colors.Black.ToString()); Ink.Strokes.Add(black);
        var red = black.Clone(); red.RemovePropertyData(OriginalColor); red.AddPropertyData(OriginalColor, Colors.Red.ToString()); red.DrawingAttributes.Color = Colors.Red; Ink.Strokes.Add(red);
        DarkBox.IsChecked = true; ApplyBackground();
        Check(black.DrawingAttributes.Color == Colors.White && red.DrawingAttributes.Color == Colors.Red, "Dark background must remap only black.");
        DarkBox.IsChecked = false; ApplyBackground();
        Check(black.DrawingAttributes.Color == Colors.Black, "Original black must return.");
        ClearClick(this, new RoutedEventArgs()); Check(Ink.Strokes.Count == 0 && !ClearButton.IsEnabled, "Clear failed.");
        UndoClick(this, new RoutedEventArgs()); Check(Ink.Strokes.Count == 2, "Clear undo failed.");
        RedoClick(this, new RoutedEventArgs()); Check(Ink.Strokes.Count == 0, "Clear redo failed.");
        int historyAfterClear = undo.Count; ClearClick(this, new RoutedEventArgs()); Check(undo.Count == historyAfterClear, "Clearing an empty board added an undo step.");
        UndoClick(this, new RoutedEventArgs());
        var original = Snapshot();
        Ink.Strokes.Erase(new[] { new Point(100, 80), new Point(100, 120) }, new EllipseStylusShape(25, 25));
        Check(!original.Ink.AsSpan().SequenceEqual(Snapshot().Ink), "Point erase did not change ink.");
        Restore(original);
        var pixels = BitmapSource.Create(1, 1, 96, 96, PixelFormats.Bgra32, null, new byte[] { 0, 0, 255, 255 }, 4);
        var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(pixels));
        using var imageBytes = new MemoryStream(); encoder.Save(imageBytes);
        var picture = new Picture(imageBytes.ToArray(), 20, 30, 100, 100); pictures.Add(picture); AddImageView(picture, pixels);
        string temp = System.IO.Path.Combine(System.IO.Path.GetTempPath(), Guid.NewGuid() + ".wslate");
        try
        {
            WriteDocument(temp, Snapshot()); var loaded = ReadDocument(temp); Restore(loaded);
            Check(Ink.Strokes.Count == 2 && pictures.Count == 1 && Surface.Width == 4096, "Document roundtrip failed.");
            Check(pictures[0].Png.AsSpan().SequenceEqual(picture.Png), "Embedded image changed.");
            selected = 0; int historyBeforeNudge = undo.Count;
            Nudge(-10, 5); Check(pictures[0].X == 10 && pictures[0].Y == 35 && undo.Count == historyBeforeNudge + 1, "Nudge failed.");
            Nudge(-50, 0); Check(pictures[0].X == 0, "Nudge must keep images on the board.");
            UndoClick(this, new RoutedEventArgs()); UndoClick(this, new RoutedEventArgs()); Check(pictures[0].X == 20 && pictures[0].Y == 30, "Nudge undo failed.");
            var rendered = RenderBoard(); Check(rendered.PixelWidth == 4096 && rendered.PixelHeight == 4096, "Rendered board has the wrong size.");
            DarkBox.IsChecked = true; ApplyBackground(); Check(Ink.Strokes[0].DrawingAttributes.Color == Colors.White, "Original color metadata did not roundtrip.");
            BoardWidth.Text = "2048"; BoardHeight.Text = "3072"; ResizeBoard(this, new RoutedEventArgs());
            Check(Surface.Width == 2048 && Surface.Height == 3072, "Resize failed."); UndoClick(this, new RoutedEventArgs());
            Check(Surface.Width == 4096 && Surface.Height == 4096, "Resize undo failed.");
            var malformed = black.Clone(); malformed.RemovePropertyData(OriginalColor); malformed.AddPropertyData(OriginalColor, "not-a-color"); Ink.Strokes.Add(malformed);
            DarkBox.IsChecked = true; ApplyBackground(); Check(malformed.DrawingAttributes.Color == Colors.Black, "Malformed color metadata should be ignored safely."); Ink.Strokes.Remove(malformed);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); recoveryTimer.Stop(); }
    }

}
