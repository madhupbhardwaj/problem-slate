using System.ComponentModel;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Win32;

namespace ProblemSlate;

public sealed record Picture(byte[] Png, double X, double Y, double Width, double Height);
public sealed record Document(int Version, double Width, double Height, bool Dark, bool Grid, byte[] Ink, List<Picture> Pictures);

public partial class MainWindow : Window
{
    static readonly Guid OriginalColor = new("fb43d289-e617-4d0e-b427-39526f917c36");
    readonly List<Document> undo = new(), redo = new();
    readonly List<Picture> pictures = new();
    readonly DispatcherTimer recoveryTimer = new() { Interval = TimeSpan.FromSeconds(2) };
    readonly string recoveryPath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "problem-slate", "Recovery.wslate");
    Task recoveryWork = Task.CompletedTask;
    Document? pending;
    string tool = "Pen";
    Color color = Colors.Black;
    string? filePath;
    bool ready, dirty, restoring, panning, dragging, resizing, spacePan;
    int selected = -1;
    Point start;
    double startHorizontal, startVertical;
    Picture? startPicture;
    double zoom = 1;

    public MainWindow()
    {
        InitializeComponent();
        foreach (var hex in new[] { "#000000", "#0095ff", "#d32ee8", "#ff404a", "#ff952b", "#ffdb00", "#28cd53" })
        {
            var c = (Color)ColorConverter.ConvertFromString(hex);
            var button = new Button { Width = 28, Height = 30, Padding = new Thickness(0), Background = Brushes.Transparent, Content = new Ellipse { Width = 23, Height = 23, Fill = new SolidColorBrush(c), Stroke = Brushes.Gray, StrokeThickness = 1 }, Tag = c, ToolTip = hex };
            button.Click += (_, _) => { color = (Color)button.Tag; ColorHex.Text = Hex(color); ConfigureInk(); };
            Swatches.Children.Add(button);
        }
        ready = true;
        Ink.Strokes.StrokesChanged += (_, _) => { if (!restoring) ScheduleRecovery(); };
        PreviewKeyUp += (_, e) => { if (e.Key == Key.Space && spacePan) { FinishGesture(); spacePan = false; ConfigureInk(); e.Handled = true; } };
        recoveryTimer.Tick += (_, _) => { recoveryTimer.Stop(); QueueRecovery(); };
        if (!Environment.GetCommandLineArgs().Contains("--smoke-test") && File.Exists(recoveryPath))
        {
            try { Restore(ReadDocument(recoveryPath)); dirty = true; Title = "problem-slate · Recovered board *"; }
            catch (Exception ex) { Status.Text = "Recovery could not be read: " + ex.Message; }
        }
        ConfigureInk(); ApplyBackground();
    }

    Color DisplayColor(Color source) => DarkBox.IsChecked == true && source.R == 0 && source.G == 0 && source.B == 0 ? Colors.White : source;
    static string Hex(Color value) => $"#{value.R:X2}{value.G:X2}{value.B:X2}";
    void ConfigureInk()
    {
        if (!ready) return;
        bool marker = tool == "Highlighter", chisel = tool == "Chisel";
        var tip = Matrix.Identity;
        if (chisel || marker) tip.Rotate(AngleSlider.Value);
        double size = SizeSlider.Value;
        Ink.DefaultDrawingAttributes = new DrawingAttributes {
            Color = DisplayColor(color), Width = marker ? Math.Max(18, size) : size,
            Height = marker ? Math.Max(8, size * .45) : chisel ? Math.Max(1, size * .23) : size,
            StylusTip = chisel || marker ? StylusTip.Rectangle : StylusTip.Ellipse,
            StylusTipTransform = tip, FitToCurve = true, IgnorePressure = PressureBox.IsChecked != true || marker,
            IsHighlighter = marker
        };
        Ink.EditingMode = spacePan || tool is "Pan" or "Select" ? InkCanvasEditingMode.None : tool == "Eraser" ? InkCanvasEditingMode.EraseByPoint : InkCanvasEditingMode.Ink;
        Ink.EditingModeInverted = spacePan || tool is "Pan" or "Select" ? InkCanvasEditingMode.None : InkCanvasEditingMode.EraseByPoint;
        Ink.EraserShape = new EllipseStylusShape(Math.Max(20, size), Math.Max(20, size));
        Ink.Cursor = spacePan || tool == "Pan" ? Cursors.Hand : tool == "Select" ? Cursors.Arrow : Cursors.Pen;
        foreach (Button b in Tools.Children) b.Background = new SolidColorBrush((string)b.Tag == tool ? Color.FromRgb(24, 91, 98) : Color.FromRgb(41, 41, 41));
        SizeLabel.Text = $"Size · {size:0} px"; AngleLabel.Text = $"Nib angle · {AngleSlider.Value:0}°";
        AngleLabel.Visibility = AngleSlider.Visibility = chisel || marker ? Visibility.Visible : Visibility.Collapsed;
        UndoButton.IsEnabled = undo.Count > 0; RedoButton.IsEnabled = redo.Count > 0;
        ClearButton.IsEnabled = Ink.Strokes.Count > 0 || pictures.Count > 0;
    }
    void ChooseTool(string name) { FinishGesture(); tool = name; selected = -1; DrawSelection(); SizeSlider.Value = name switch { "Pen" => 4, "Chisel" => 12, "Highlighter" => 28, "Eraser" => 36, _ => SizeSlider.Value }; ConfigureInk(); }
    void ToolClick(object sender, RoutedEventArgs e) => ChooseTool((string)((Button)sender).Tag);
    void SettingChanged(object sender, RoutedEventArgs e) => ConfigureInk();
    void CustomColor(object sender, RoutedEventArgs e)
    {
        try { color = (Color)ColorConverter.ConvertFromString(ColorHex.Text); color.A = 255; ColorHex.Text = Hex(color); ConfigureInk(); }
        catch { MessageBox.Show(this, "Enter a color such as #2584FF.", "Color"); }
    }
    void BackgroundChanged(object sender, RoutedEventArgs e)
    {
        if (!ready) return;
        // Click fires after the checkbox toggles: capture the previous board setting for undo.
        var before = Snapshot();
        before = ReferenceEquals(sender, DarkBox) ? before with { Dark = !before.Dark } : before with { Grid = !before.Grid };
        Remember(before); ApplyBackground(); Changed();
    }
    void ApplyBackground()
    {
        var bg = DarkBox.IsChecked == true ? Brushes.Black : Brushes.White;
        Viewport.Background = bg;
        if (GridBox.IsChecked == true)
        {
            var group = new DrawingGroup();
            group.Children.Add(new GeometryDrawing(bg, null, new RectangleGeometry(new Rect(0, 0, 24, 24))));
            group.Children.Add(new GeometryDrawing(DarkBox.IsChecked == true ? Brushes.DimGray : Brushes.Black, null, new EllipseGeometry(new Point(12.75, 12.75), .75, .75)));
            Surface.Background = new DrawingBrush(group) { TileMode = TileMode.Tile, ViewportUnits = BrushMappingMode.Absolute, Viewport = new Rect(0, 0, 24, 24), ViewboxUnits = BrushMappingMode.Absolute, Viewbox = new Rect(0, 0, 24, 24), Stretch = Stretch.Fill };
        }
        else Surface.Background = bg;
        foreach (Button swatch in Swatches.Children) ((Ellipse)swatch.Content).Fill = new SolidColorBrush(DisplayColor((Color)swatch.Tag));
        foreach (Stroke stroke in Ink.Strokes)
            if (TryOriginalColor(stroke, out var original)) stroke.DrawingAttributes.Color = DisplayColor(original);
        ConfigureInk();
    }
    static bool TryOriginalColor(Stroke stroke, out Color original)
    {
        original = stroke.DrawingAttributes.Color;
        if (!stroke.ContainsPropertyData(OriginalColor))
        {
            stroke.AddPropertyData(OriginalColor, original.ToString());
            return true;
        }
        if (stroke.GetPropertyData(OriginalColor) is not string value) return false;
        try { original = (Color)ColorConverter.ConvertFromString(value); return true; }
        catch { return false; }
    }
    void StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
    {
        e.Stroke.AddPropertyData(OriginalColor, color.ToString());
        Changed();
    }
    void BeginGesture() { if (pending == null && !restoring) pending = Snapshot(); }
    void PenDown(object sender, StylusDownEventArgs e)
    {
        BeginGesture();
        Status.Text = "Pen tablet detected · " + (PressureBox.IsChecked == true ? "pressure enabled" : "fixed width");
    }
    void PenUp(object sender, StylusEventArgs e) => Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(FinishGesture));
    void PointerDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left && e.ChangedButton != MouseButton.Middle) return;
        if (e.StylusDevice == null) Status.Text = "Mouse · tablet ready";
        if (tool == "Pan" || spacePan || e.ChangedButton == MouseButton.Middle)
        {
            panning = true; start = e.GetPosition(Viewport); startHorizontal = Viewport.HorizontalOffset; startVertical = Viewport.VerticalOffset;
            Ink.CaptureMouse(); e.Handled = true; return;
        }
        BeginGesture();
        if (tool != "Select") return;
        start = e.GetPosition(Surface);
        resizing = selected >= 0 && HandleRect(pictures[selected]).Contains(start);
        if (!resizing) selected = pictures.FindLastIndex(p => new Rect(p.X, p.Y, p.Width, p.Height).Contains(start));
        if (selected >= 0) { startPicture = pictures[selected]; dragging = true; Ink.CaptureMouse(); }
        DrawSelection(); e.Handled = true;
    }
    void PointerMove(object sender, MouseEventArgs e)
    {
        if (panning)
        {
            var p = e.GetPosition(Viewport); Viewport.ScrollToHorizontalOffset(startHorizontal - p.X + start.X); Viewport.ScrollToVerticalOffset(startVertical - p.Y + start.Y); e.Handled = true;
        }
        if (!dragging || selected < 0 || startPicture is not Picture original) return;
        var position = e.GetPosition(Surface); var delta = position - start;
        if (resizing)
        {
            double maxWidth = Math.Max(1, Math.Min(Surface.Width - original.X, (Surface.Height - original.Y) * original.Width / original.Height));
            double w = Math.Clamp(original.Width + delta.X, Math.Min(20, maxWidth), maxWidth);
            pictures[selected] = original with { Width = w, Height = w * original.Height / original.Width };
        }
        else pictures[selected] = original with { X = Math.Clamp(original.X + delta.X, 0, Math.Max(0, Surface.Width - original.Width)), Y = Math.Clamp(original.Y + delta.Y, 0, Math.Max(0, Surface.Height - original.Height)) };
        // Reuse the bitmap during dragging, only update layout.
        var image = (Image)Images.Children[selected]; var current = pictures[selected];
        Canvas.SetLeft(image, current.X); Canvas.SetTop(image, current.Y); image.Width = current.Width; image.Height = current.Height;
        DrawSelection(); e.Handled = true;
    }
    void PointerUp(object sender, MouseButtonEventArgs e) => Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(FinishGesture));
    void CaptureLost(object sender, InputEventArgs e) => Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(FinishGesture));
    void FinishGesture()
    {
        dragging = panning = resizing = false; startPicture = null;
        if (Ink.IsMouseCaptured) Ink.ReleaseMouseCapture();
        if (pending is Document before)
        {
            pending = null;
            var after = Snapshot();
            if (!Same(before, after)) { Remember(before); Changed(); }
        }
    }
    void OnDeactivated(object? sender, EventArgs e)
    {
        // Ending edit mode discards any unfinished dynamic stroke and resets input after focus changes.
        Ink.EditingMode = InkCanvasEditingMode.None;
        Ink.ReleaseStylusCapture(); FinishGesture(); spacePan = false; ConfigureInk();
    }
    static bool Same(Document a, Document b) => a.Width == b.Width && a.Height == b.Height && a.Dark == b.Dark && a.Grid == b.Grid && a.Ink.AsSpan().SequenceEqual(b.Ink) && a.Pictures.SequenceEqual(b.Pictures);
    Document Snapshot()
    {
        using var stream = new MemoryStream(); Ink.Strokes.Save(stream);
        return new(1, Surface.Width, Surface.Height, DarkBox.IsChecked == true, GridBox.IsChecked == true, stream.ToArray(), new(pictures));
    }
    void Remember(Document d)
    {
        undo.Add(d); redo.Clear();
        // Bound history; image bytes are immutable and shared by snapshots.
        long bytes = 0;
        for (int i = undo.Count - 1; i >= 0; i--) { bytes += undo[i].Ink.Length + undo[i].Pictures.Sum(p => (long)p.Png.Length); if (bytes > 128L * 1024 * 1024 || undo.Count - i > 40) { undo.RemoveRange(0, i + 1); break; } }
    }
    void Restore(Document d)
    {
        restoring = true;
        try
        {
            // Decode everything before touching the current board.
            var strokes = new StrokeCollection(new MemoryStream(d.Ink));
            var decoded = d.Pictures.Select(p => Decode(p.Png)).ToArray();
            Ink.Strokes.Clear(); Ink.Strokes.Add(strokes);
            Surface.Width = d.Width; Surface.Height = d.Height;
            BoardWidth.Text = d.Width.ToString("0"); BoardHeight.Text = d.Height.ToString("0");
            DarkBox.IsChecked = d.Dark; GridBox.IsChecked = d.Grid;
            pictures.Clear(); pictures.AddRange(d.Pictures); Images.Children.Clear();
            for (int i = 0; i < pictures.Count; i++) AddImageView(pictures[i], decoded[i]);
            selected = -1; DrawSelection(); ApplyBackground();
        }
        finally { restoring = false; }
    }
    void UndoClick(object sender, RoutedEventArgs e) { FinishGesture(); if (undo.Count == 0) return; redo.Add(Snapshot()); var d = undo[^1]; undo.RemoveAt(undo.Count - 1); Restore(d); Changed(); }
    void RedoClick(object sender, RoutedEventArgs e) { FinishGesture(); if (redo.Count == 0) return; undo.Add(Snapshot()); var d = redo[^1]; redo.RemoveAt(redo.Count - 1); Restore(d); Changed(); }
    void Changed() { dirty = true; Title = "problem-slate · " + (filePath == null ? "Untitled board" : System.IO.Path.GetFileName(filePath)) + " *"; ClearButton.IsEnabled = Ink.Strokes.Count > 0 || pictures.Count > 0; ScheduleRecovery(); }
    void ScheduleRecovery() { if (!ready || restoring) return; UndoButton.IsEnabled = undo.Count > 0; RedoButton.IsEnabled = redo.Count > 0; recoveryTimer.Stop(); recoveryTimer.Start(); }
    void QueueRecovery()
    {
        var snapshot = Snapshot();
        recoveryWork = recoveryWork.ContinueWith(_ => { try { WriteDocument(recoveryPath, snapshot); } catch { /* surfaced at final flush */ } }, TaskScheduler.Default);
    }
    static void WriteDocument(string path, Document document)
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(path))!);
        string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try { using (var stream = File.Create(temp)) JsonSerializer.Serialize(stream, document); File.Move(temp, path, true); }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }
    static Document ReadDocument(string path)
    {
        if (new FileInfo(path).Length > 160L * 1024 * 1024) throw new InvalidDataException("Board exceeds 160 MB.");
        using var stream = File.OpenRead(path);
        var d = JsonSerializer.Deserialize<Document>(stream) ?? throw new InvalidDataException("Empty board.");
        if (d.Version != 1 || !double.IsFinite(d.Width) || !double.IsFinite(d.Height) || d.Width < 512 || d.Width > 8192 || d.Height < 512 || d.Height > 8192 || d.Ink == null || d.Pictures == null || d.Pictures.Count > 100) throw new InvalidDataException("Unsupported or invalid Windows board.");
        long total = 0;
        foreach (var p in d.Pictures)
        {
            if (p == null || p.Png == null || p.Png.Length > 25 * 1024 * 1024 || !double.IsFinite(p.X) || !double.IsFinite(p.Y) || !double.IsFinite(p.Width) || !double.IsFinite(p.Height) || p.Width <= 0 || p.Height <= 0 || p.Width > 8192 || p.Height > 8192) throw new InvalidDataException("Invalid image.");
            total += p.Png.Length;
        }
        if (total > 100L * 1024 * 1024) throw new InvalidDataException("Images exceed 100 MB.");
        return d;
    }
    bool Save(bool saveAs = false)
    {
        FinishGesture(); string? target = filePath;
        if (target == null || saveAs)
        {
            var dialog = new SaveFileDialog { Filter = "Windows slate board (*.wslate)|*.wslate", DefaultExt = ".wslate", FileName = target == null ? "Untitled.wslate" : System.IO.Path.GetFileName(target) };
            if (dialog.ShowDialog(this) != true) return false; target = dialog.FileName;
        }
        try { WriteDocument(target, Snapshot()); filePath = target; dirty = false; Title = "problem-slate · " + System.IO.Path.GetFileName(target); Status.Text = "Board saved"; return true; }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not save"); return false; }
    }
    bool CanReplace()
    {
        FinishGesture(); if (!dirty) return true;
        var answer = MessageBox.Show(this, "Save this board before continuing?", "Unsaved board", MessageBoxButton.YesNoCancel);
        return answer == MessageBoxResult.No || answer == MessageBoxResult.Yes && Save();
    }
    void SaveClick(object sender, RoutedEventArgs e) => Save();
    void SaveAsClick(object sender, RoutedEventArgs e) => Save(true);
    void OpenClick(object sender, RoutedEventArgs e)
    {
        if (!CanReplace()) return;
        var dialog = new OpenFileDialog { Filter = "Windows slate board (*.wslate)|*.wslate" }; if (dialog.ShowDialog(this) != true) return;
        try { Restore(ReadDocument(dialog.FileName)); undo.Clear(); redo.Clear(); filePath = dialog.FileName; dirty = false; Title = "problem-slate · " + System.IO.Path.GetFileName(filePath); ScheduleRecovery(); }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not open board"); }
    }
    void NewClick(object sender, RoutedEventArgs e)
    {
        if (!CanReplace()) return;
        Ink.Strokes.Clear(); pictures.Clear(); Images.Children.Clear(); selected = -1; DrawSelection();
        Surface.Width = Surface.Height = 4096; BoardWidth.Text = BoardHeight.Text = "4096";
        filePath = null; undo.Clear(); redo.Clear(); SetZoom(1);
        DarkBox.IsChecked = false; GridBox.IsChecked = true; ApplyBackground();
        dirty = false; Title = "problem-slate · Untitled board"; ClearButton.IsEnabled = false; ScheduleRecovery();
    }
    void ClearClick(object sender, RoutedEventArgs e)
    {
        FinishGesture();
        if (Ink.Strokes.Count == 0 && pictures.Count == 0) return;
        Remember(Snapshot()); Ink.Strokes.Clear(); pictures.Clear(); Images.Children.Clear(); selected = -1; DrawSelection(); Changed();
    }
    void ResizeBoard(object sender, RoutedEventArgs e)
    {
        if (!int.TryParse(BoardWidth.Text, out int w) || !int.TryParse(BoardHeight.Text, out int h) || w < 512 || h < 512 || w > 8192 || h > 8192) { MessageBox.Show(this, "Width and height must be between 512 and 8192 pixels."); return; }
        FinishGesture();
        if (Surface.Width == w && Surface.Height == h) { BoardWidth.Text = w.ToString(); BoardHeight.Text = h.ToString(); return; }
        Remember(Snapshot()); Surface.Width = w; Surface.Height = h; BoardWidth.Text = w.ToString(); BoardHeight.Text = h.ToString(); Changed();
    }
    static BitmapSource Decode(byte[] png)
    {
        using var stream = new MemoryStream(png);
        var decoder = BitmapDecoder.Create(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnDemand);
        var frame = decoder.Frames[0];
        if ((long)frame.PixelWidth * frame.PixelHeight > 32_000_000) throw new InvalidDataException("Image exceeds 32 megapixels.");
        var bitmap = new WriteableBitmap(frame);
        bitmap.Freeze(); return bitmap;
    }
    void AddImageView(Picture p, BitmapSource bitmap)
    {
        var image = new Image { Source = bitmap, Width = p.Width, Height = p.Height, Stretch = Stretch.Fill };
        Canvas.SetLeft(image, p.X); Canvas.SetTop(image, p.Y); Images.Children.Add(image);
    }
    void Paste()
    {
        try
        {
            BitmapSource? bitmap = null;
            // File-drop data comes first; never paste Explorer's generic file icon.
            bool hasFileDrop = Clipboard.ContainsFileDropList();
            if (hasFileDrop)
            {
                foreach (string path in Clipboard.GetFileDropList())
                {
                    if (!new[] { ".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff" }.Contains(System.IO.Path.GetExtension(path).ToLowerInvariant())) continue;
                    if (new FileInfo(path).Length > 25L * 1024 * 1024) throw new InvalidDataException("Image exceeds 25 MB.");
                    bitmap = Decode(File.ReadAllBytes(path)); break;
                }
            }
            else if (Clipboard.ContainsImage()) bitmap = Clipboard.GetImage();
            if (bitmap == null) { Status.Text = "Copy an image or image file first."; return; }
            if ((long)bitmap.PixelWidth * bitmap.PixelHeight > 32_000_000) throw new InvalidDataException("Image exceeds 32 megapixels.");
            var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap)); using var stream = new MemoryStream(); encoder.Save(stream); byte[] png = stream.ToArray();
            if (png.Length > 25L * 1024 * 1024 || pictures.Count >= 100 || pictures.Sum(p => (long)p.Png.Length) + png.Length > 100L * 1024 * 1024) throw new InvalidDataException("Image limit: 25 MB each, 100 images and 100 MB total.");
            double scale = Math.Min(1, Math.Min(Math.Min(800, Surface.Width) / bitmap.PixelWidth, Math.Min(800, Surface.Height) / bitmap.PixelHeight));
            double w = bitmap.PixelWidth * scale, h = bitmap.PixelHeight * scale;
            double x = Math.Clamp((Viewport.HorizontalOffset + Viewport.ViewportWidth / 2) / zoom - w / 2, 0, Surface.Width - w);
            double y = Math.Clamp((Viewport.VerticalOffset + Viewport.ViewportHeight / 2) / zoom - h / 2, 0, Surface.Height - h);
            FinishGesture(); Remember(Snapshot()); var picture = new Picture(png, x, y, w, h); pictures.Add(picture); AddImageView(picture, bitmap);
            selected = pictures.Count - 1; tool = "Select"; ConfigureInk(); DrawSelection(); Changed(); Status.Text = "Image pasted · drag to move, corner to resize";
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not paste image"); }
    }
    Rect HandleRect(Picture p) => new(p.X + p.Width - 8 / zoom, p.Y + p.Height - 8 / zoom, 16 / zoom, 16 / zoom);
    void DrawSelection()
    {
        Selection.Children.Clear(); if (selected < 0 || selected >= pictures.Count) return;
        var p = pictures[selected];
        var border = new Rectangle { Width = p.Width, Height = p.Height, Stroke = Brushes.DarkTurquoise, StrokeThickness = 1.5 / zoom, StrokeDashArray = new DoubleCollection { 4, 3 } };
        Canvas.SetLeft(border, p.X); Canvas.SetTop(border, p.Y); Selection.Children.Add(border);
        var r = HandleRect(p); var handle = new Rectangle { Width = r.Width, Height = r.Height, Fill = Brushes.White, Stroke = Brushes.DarkTurquoise, StrokeThickness = 1.5 / zoom };
        Canvas.SetLeft(handle, r.X); Canvas.SetTop(handle, r.Y); Selection.Children.Add(handle);
    }
    void DeleteSelection()
    {
        if (selected < 0) return; Remember(Snapshot()); pictures.RemoveAt(selected); Images.Children.RemoveAt(selected); selected = -1; DrawSelection(); Changed();
    }
    void SetZoom(double value)
    {
        FinishGesture(); double previous = zoom; zoom = Math.Clamp(value, .25, 3);
        double cx = (Viewport.HorizontalOffset + Viewport.ViewportWidth / 2) / previous, cy = (Viewport.VerticalOffset + Viewport.ViewportHeight / 2) / previous;
        ZoomTransform.ScaleX = ZoomTransform.ScaleY = zoom; Surface.UpdateLayout();
        Viewport.ScrollToHorizontalOffset(cx * zoom - Viewport.ViewportWidth / 2); Viewport.ScrollToVerticalOffset(cy * zoom - Viewport.ViewportHeight / 2);
        ZoomLabel.Text = $"{zoom:P0}"; DrawSelection();
    }
    void ZoomIn(object sender, RoutedEventArgs e) => SetZoom(zoom + .25);
    void ZoomOut(object sender, RoutedEventArgs e) => SetZoom(zoom - .25);
    void OnWheel(object sender, MouseWheelEventArgs e)
    {
        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) SetZoom(zoom * (e.Delta > 0 ? 1.1 : 1 / 1.1));
        else if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) Viewport.ScrollToHorizontalOffset(Viewport.HorizontalOffset - e.Delta);
        else Viewport.ScrollToVerticalOffset(Viewport.VerticalOffset - e.Delta);
        e.Handled = true;
    }
    void ExportClick(object sender, RoutedEventArgs e)
    {
        FinishGesture(); var dialog = new SaveFileDialog { Filter = "PNG image|*.png", FileName = "Board.png" }; if (dialog.ShowDialog(this) != true) return;
        try
        {
            var visual = new DrawingVisual(); using (var dc = visual.RenderOpen())
            {
                dc.PushClip(new RectangleGeometry(new Rect(0, 0, Surface.Width, Surface.Height)));
                dc.DrawRectangle(Surface.Background, null, new Rect(0, 0, Surface.Width, Surface.Height));
                for (int i = 0; i < pictures.Count; i++) { var p = pictures[i]; dc.DrawImage(((Image)Images.Children[i]).Source, new Rect(p.X, p.Y, p.Width, p.Height)); }
                Ink.Strokes.Draw(dc); dc.Pop();
            }
            var bitmap = new RenderTargetBitmap((int)Surface.Width, (int)Surface.Height, 96, 96, PixelFormats.Pbgra32); bitmap.Render(visual);
            var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap)); using var stream = File.Create(dialog.FileName); encoder.Save(stream); Status.Text = "PNG exported";
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not export"); }
    }
    void OnKey(object sender, KeyEventArgs e)
    {
        if (Keyboard.FocusedElement is TextBox) return;
        bool ctrl = Keyboard.Modifiers.HasFlag(ModifierKeys.Control), shift = Keyboard.Modifiers.HasFlag(ModifierKeys.Shift);
        if (ctrl)
        {
            switch (e.Key)
            {
                case Key.Z: if (shift) RedoClick(this, e); else UndoClick(this, e); break;
                case Key.Y: RedoClick(this, e); break;
                case Key.S: Save(shift); break;
                case Key.O: OpenClick(this, e); break;
                case Key.N: NewClick(this, e); break;
                case Key.V: Paste(); break;
                case Key.E when shift: ExportClick(this, e); break;
                case Key.K when shift: ClearClick(this, e); break;
                default: return;
            }
        }
        else
        {
            switch (e.Key)
            {
                case Key.Space: if (!spacePan) { FinishGesture(); spacePan = true; ConfigureInk(); } break;
                case Key.Delete: case Key.Back: DeleteSelection(); break;
                case Key.Escape: selected = -1; DrawSelection(); break;
                case Key.P: ChooseTool("Pen"); break;
                case Key.C: ChooseTool("Chisel"); break;
                case Key.H: ChooseTool("Highlighter"); break;
                case Key.E: ChooseTool("Eraser"); break;
                case Key.V: ChooseTool("Select"); break;
                case Key.M: ChooseTool("Pan"); break;
                default: return;
            }
        }
        e.Handled = true;
    }
    void OnClosing(object? sender, CancelEventArgs e)
    {
        if (!CanReplace()) { e.Cancel = true; return; }
        recoveryTimer.Stop(); recoveryWork.GetAwaiter().GetResult();
        try { WriteDocument(recoveryPath, Snapshot()); }
        catch (Exception ex) { MessageBox.Show(this, "Recovery could not be saved: " + ex.Message); }
    }
    internal void RunSmokeTests()
    {
        void Check(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        DarkBox.IsChecked = false; GridBox.IsChecked = true; ApplyBackground();
        var gridVisual = new DrawingVisual();
        using (var dc = gridVisual.RenderOpen()) dc.DrawRectangle(Surface.Background, null, new Rect(0, 0, 48, 48));
        var gridPixels = new RenderTargetBitmap(48, 48, 96, 96, PixelFormats.Pbgra32); gridPixels.Render(gridVisual);
        var pixel = new byte[4]; gridPixels.CopyPixels(new Int32Rect(12, 12, 1, 1), pixel, 4, 0);
        Check(pixel[0] < 230 && pixel[3] == 255, "White board must render a visible dark dot.");
        gridPixels.CopyPixels(new Int32Rect(5, 5, 1, 1), pixel, 4, 0);
        Check(pixel[0] == 255, "Space between dots must remain white.");
        ChooseTool("Chisel"); Check(SizeSlider.Value == 12, "Chisel default size differs from Mac.");
        ChooseTool("Pen"); Check(SizeSlider.Value == 4, "Pen default size differs from Mac.");
        Ink.Strokes.Clear(); pictures.Clear();
        var black = new Stroke(new StylusPointCollection(new[] { new StylusPoint(50, 50, .2f), new StylusPoint(100, 100, .8f), new StylusPoint(150, 150, .5f) }));
        black.AddPropertyData(OriginalColor, Colors.Black.ToString()); Ink.Strokes.Add(black);
        var red = black.Clone(); red.RemovePropertyData(OriginalColor); red.AddPropertyData(OriginalColor, Colors.Red.ToString()); red.DrawingAttributes.Color = Colors.Red; Ink.Strokes.Add(red);
        DarkBox.IsChecked = true; ApplyBackground();
        Check(black.DrawingAttributes.Color == Colors.White && red.DrawingAttributes.Color == Colors.Red, "Dark background must remap only black.");
        DarkBox.IsChecked = false; ApplyBackground();
        Check(black.DrawingAttributes.Color == Colors.Black, "Original black must return.");
        ClearClick(this, new RoutedEventArgs()); Check(Ink.Strokes.Count == 0 && !ClearButton.IsEnabled, "Clear failed.");
        UndoClick(this, new RoutedEventArgs()); Check(Ink.Strokes.Count == 2, "Clear undo failed.");
        RedoClick(this, new RoutedEventArgs()); Check(Ink.Strokes.Count == 0, "Clear redo failed.");
        int historyAfterClear = undo.Count; ClearClick(this, new RoutedEventArgs()); Check(undo.Count == historyAfterClear, "Clearing an empty board added an undo step.");
        UndoClick(this, new RoutedEventArgs());
        var original = Snapshot();
        Ink.Strokes.Erase(new[] { new Point(100, 80), new Point(100, 120) }, new EllipseStylusShape(25, 25));
        Check(!original.Ink.AsSpan().SequenceEqual(Snapshot().Ink), "Point erase did not change ink.");
        Restore(original);
        var pixels = BitmapSource.Create(1, 1, 96, 96, PixelFormats.Bgra32, null, new byte[] { 0, 0, 255, 255 }, 4);
        var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(pixels));
        using var imageBytes = new MemoryStream(); encoder.Save(imageBytes);
        var picture = new Picture(imageBytes.ToArray(), 20, 30, 100, 100); pictures.Add(picture); AddImageView(picture, pixels);
        string temp = System.IO.Path.Combine(System.IO.Path.GetTempPath(), Guid.NewGuid() + ".wslate");
        try
        {
            WriteDocument(temp, Snapshot()); var loaded = ReadDocument(temp); Restore(loaded);
            Check(Ink.Strokes.Count == 2 && pictures.Count == 1 && Surface.Width == 4096, "Document roundtrip failed.");
            Check(pictures[0].Png.AsSpan().SequenceEqual(picture.Png), "Embedded image changed.");
            DarkBox.IsChecked = true; ApplyBackground(); Check(Ink.Strokes[0].DrawingAttributes.Color == Colors.White, "Original color metadata did not roundtrip.");
            BoardWidth.Text = "2048"; BoardHeight.Text = "3072"; ResizeBoard(this, new RoutedEventArgs());
            Check(Surface.Width == 2048 && Surface.Height == 3072, "Resize failed."); UndoClick(this, new RoutedEventArgs());
            Check(Surface.Width == 4096 && Surface.Height == 4096, "Resize undo failed.");
            var malformed = black.Clone(); malformed.RemovePropertyData(OriginalColor); malformed.AddPropertyData(OriginalColor, "not-a-color"); Ink.Strokes.Add(malformed);
            DarkBox.IsChecked = true; ApplyBackground(); Check(malformed.DrawingAttributes.Color == Colors.Black, "Malformed color metadata should be ignored safely."); Ink.Strokes.Remove(malformed);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); recoveryTimer.Stop(); }
    }

}
