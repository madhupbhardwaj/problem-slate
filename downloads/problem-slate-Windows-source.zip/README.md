# problem-slate for Windows — developer preview

Native C# / WPF whiteboard, targeting Windows 11 x64 with .NET 10.
This package contains source code, not a precompiled installer. No paid developer
membership is required to build it. It has not been compiled or run in the authoring
Linux environment, which has no .NET SDK or Windows desktop. Test on Windows before
publishing an executable as a stable release.

## Run on Windows

1. Extract this ZIP with **Extract All**. Do not launch from inside the ZIP preview.
2. Install the free **.NET 10 SDK** for Windows x64 (SDK, not only Runtime):
   https://dotnet.microsoft.com/download/dotnet/10.0
3. Double-click **Build-and-Run.cmd**. The first build needs internet to restore Microsoft components.
4. The built application opens. Later, run **dist/win-x64/problem-slate.exe** directly.
   You can copy that EXE to your own folder and create a desktop shortcut.

The publish command embeds the runtime and logo in a single EXE. People receiving
that finished EXE do not need the SDK or loose logo/source files. It is unsigned;
Windows may show publisher/reputation warnings. Packaging is not tamper prevention.
Do not instruct users to disable security software.

## Build from a Mac using GitHub

1. Create a separate repository for the Windows app.
2. Put this folder's **contents** at repository root, including `.github/workflows/windows.yml`.
   Enable hidden-file viewing in Finder with Command-Shift-period to see `.github`.
   If using GitHub's web UI, create `.github/workflows/windows.yml` with **Add file → Create new file**
   and paste the supplied YAML; upload the other source files normally.
3. Open **Actions → Build Windows app → Run workflow**.
4. When it succeeds, download the **problem-slate-Windows-x64** artifact from the run.
5. Extract the artifact and test the EXE on a Windows PC. The workflow checks build and
   board operations, but not real pen drivers or physical UI interactions.
6. Publish the tested EXE in a ZIP through your download host/GitHub Releases and update
   the website's Windows link and preview wording. Do not label the source ZIP an installer.

GitHub Actions availability/usage limits depend on your account. No remote workflow
has been run by the author here. This workflow is supplied for you to run.

## Features

- Compact full-button hit targets: Select (V), Pan (M), Pen (P), Chisel (C), Highlighter (H), Eraser (E).
- Native WPF ink and curve fitting, pressure-aware round/angled rectangular nibs;
  adjust nib angle, size, color and pressure. Reverse-tip eraser when driver exposes it.
- Black/white board: logical black ink becomes white on black, restores black on white.
  Other ink colors are kept. Dot grid optional. No white scrollbar tracks.
- 4096×4096 new board; editable width/height from 512 to 8192. Shrinking clips content
  without deleting it; expand again or undo to reveal it.
- Drag with Pan or hold Space. Scroll vertically, Shift-scroll horizontally;
  Ctrl-scroll or +/- buttons zoom from 25% to 300%.
- Ctrl+V pastes PNG/JPEG/BMP/GIF/TIFF files or clipboard image pixels. The first supported
  image file is loaded, not Explorer's file icon. Animated images use their first frame.
  HEIC is not supported in this Windows preview.
- Select an image to move it; drag its bottom-right handle to resize proportionally;
  Delete removes it. Ink renders above images; the eraser removes portions of ink only.
- Undo/redo for drawing, erasing, images, clearing, background/grid and board resizing.
  History is capped at 40 actions and approximately 128 MB of snapshots.
- Ctrl+S save, Ctrl+Shift+S save as, Ctrl+O open, Ctrl+N new board.
  Ctrl+Shift+E exports the entire board as PNG at its chosen dimensions.
- Recovery stored in `%LOCALAPPDATA%\problem-slate\Recovery.wslate` after a two-second
  idle delay and at clean exit. Named files save only when requested. Opening/new board
  replaces the single recovery slot. Active unfinished ink may be lost on focus changes.
- Images capped at 25 MB / 32 megapixels each, 100 images and 100 MB per board.

## Windows versus Mac files

This native Windows implementation saves **.wslate** documents (JSON + native ink data).
They are **not compatible with the Mac .slate format**. Use PNG export and paste to
exchange flattened boards between platforms. This is an explicit limitation of the
preview; do not rename extensions expecting conversion.

## Tablet and smoothness

Install the tablet manufacturer's Windows driver and enable its Windows Ink support.
The status bar reports pen events as they arrive; the app does not enumerate USB devices
or identify brands. Mouse-emulation-only drivers cannot supply pressure.
WPF's native dynamic renderer handles live ink; completed strokes are retained separately.
Focus loss resets the active gesture to avoid long connecting lines when returning.
Real Wacom, Huion, XP-Pen and other hardware has not been tested here.

## Before releasing

Run on Windows and test all of these:
1. Pen dots, fast strokes, pressure, chisel angle, inverted pen eraser and mouse fallback.
2. Switch apps mid-stroke and after idle; check there are no connecting lines or lag.
3. Draw black/red/blue, toggle dark twice, save/open and check original colors.
4. Erase portions, undo/redo; clear a board with images, undo/redo.
5. Paste an Explorer image and screenshot, move/resize/delete and undo each.
6. Resize smaller and larger; pan/zoom; export PNG at 4096 and 8192 and check dimensions.
7. Save/open, close/restart recovery, cancel unsaved prompts, try an invalid board file.
8. Verify both Windows and Mac links on the redeployed website.

Reference: https://learn.microsoft.com/dotnet/core/deploying/single-file/overview
