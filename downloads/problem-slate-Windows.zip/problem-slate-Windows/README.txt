problem-slate 1.7 for Windows (x64) — preview
=============================================

1. Right-click the downloaded ZIP and choose "Extract All".
2. Open the extracted folder and double-click problem-slate.exe.
   Nothing else needs to be installed: the .NET runtime is included.
3. The app is not code-signed. If Windows SmartScreen says
   "Windows protected your PC", click "More info", then "Run anyway".

You can move problem-slate.exe anywhere (for example your Documents folder)
and pin it to Start or the taskbar.

Quick keys
  P pen · C chisel · H highlighter · E eraser · V select · M pan
  Shift + draw    straight line        [ / ]        brush size
  Space + drag    pan                  Ctrl+scroll  zoom
  Ctrl+9          fit board            Ctrl+0       100%
  Ctrl+V or drop  add an image         Arrow keys   nudge selected image
  Ctrl+Z / Ctrl+Y undo / redo          Ctrl+S       save (.wslate)
  Ctrl+Shift+C    copy board as image  Ctrl+Shift+E export PNG

Boards autosave to %LOCALAPPDATA%\problem-slate\Recovery.wslate and reopen on launch.
Windows .wslate boards cannot be opened by the Mac app; share boards as PNG.

This build was compiled and its automated board tests pass, but it has not yet
been tested on physical Windows PCs or pen tablets.
