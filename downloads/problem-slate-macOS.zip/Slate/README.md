# problem-slate 1.4 — a simple native Mac whiteboard

A SwiftUI + AppKit app for macOS 13 Ventura or later. Works with mouse/trackpad and receives native tablet pen events. No third-party packages, accounts, or network requests.

## Update from the first version

Save any board you want to keep and quit the old Slate app. Extract this updated ZIP into a new folder. Run its `Build-and-Run.command` using the same Terminal method as before (`bash ` followed by dragging the command file into Terminal). Copy the newly built `dist/problem-slate.app` into Applications. You can then remove the old `Slate.app` from Applications. Existing `.slate` files and the recovery location are compatible. You do not need to reinstall developer tools. Do not accidentally run the launcher from the old download folder.

## Fixed in 1.4

- Copying a PNG, JPEG, HEIC, GIF, TIFF or other supported image file in Finder now pastes the actual image. Earlier versions could paste macOS's generic file icon instead.
- Clipboard pixels copied from Preview, Photos, browsers and screenshot tools continue to work.
- When Finder supplies file URLs, problem-slate accepts only files whose system type is an image. This prevents unrelated document icons from being pasted accidentally.

## New in 1.3

- Rebranded the app as **problem-slate** to match the supplied problemset design.
- Added a near-black header with a white rounded-square pen mark and bold lowercase monospaced wordmark.
- Added a matching pen app icon for Finder, Applications, the Dock, and app switching.
- The build now creates `dist/problem-slate.app`. The editable board format and recovery folder remain compatible with earlier versions.

## New in 1.2

- Copy an image from Finder, Preview, Photos, a browser, or another app and press **Command-V** in Slate. You can also click **Paste image** in the sidebar.
- Slate places the image in the center of the currently visible board and automatically selects it.
- Choose **Select** or press **V**, then drag an image to move it. Drag its lower-right square handle to resize it while keeping its proportions.
- Press Delete or Backspace to remove the selected image. Image insertion, movement, resizing, deletion, and Clear Board work with undo and redo.
- Pasted images are stored inside `.slate` files and recovery data and appear in PNG exports. Ink is drawn above images, while the eraser removes only ink.
- Each pasted image is limited to 25 MB; a board accepts up to 100 images and 100 MB of embedded image data.

## New in 1.1

- **Clear board** in the sidebar (also Board menu or Shift-Command-K). Clears ink while keeping the background and grid. Command-Z restores the cleared drawing as one action.
- **Black background** toggle in the sidebar and Board menu. Existing and new black ink displays white, including the original default blue-black swatch. Other colors are preserved. Toggling back restores original black; the source colors are never overwritten. Saved boards, recovery and PNG export retain the chosen background.
- Tool buttons have a 46-point height, full rectangular hit areas, pressed feedback, a border and a selected checkmark. The wider sidebar scrolls on smaller windows.
- Completed ink is cached and new strokes are appended to that cache. Active geometry grows incrementally instead of regenerating every previous stroke on every event. Midpoint quadratic interpolation and pressure filtering smooth input; autosave encoding/writes now run on a serial background queue. Status updates are throttled. Losing app/window focus commits the stroke and resets input state; each new stroke starts fresh. Duplicate/out-of-order samples are ignored.

These address concrete performance and input-state issues in the earlier source. Smoothness cannot be guaranteed across all tablet drivers and hardware without a Mac/tablet test pass. Extremely long individual strokes may still cost more to display; undo, background changes and zoom rebuild the completed-ink cache once.

## Run on your Mac

1. Extract this ZIP.
2. Install Apple's Command Line Tools if needed: open Terminal and run `xcode-select --install`. The compiler must support Swift 5.9 or newer (Xcode 15 tools or later).
3. Double-click **Build-and-Run.command**. It compiles locally, creates `dist/problem-slate.app`, ad-hoc signs it, and launches it. Alternatively, in Terminal type `bash `, drag the command file onto the Terminal window, and press Return.
4. Drag the resulting **problem-slate.app** into Applications if you want to keep it there.

You can also open Package.swift in Xcode and run the Slate executable scheme. A build is required: this archive contains source, not a precompiled or notarized app. The build launcher uses the architecture of your Mac, supporting Intel and Apple silicon Macs with compatible tools.

## Drawing

- **P — Pen:** round tip, pressure-sensitive width.
- **C — Chisel:** angled rectangular nib with thin and broad strokes; adjustable angle and pressure-sensitive width.
- **H — Highlighter:** translucent broad nib. Select yellow or any other color. Opacity stays even within a stroke; separate passes build up.
- **E — Eraser:** removes portions of ink, preserving the paper/grid; minimum size 20 px.
- Use the swatches or custom color picker, size slider, nib angle slider and pressure toggle.
- Scroll horizontally/vertically to move around the fixed 2400 × 1600 board. Use + / − for 25–300% zoom.
- Command-Z / Shift-Command-Z: undo / redo strokes, including erasing.
- Command-S: save editable `.slate` file. Shift-Command-S: Save As.
- Command-O: open a board. Command-N: new board.
- Shift-Command-E: export the entire board as a 2400 × 1600 PNG, including the grid if enabled.

## Pen tablets

Install your tablet manufacturer's compatible macOS driver and grant it the permissions the manufacturer requires. Connect the tablet, open Slate, and bring the pen into proximity. The bottom status bar reports tablet proximity and pressure when macOS supplies them. If the driver reports the reverse tip as an eraser, flipping the stylus temporarily erases.

Slate uses AppKit's tablet proximity and tablet-point mouse subevents. Detection happens from actual pen events; it does not enumerate USB devices or identify a tablet by brand. Pressure requires a driver that provides native tablet events. A tablet that only emulates a mouse will still draw at a constant width. Tablet side buttons use the manufacturer's mapping. Tilt and barrel rotation are not used; chisel angle is set manually. No specific Wacom, Huion, XP-Pen, or other device has been hardware-tested here.

Apple references:
- https://developer.apple.com/documentation/appkit/nsresponder/tabletproximity(with:)
- https://developer.apple.com/documentation/appkit/nsevent/pressure

## Saving and recovery

Completed strokes and grid changes automatically update `~/Library/Application Support/Slate/Recovery.slate` after a short delay. Normal app exit flushes recovery immediately. Relaunch restores this last working board. This is one recovery slot, not a version history; opening or creating another board replaces it. Save named `.slate` files to keep multiple boards. Named files update only when you choose Save. An interrupted, unfinished stroke may be lost.

## Validation status and Mac checklist

The source was reviewed and shell syntax, plist and ZIP structure were checked in a Linux environment. Compilation, UI rendering and real tablet input have **not** been tested because this environment has no macOS SDK or Swift compiler.

On your Mac:
1. Build and launch; verify all four tools using both taps and fast strokes.
2. For a tablet, check the detection status, light/heavy pressure, reverse-tip erasing if supported, and mouse fallback.
3. Draw highlighter over ink; confirm one pass is even and a second pass darkens.
4. Erase across several strokes; check the grid is preserved; undo and redo the erasure.
5. Save, create a new board, reopen the saved file and export PNG; inspect the whole PNG and orientation.
6. Test zoom and scrolling while drawing; close and relaunch to check recovery.

This version has a fixed board and no text or shape tools. Image selection supports moving and proportional resizing. Vector samples are retained for editing/export, while completed ink is cached for interactive drawing. Very large drawings may slow down. It is locally signed for personal use; distributing a polished downloadable app would need a macOS build/test pass and developer signing/notarization.

## Regression checks for version 1.1

Optional: run `bash Test-on-Mac.command` from this folder (or `swift test`). The included XCTest suite checks legacy file decoding, background persistence, selective black-color conversion, clear/undo/redo, smoother reset, and rendering/erasure parity between cached display and direct export. These Swift tests are supplied but have not been run in the Linux environment.

Also verify on your Mac:
- Click each tool's icon, text, center space and far right edge. All should select it. Scroll the sidebar on a small window.
- Draw black, red, blue and gray strokes. Toggle the black background both ways; only black and the original default blue-black should change. Erase, save/reopen, and export in both modes.
- Clear a populated board, undo, redo, undo, then draw. Check redo resets after the new stroke.
- Draw for several minutes, switch to another app mid-stroke, return, and draw again. Repeat after an idle period; check for stray connecting lines, width spikes, gaps or lag. Test both mouse and tablet.

## Image-paste checks for version 1.2

Copy an image from Preview or Finder, switch to Slate, and press Command-V. Move and resize it, draw over it, erase the drawing, save and reopen the `.slate` file, then export PNG. Check undo and redo after inserting, moving, resizing, deleting, and clearing an image. Transparent PNGs keep their transparency over the selected board background.
