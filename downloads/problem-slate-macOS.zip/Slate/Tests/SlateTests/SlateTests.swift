import XCTest
import AppKit
@testable import Slate

final class SlateTests: XCTestCase {
    func ink(_ color: [Double] = [0, 0, 0, 1], tool: Tool = .pen, x: Double = 100) -> Ink {
        Ink(tool: tool, color: color, width: 20, angle: 0,
            samples: [Sample(x: x, y: 100, pressure: 1), Sample(x: x+80, y: 100, pressure: 1)])
    }
    func testLegacyFileAndThemeRoundTrip() throws {
        let old = Data(#"{"version":1,"strokes":[],"grid":true}"#.utf8)
        var board = try Studio.decode(old)
        XCTAssertFalse(board.isDark)
        board.dark = true; board.strokes = [ink()]
        let loaded = try Studio.decode(JSONEncoder().encode(board))
        XCTAssertTrue(loaded.isDark)
        XCTAssertEqual(loaded.strokes[0].color, [0,0,0,1])
    }
    func testOnlyBlackAndOriginalDefaultAreRemapped() {
        XCTAssertTrue(Renderer.isBlack([0,0,0]))
        XCTAssertTrue(Renderer.isBlack([0.12,0.16,0.23]))
        for c in [[1.0,0,0], [0,0,1], [0.2,0.2,0.2], [1,1,1], [0.05,0.1,0.2]] {
            XCTAssertFalse(Renderer.isBlack(c))
        }
    }
    func testClearUndoRedoPreservesThemeAndCanBeUndoneAsOneAction() throws {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("Recovery.slate")
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        let studio = Studio(recoveryURL: path)
        studio.setDark(true); studio.finish(ink()); studio.finish(ink([1,0,0,1]))
        studio.clearBoard(); XCTAssertTrue(studio.board.strokes.isEmpty); XCTAssertTrue(studio.board.isDark)
        studio.undo(); XCTAssertEqual(studio.board.strokes.count, 2)
        studio.redo(); XCTAssertTrue(studio.board.strokes.isEmpty)
        studio.undo(); studio.undo(); XCTAssertEqual(studio.board.strokes.count, 1)
        studio.finish(ink()); XCTAssertTrue(studio.redoHistory.isEmpty)
        studio.flush()
        XCTAssertTrue(try Studio.decode(Data(contentsOf: path)).isDark)
    }
    func testImagePersistenceAndLegacyCompatibility() throws {
        let png = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M/wHwAF/gL+3MxZ5wAAAABJRU5ErkJggg==")!
        var board = Board()
        let image = BoardImage(png: png, x: 12, y: 34, width: 100, height: 100)
        board.images = [image]
        let decoded = try Studio.decode(JSONEncoder().encode(board))
        XCTAssertEqual(decoded.boardImages.count, 1)
        XCTAssertEqual(decoded.boardImages[0].id, image.id)
        XCTAssertEqual(decoded.boardImages[0].rect, image.rect)
    }
    func testImageMoveUndoRedoAndClear() throws {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("Recovery.slate")
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        let studio = Studio(recoveryURL: path)
        let image = BoardImage(png: Data(), x: 10, y: 20, width: 100, height: 80)
        studio.board.images = [image]
        let before = image.rect, after = CGRect(x: 50, y: 60, width: 200, height: 160)
        studio.updateImage(image.id, rect: after)
        studio.undoHistory.append(.moveImage(id: image.id, before: before, after: after))
        studio.undo(); XCTAssertEqual(studio.board.boardImages[0].rect, before)
        studio.redo(); XCTAssertEqual(studio.board.boardImages[0].rect, after)
        studio.clearBoard(); XCTAssertTrue(studio.board.boardImages.isEmpty)
        studio.undo(); XCTAssertEqual(studio.board.boardImages[0].id, image.id)
    }
    func testSmoothingContinuityAndFreshStroke() {
        var smoother = StrokeSmoother(Sample(x: 0, y: 0, pressure: 1))
        let points = smoother.add(Sample(x: 20, y: 0, pressure: 0.1))
        XCTAssertEqual(points.last!.x, 10, accuracy: 0.001)
        XCTAssertTrue(points.allSatisfy { $0.y == 0 && $0.pressure > 0.1 })
        XCTAssertEqual(smoother.previous.x, 20) // commit flushes this exact endpoint
        var fresh = StrokeSmoother(Sample(x: 500, y: 300, pressure: 0.5))
        XCTAssertTrue(fresh.add(Sample(x: 502, y: 300, pressure: 0.5)).allSatisfy { $0.x >= 500 && $0.y == 300 })
    }
    func rendered(_ board: Board, cached: Bool) throws -> [UInt8] {
        let ctx = try XCTUnwrap(CGContext(data: nil, width: 2400, height: 1600, bitsPerComponent: 8, bytesPerRow: 2400*4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
        ctx.translateBy(x: 0, y: 1600); ctx.scaleBy(x: 1, y: -1)
        if cached {
            let layer = try XCTUnwrap(CGLayer(ctx, size: board.size, auxiliaryInfo: nil))
            let cache = try XCTUnwrap(layer.context)
            for stroke in board.strokes { Renderer.stroke(stroke, dark: board.isDark, in: cache) }
            Renderer.paper(board, in: ctx)
            ctx.draw(layer, at: .zero)
        } else { Renderer.board(board, active: nil, in: ctx) }
        return Array(UnsafeBufferPointer(start: try XCTUnwrap(ctx.data).assumingMemoryBound(to: UInt8.self), count: 2400*1600*4))
    }
    func testRenderingThemeErasureAndCacheParity() throws {
        var board = Board(); board.grid = false
        board.strokes = [ink(), ink([1,0,0,1], x: 300), ink(tool: .eraser, x: 150)]
        let light = try rendered(board, cached: false)
        board.dark = true
        let dark = try rendered(board, cached: false)
        let cache = try rendered(board, cached: true)
        func pixel(_ data: [UInt8], _ x: Int, _ y: Int) -> [UInt8] {
            let i = ((1599-y)*2400+x)*4
            return Array(data[i..<i+3])
        }
        XCTAssertEqual(pixel(light, 120, 100), [0,0,0])
        XCTAssertEqual(pixel(dark, 120, 100), [255,255,255])
        XCTAssertEqual(pixel(light, 330, 100), pixel(dark, 330, 100))
        XCTAssertEqual(pixel(dark, 180, 100), [0,0,0])
        XCTAssertEqual(pixel(light, 180, 100), [255,255,255])
        // Same orientation, colors and erasing in the interactive cache and exported image.
        for x in [120, 180, 330, 500] { XCTAssertEqual(pixel(cache, x, 100), pixel(dark, x, 100)) }
    }
    func testNewAndLegacyCanvasSizes() throws {
        XCTAssertEqual(Board.blank.size, CGSize(width: 4096, height: 4096))
        let old = Data(#"{"version":1,"strokes":[],"grid":true}"#.utf8)
        XCTAssertEqual(try Studio.decode(old).size, CGSize(width: 2400, height: 1600))
        var resized = Board.blank; resized.canvasWidth = 3000; resized.canvasHeight = 2048
        let decoded = try Studio.decode(JSONEncoder().encode(resized))
        XCTAssertEqual(decoded.size, CGSize(width: 3000, height: 2048))
    }
}
