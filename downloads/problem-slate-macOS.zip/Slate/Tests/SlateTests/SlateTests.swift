import XCTest
import AppKit
@testable import Slate

final class SlateTests: XCTestCase {
    func ink(_ color: [Double] = [0, 0, 0, 1], tool: Tool = .pen, x: Double = 100) -> Ink {
        Ink(tool: tool, color: color, width: 20, angle: 0,
            samples: [Sample(x: x, y: 100, pressure: 1), Sample(x: x+80, y: 100, pressure: 1)])
    }
    func testLegacyFileAndThemeRoundTrip() throws {
        let old = Data(#"{"version":1,"strokes":[],"grid":true}"#.utf8)
        var board = try Studio.decode(old)
        XCTAssertFalse(board.isDark)
        board.dark = true; board.strokes = [ink()]
        let loaded = try Studio.decode(JSONEncoder().encode(board))
        XCTAssertTrue(loaded.isDark)
        XCTAssertEqual(loaded.strokes[0].color, [0,0,0,1])
    }
    func testOnlyBlackAndOriginalDefaultAreRemapped() {
        XCTAssertTrue(Renderer.isBlack([0,0,0]))
        XCTAssertTrue(Renderer.isBlack([0.12,0.16,0.23]))
        for c in [[1.0,0,0], [0,0,1], [0.2,0.2,0.2], [1,1,1], [0.05,0.1,0.2]] {
            XCTAssertFalse(Renderer.isBlack(c))
        }
    }
    func testClearUndoRedoPreservesThemeAndCanBeUndoneAsOneAction() throws {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("Recovery.slate")
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        let studio = Studio(recoveryURL: path)
        studio.setDark(true); studio.finish(ink()); studio.finish(ink([1,0,0,1]))
        studio.clearBoard(); XCTAssertTrue(studio.board.strokes.isEmpty); XCTAssertTrue(studio.board.isDark)
        studio.undo(); XCTAssertEqual(studio.board.strokes.count, 2)
        studio.redo(); XCTAssertTrue(studio.board.strokes.isEmpty)
        studio.undo(); studio.undo(); XCTAssertEqual(studio.board.strokes.count, 1)
        studio.finish(ink()); XCTAssertTrue(studio.redoHistory.isEmpty)
        studio.flush()
        XCTAssertTrue(try Studio.decode(Data(contentsOf: path)).isDark)
    }
    func testAppearanceChangesSupportUndoAndRedo() throws {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("Recovery.slate")
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        let studio = Studio(recoveryURL: path)
        studio.setDark(true); studio.setGrid(false)
        XCTAssertTrue(studio.board.isDark); XCTAssertFalse(studio.board.grid)
        studio.undo(); XCTAssertTrue(studio.board.grid)
        studio.undo(); XCTAssertFalse(studio.board.isDark)
        studio.redo(); studio.redo()
        XCTAssertTrue(studio.board.isDark); XCTAssertFalse(studio.board.grid)
    }
    func testImagePersistenceAndLegacyCompatibility() throws {
        let png = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M/wHwAF/gL+3MxZ5wAAAABJRU5ErkJggg==")!
        var board = Board()
        let image = BoardImage(png: png, x: 12, y: 34, width: 100, height: 100)
        board.images = [image]
        let decoded = try Studio.decode(JSONEncoder().encode(board))
        XCTAssertEqual(decoded.boardImages.count, 1)
        XCTAssertEqual(decoded.boardImages[0].id, image.id)
        XCTAssertEqual(decoded.boardImages[0].rect, image.rect)
    }
    func testImageMoveUndoRedoAndClear() throws {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("Recovery.slate")
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        let studio = Studio(recoveryURL: path)
        let image = BoardImage(png: Data(), x: 10, y: 20, width: 100, height: 80)
        studio.board.images = [image]
        let before = image.rect, after = CGRect(x: 50, y: 60, width: 200, height: 160)
        studio.updateImage(image.id, rect: after)
        studio.undoHistory.append(.moveImage(id: image.id, before: before, after: after))
        studio.undo(); XCTAssertEqual(studio.board.boardImages[0].rect, before)
        studio.redo(); XCTAssertEqual(studio.board.boardImages[0].rect, after)
        studio.clearBoard(); XCTAssertTrue(studio.board.boardImages.isEmpty)
        studio.undo(); XCTAssertEqual(studio.board.boardImages[0].id, image.id)
    }
    func testDeletingAnImageRestoresItsOriginalLayerOrder() throws {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("Recovery.slate")
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        let studio = Studio(recoveryURL: path)
        let first = BoardImage(png: Data(), x: 0, y: 0, width: 20, height: 20)
        let middle = BoardImage(png: Data(), x: 10, y: 10, width: 20, height: 20)
        let last = BoardImage(png: Data(), x: 20, y: 20, width: 20, height: 20)
        studio.board.images = [first, middle, last]
        studio.board.images!.remove(at: 1)
        studio.undoHistory.append(.removeImage(middle, index: 1))
        studio.undo()
        XCTAssertEqual(studio.board.boardImages.map(\.id), [first.id, middle.id, last.id])
        studio.redo()
        XCTAssertEqual(studio.board.boardImages.map(\.id), [first.id, last.id])
    }
    func testDirtyStateTracksEditsAndNamedSaveState() throws {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("Recovery.slate")
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        let studio = Studio(recoveryURL: path)
        XCTAssertFalse(studio.isDirty)
        studio.finish(ink())
        XCTAssertTrue(studio.isDirty)
        studio.isDirty = false
        studio.undo()
        XCTAssertTrue(studio.isDirty)
    }
    func testSmoothingContinuityAndFreshStroke() {
        var smoother = StrokeSmoother(Sample(x: 0, y: 0, pressure: 1))
        let points = smoother.add(Sample(x: 20, y: 0, pressure: 0.1))
        XCTAssertEqual(points.last!.x, 10, accuracy: 0.001)
        XCTAssertTrue(points.allSatisfy { $0.y == 0 && $0.pressure > 0.1 })
        XCTAssertEqual(smoother.previous.x, 20) // commit flushes this exact endpoint
        var fresh = StrokeSmoother(Sample(x: 500, y: 300, pressure: 0.5))
        XCTAssertTrue(fresh.add(Sample(x: 502, y: 300, pressure: 0.5)).allSatisfy { $0.x >= 500 && $0.y == 300 })
    }
    func rendered(_ board: Board, cached: Bool) throws -> [UInt8] {
        let ctx = try XCTUnwrap(CGContext(data: nil, width: 2400, height: 1600, bitsPerComponent: 8, bytesPerRow: 2400*4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue))
        ctx.translateBy(x: 0, y: 1600); ctx.scaleBy(x: 1, y: -1)
        if cached {
            let layer = try XCTUnwrap(CGLayer(ctx, size: board.size, auxiliaryInfo: nil))
            let cache = try XCTUnwrap(layer.context)
            for stroke in board.strokes { Renderer.stroke(stroke, dark: board.isDark, in: cache) }
            Renderer.paper(board, in: ctx)
            ctx.draw(layer, at: .zero)
        } else { Renderer.board(board, active: nil, in: ctx) }
        return Array(UnsafeBufferPointer(start: try XCTUnwrap(ctx.data).assumingMemoryBound(to: UInt8.self), count: 2400*1600*4))
    }
    func testRenderingThemeErasureAndCacheParity() throws {
        var board = Board(); board.grid = false
        board.strokes = [ink(), ink([1,0,0,1], x: 300), ink(tool: .eraser, x: 150)]
        let light = try rendered(board, cached: false)
        board.dark = true
        let dark = try rendered(board, cached: false)
        let cache = try rendered(board, cached: true)
        func pixel(_ data: [UInt8], _ x: Int, _ y: Int) -> [UInt8] {
            // Bitmap memory starts with the top row, which is board y = 0 after the flip above.
            let i = (y*2400+x)*4
            return Array(data[i..<i+3])
        }
        XCTAssertEqual(pixel(light, 120, 100), [0,0,0])
        XCTAssertEqual(pixel(dark, 120, 100), [255,255,255])
        XCTAssertEqual(pixel(light, 330, 100), pixel(dark, 330, 100))
        XCTAssertEqual(pixel(dark, 180, 100), [0,0,0])
        XCTAssertEqual(pixel(light, 180, 100), [255,255,255])
        // Same orientation, colors and erasing in the interactive cache and exported image.
        for x in [120, 180, 330, 500] { XCTAssertEqual(pixel(cache, x, 100), pixel(dark, x, 100)) }
    }
    func temporaryStudio() -> (Studio, URL) {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("Recovery.slate")
        return (Studio(recoveryURL: path), path)
    }
    func testToolsRememberTheirOwnSizes() throws {
        let (studio, path) = temporaryStudio()
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        XCTAssertEqual(studio.width, 4)
        studio.select(.chisel); XCTAssertEqual(studio.width, 12)
        studio.width = 20
        studio.select(.pen); XCTAssertEqual(studio.width, 4)
        studio.width = 9
        studio.select(.select); XCTAssertEqual(studio.width, 9)
        studio.select(.chisel); XCTAssertEqual(studio.width, 20)
        studio.select(.pen); XCTAssertEqual(studio.width, 9)
        studio.select(.highlighter); XCTAssertEqual(studio.width, 28)
        studio.select(.eraser); XCTAssertEqual(studio.width, 36)
    }
    func testBracketKeysStepTheSize() {
        XCTAssertEqual(Studio.steppedWidth(4, 1), 5)
        XCTAssertEqual(Studio.steppedWidth(10, 1), 12)
        XCTAssertEqual(Studio.steppedWidth(30, 1), 34)
        XCTAssertEqual(Studio.steppedWidth(30, -1), 26)
        XCTAssertEqual(Studio.steppedWidth(1, -1), 1)
        XCTAssertEqual(Studio.steppedWidth(60, 1), 60)
    }
    func testZoomIsClamped() throws {
        let (studio, path) = temporaryStudio()
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        studio.setZoom(100); XCTAssertEqual(studio.zoom, Studio.maxZoom)
        studio.setZoom(0); XCTAssertEqual(studio.zoom, Studio.minZoom)
        studio.setZoom(1); studio.zoomIn(); XCTAssertEqual(studio.zoom, 1.25, accuracy: 0.0001)
        studio.zoomOut(); XCTAssertEqual(studio.zoom, 1, accuracy: 0.0001)
    }
    func testNudgingAnImageStaysOnTheBoardAndUndoes() throws {
        let (studio, path) = temporaryStudio()
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        let image = BoardImage(png: Data(), x: 5, y: 20, width: 100, height: 80)
        studio.board.images = [image]
        XCTAssertTrue(studio.nudgeImage(image.id, dx: 10, dy: -1))
        XCTAssertEqual(studio.board.boardImages[0].rect, CGRect(x: 15, y: 19, width: 100, height: 80))
        XCTAssertTrue(studio.nudgeImage(image.id, dx: -50, dy: 0))
        XCTAssertEqual(studio.board.boardImages[0].rect.minX, 0)
        XCTAssertFalse(studio.nudgeImage(image.id, dx: -1, dy: 0), "An image at the edge cannot move further")
        studio.undo(); studio.undo()
        XCTAssertEqual(studio.board.boardImages[0].rect, image.rect)
        XCTAssertTrue(studio.isDirty)
    }
    func testStraightLinesUseTheStrokeEndsAndEvenPressure() {
        let line = Renderer.straightLine(from: Sample(x: 10, y: 20, pressure: 0.2), to: Sample(x: 300, y: 40, pressure: 0.9), pressure: 0.5)
        XCTAssertEqual(line.count, 2)
        XCTAssertEqual(line[0].x, 10); XCTAssertEqual(line[0].y, 20)
        XCTAssertEqual(line[1].x, 300); XCTAssertEqual(line[1].y, 40)
        XCTAssertTrue(line.allSatisfy { $0.pressure == 0.5 })
        let ink = Ink(tool: .pen, color: [0,0,0,1], width: 10, angle: 0, samples: line)
        XCTAssertTrue(Renderer.bounds(ink).contains(CGPoint(x: 10, y: 20)))
        XCTAssertTrue(Renderer.bounds(ink).contains(CGPoint(x: 300, y: 40)))
    }
    func testEmptyRecoveryIsNotReportedAsUnsavedWork() throws {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("Recovery.slate")
        defer { try? FileManager.default.removeItem(at: path.deletingLastPathComponent()) }
        let first = Studio(recoveryURL: path)
        first.flush()
        let blank = Studio(recoveryURL: path)
        XCTAssertFalse(blank.isDirty)
        XCTAssertEqual(blank.name, "Untitled board")
        blank.finish(ink()); blank.flush()
        let recovered = Studio(recoveryURL: path)
        XCTAssertTrue(recovered.isDirty)
        XCTAssertEqual(recovered.name, "Recovered board")
        XCTAssertEqual(recovered.board.strokes.count, 1)
    }
    func testNewAndLegacyCanvasSizes() throws {
        XCTAssertEqual(Board.blank.size, CGSize(width: 4096, height: 4096))
        let old = Data(#"{"version":1,"strokes":[],"grid":true}"#.utf8)
        XCTAssertEqual(try Studio.decode(old).size, CGSize(width: 2400, height: 1600))
        var resized = Board.blank; resized.canvasWidth = 3000; resized.canvasHeight = 2048
        let decoded = try Studio.decode(JSONEncoder().encode(resized))
        XCTAssertEqual(decoded.size, CGSize(width: 3000, height: 2048))
    }
}
