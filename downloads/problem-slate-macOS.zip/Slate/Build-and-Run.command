#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
trap 'printf "\nBuild failed. See the message above. Press Return to close."; read -r' ERR
if [[ "$(uname -s)" != Darwin ]]; then
  echo "Build this native app on a Mac running macOS 13 or later."
  exit 1
fi
if ! xcrun --find swift >/dev/null 2>&1; then
  echo "Install Apple's Command Line Tools with: xcode-select --install"
  echo "After installation finishes, run this launcher again."
  exit 1
fi
swift build -c release
BIN_DIR="$(swift build -c release --show-bin-path)"
APP="$PWD/dist/problem-slate.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN_DIR/Slate" "$APP/Contents/MacOS/problem-slate"
cp scripts/Info.plist "$APP/Contents/Info.plist"
iconutil -c icns Assets/problem-slate.iconset -o "$APP/Contents/Resources/problem-slate.icns"
codesign --force --deep --sign - "$APP"
echo "Built: $APP"
echo "You can drag problem-slate.app from dist into Applications."
open "$APP"
