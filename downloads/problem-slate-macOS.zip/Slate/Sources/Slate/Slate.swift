import SwiftUI
import AppKit
import UniformTypeIdentifiers

enum Tool: String, Codable, CaseIterable {
    case select = "Select", pan = "Pan", pen = "Pen", chisel = "Chisel", highlighter = "Highlighter", eraser = "Eraser"
    var icon: String { switch self { case .select: return "arrow.up.left.and.arrow.down.right"; case .pan: return "hand.draw"; case .pen: return "pencil.tip"; case .chisel: return "paintbrush.pointed"; case .highlighter: return "highlighter"; case .eraser: return "eraser" } }
    var key: KeyEquivalent { switch self { case .select: return "v"; case .pan: return "m"; case .pen: return "p"; case .chisel: return "c"; case .highlighter: return "h"; case .eraser: return "e" } }
    var help: String {
        switch self {
        case .select: return "Select, move and resize images (V)"
        case .pan: return "Pan around the board (M, or hold Space)"
        case .pen: return "Round, pressure-sensitive pen (P)"
        case .chisel: return "Angled calligraphy nib (C)"
        case .highlighter: return "Translucent highlighter (H)"
        case .eraser: return "Erase parts of strokes (E)"
        }
    }
    var hint: String {
        switch self {
        case .select: return "Click an image to select · drag its corner to resize · arrow keys nudge"
        case .pan: return "Drag to move around the board"
        case .eraser: return "Erases ink only; images stay · [ ] change size"
        default: return "Hold ⇧ for a straight line · Space to pan · [ ] change size"
        }
    }
}
struct Sample: Codable { var x: Double; var y: Double; var pressure: Double }
struct Ink: Codable { var tool: Tool; var color: [Double]; var width: Double; var angle: Double; var samples: [Sample] }
struct BoardImage: Codable, Identifiable {
    var id = UUID()
    var png: Data
    var x: Double
    var y: Double
    var width: Double
    var height: Double
    var rect: CGRect { CGRect(x: x, y: y, width: width, height: height) }
}
struct Board: Codable {
    var version = 1
    var strokes: [Ink] = []
    var grid = true
    // Optional for backward-compatible decoding of version 1 boards.
    var dark: Bool? = nil
    // Optional so boards saved by Slate 1.0/1.1 continue to open.
    var images: [BoardImage]? = nil
    // Missing dimensions identify boards created before adjustable canvases.
    var canvasWidth: Double? = nil
    var canvasHeight: Double? = nil
    var isDark: Bool { dark ?? false }
    var boardImages: [BoardImage] { images ?? [] }
    var size: CGSize { CGSize(width: canvasWidth ?? 2400, height: canvasHeight ?? 1600) }
    var isEmpty: Bool { strokes.isEmpty && boardImages.isEmpty }
    static var blank: Board {
        var board = Board(); board.canvasWidth = 4096; board.canvasHeight = 4096
        return board
    }
}
enum Edit {
    case stroke(Ink)
    case clear(strokes: [Ink], images: [BoardImage])
    case addImage(BoardImage)
    case removeImage(BoardImage, index: Int)
    case moveImage(id: UUID, before: CGRect, after: CGRect)
    case resizeCanvas(before: CGSize, after: CGSize)
    case dark(before: Bool, after: Bool)
    case grid(before: Bool, after: Bool)
}

final class Studio: ObservableObject {
    static let defaultWidths: [Tool: Double] = [.pen: 4, .chisel: 12, .highlighter: 28, .eraser: 36]
    static let minZoom: CGFloat = 0.1, maxZoom: CGFloat = 4
    static let readyStatus = "Mouse / trackpad · tablet ready"
    @Published var tool: Tool = .pen
    @Published var color: Color = .black
    /// Index of the selected palette swatch, or nil for a custom color.
    @Published var swatch: Int? = 0
    @Published var width: Double = 4
    @Published var angle: Double = 40
    @Published var pressure = true
    @Published var board = Board.blank
    @Published var undoHistory: [Edit] = []
    @Published var redoHistory: [Edit] = []
    @Published var inputStatus = Studio.readyStatus
    @Published var name = "Untitled board"
    @Published var isDirty = false
    @Published var zoom: CGFloat = 1
    /// Each drawing tool remembers its own size, so switching tools never loses a chosen width.
    var toolWidths = Studio.defaultWidths
    var url: URL?
    weak var canvas: Canvas?
    var pendingSave: DispatchWorkItem?
    let saveQueue = DispatchQueue(label: "app.madhup.slate.recovery", qos: .utility)
    let recovery: URL
    init(recoveryURL: URL? = nil) {
        let base = recoveryURL?.deletingLastPathComponent() ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Slate", isDirectory: true)
        recovery = recoveryURL ?? base.appendingPathComponent("Recovery.slate")
        do {
            try FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: recovery.path) {
                board = try Self.loadBoard(from: recovery)
                undoHistory = board.strokes.map { .stroke($0) }
                // An empty recovered board is simply a fresh board: only flag real work as unsaved.
                if !board.isEmpty { isDirty = true; name = "Recovered board" }
            }
        } catch { inputStatus = "Recovery unavailable: \(error.localizedDescription)" }
    }
    static let maximumBoardBytes = 160_000_000
    static func loadBoard(from url: URL) throws -> Board {
        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size <= maximumBoardBytes else {
            throw NSError(domain: "Slate", code: 2, userInfo: [NSLocalizedDescriptionKey: "This board is larger than the 160 MB limit."])
        }
        return try decode(Data(contentsOf: url))
    }
    static func encode(_ board: Board) throws -> Data {
        let data = try JSONEncoder().encode(board)
        guard data.count <= maximumBoardBytes else {
            throw NSError(domain: "Slate", code: 3, userInfo: [NSLocalizedDescriptionKey: "This board is larger than the 160 MB limit."])
        }
        return data
    }
    static func validImageData(_ data: Data) -> Bool {
        guard let image = NSImage(data: data), let source = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return false }
        return Int64(source.width) * Int64(source.height) <= 32_000_000
    }
    static func decode(_ data: Data) throws -> Board {
        let value = try JSONDecoder().decode(Board.self, from: data)
        guard value.version == 1, value.strokes.allSatisfy({ s in
            s.color.count == 4 && s.color.allSatisfy { $0.isFinite && (0...1).contains($0) } && s.width.isFinite && (0.5...100).contains(s.width) && s.angle.isFinite && s.samples.allSatisfy { $0.x.isFinite && $0.y.isFinite && $0.pressure.isFinite && (0...1).contains($0.pressure) }
        }), (512...8192).contains(value.size.width), (512...8192).contains(value.size.height),
              value.boardImages.count <= 100, value.boardImages.reduce(0, { $0 + $1.png.count }) <= 100_000_000,
              value.boardImages.allSatisfy({ image in
                  image.png.count <= 25_000_000 && image.x.isFinite && image.y.isFinite && image.width.isFinite && image.height.isFinite && image.width > 0 && image.height > 0 && image.width <= 8192 && image.height <= 8192 && validImageData(image.png)
              }) else { throw NSError(domain: "Slate", code: 1, userInfo: [NSLocalizedDescriptionKey: "This board has an unsupported format or invalid drawing data."]) }
        return value
    }
    func changed(invalidate: Bool = true, markDirty: Bool = true) {
        if markDirty { isDirty = true }
        if invalidate { canvas?.invalidateInk() }
        pendingSave?.cancel()
        let snapshot = board
        let path = recovery
        let work = DispatchWorkItem { [weak self] in
            do { try Self.encode(snapshot).write(to: path, options: .atomic) }
            catch { DispatchQueue.main.async { self?.inputStatus = "Autosave failed — use Save" } }
        }
        pendingSave = work
        saveQueue.asyncAfter(deadline: .now() + 0.4, execute: work)
    }
    func flush() {
        pendingSave?.cancel()
        do { try saveQueue.sync { try Self.encode(board).write(to: recovery, options: .atomic) } } catch { show(error) }
    }
    func finish(_ ink: Ink) {
        board.strokes.append(ink); undoHistory.append(.stroke(ink)); redoHistory.removeAll()
        canvas?.cacheFinished(ink)
        changed(invalidate: false)
    }

    // MARK: Tools, size and zoom
    func select(_ next: Tool) {
        canvas?.commit()
        if toolWidths[tool] != nil { toolWidths[tool] = width }
        tool = next
        if let remembered = toolWidths[next] { width = remembered }
        canvas?.refreshCursor()
    }
    func choose(color value: Color, swatch index: Int?) { color = value; swatch = index }
    static func steppedWidth(_ value: Double, _ direction: Int) -> Double {
        let step: Double = value < 10 ? 1 : value < 30 ? 2 : 4
        return min(60, max(1, value.rounded() + step * Double(direction)))
    }
    func stepWidth(_ direction: Int) { width = Self.steppedWidth(width, direction); canvas?.refreshCursor() }
    func setZoom(_ value: CGFloat) { zoom = min(Self.maxZoom, max(Self.minZoom, value)) }
    func zoomIn() { setZoom(zoom * 1.25) }
    func zoomOut() { setZoom(zoom / 1.25) }
    func zoomToFit() { if let fit = canvas?.fitZoom() { setZoom(fit) } }

    // MARK: Editing
    func undo() {
        canvas?.commit()
        guard let edit = undoHistory.popLast() else { return }
        switch edit {
        case .stroke: if !board.strokes.isEmpty { board.strokes.removeLast() }
        case .clear(let strokes, let images): board.strokes = strokes; board.images = images
        case .addImage(let image): board.images?.removeAll { $0.id == image.id }
        case .removeImage(let image, let index):
            var images = board.boardImages
            images.insert(image, at: min(index, images.count))
            board.images = images
        case .moveImage(let id, let before, _): updateImage(id, rect: before)
        case .resizeCanvas(let before, _): applyCanvasSize(before)
        case .dark(let before, _): board.dark = before
        case .grid(let before, _): board.grid = before
        }
        if let selected = canvas?.selectedImageID, !board.boardImages.contains(where: { $0.id == selected }) { canvas?.selectedImageID = nil }
        redoHistory.append(edit); changed()
    }
    func redo() {
        canvas?.commit()
        guard let edit = redoHistory.popLast() else { return }
        switch edit {
        case .stroke(let ink): board.strokes.append(ink)
        case .clear: board.strokes.removeAll(); board.images = []
        case .addImage(let image): board.images = board.boardImages + [image]
        case .removeImage(let image, _): board.images?.removeAll { $0.id == image.id }
        case .moveImage(let id, _, let after): updateImage(id, rect: after)
        case .resizeCanvas(_, let after): applyCanvasSize(after)
        case .dark(_, let after): board.dark = after
        case .grid(_, let after): board.grid = after
        }
        if let selected = canvas?.selectedImageID, !board.boardImages.contains(where: { $0.id == selected }) { canvas?.selectedImageID = nil }
        undoHistory.append(edit); changed()
    }
    func clearBoard() {
        canvas?.commit()
        guard !board.isEmpty else { return }
        undoHistory.append(.clear(strokes: board.strokes, images: board.boardImages)); redoHistory.removeAll()
        board.strokes.removeAll(); board.images = []; canvas?.selectedImageID = nil; changed()
    }
    func updateImage(_ id: UUID, rect: CGRect) {
        guard let index = board.images?.firstIndex(where: { $0.id == id }) else { return }
        board.images![index].x = rect.minX; board.images![index].y = rect.minY
        board.images![index].width = rect.width; board.images![index].height = rect.height
    }
    /// Moves an image by a small offset, keeping it on the board. Returns false when nothing moved.
    @discardableResult func nudgeImage(_ id: UUID, dx: Double, dy: Double) -> Bool {
        guard let image = board.boardImages.first(where: { $0.id == id }) else { return false }
        let before = image.rect
        var after = before.offsetBy(dx: dx, dy: dy)
        after.origin.x = min(max(0, board.size.width - after.width), max(0, after.origin.x))
        after.origin.y = min(max(0, board.size.height - after.height), max(0, after.origin.y))
        guard after != before else { return false }
        updateImage(id, rect: after)
        undoHistory.append(.moveImage(id: id, before: before, after: after)); redoHistory.removeAll()
        changed(invalidate: false)
        return true
    }
    func pasteImage() { canvas?.pasteImage() }
    func deleteSelection() { canvas?.deleteSelection() }
    func applyCanvasSize(_ size: CGSize) {
        board.canvasWidth = size.width; board.canvasHeight = size.height
        canvas?.resizeToBoard()
    }
    func chooseCanvasSize() {
        canvas?.commit()
        let alert = NSAlert(); alert.messageText = "Canvas size"
        alert.informativeText = "Choose a width and height from 512 to 8192 pixels. Content outside a smaller canvas stays saved but will be hidden."
        let widthField = NSTextField(string: String(Int(board.size.width)))
        let heightField = NSTextField(string: String(Int(board.size.height)))
        widthField.alignment = .right; heightField.alignment = .right
        let row = NSStackView(views: [NSTextField(labelWithString: "Width"), widthField, NSTextField(labelWithString: "Height"), heightField])
        row.spacing = 8; row.frame = NSRect(x: 0, y: 0, width: 310, height: 26)
        alert.accessoryView = row; alert.addButton(withTitle: "Resize"); alert.addButton(withTitle: "Cancel")
        guard alert.runModal() == .alertFirstButtonReturn,
              let width = Double(widthField.stringValue), let height = Double(heightField.stringValue),
              (512...8192).contains(width), (512...8192).contains(height) else { return }
        let before = board.size, after = CGSize(width: width.rounded(), height: height.rounded())
        guard before != after else { return }
        applyCanvasSize(after); undoHistory.append(.resizeCanvas(before: before, after: after)); redoHistory.removeAll(); changed()
    }
    func setDark(_ dark: Bool) {
        canvas?.commit()
        let before = board.isDark
        guard before != dark else { return }
        board.dark = dark; undoHistory.append(.dark(before: before, after: dark)); redoHistory.removeAll(); changed()
    }
    func setGrid(_ grid: Bool) {
        canvas?.commit()
        let before = board.grid
        guard before != grid else { return }
        board.grid = grid; undoHistory.append(.grid(before: before, after: grid)); redoHistory.removeAll(); changed()
    }
    func displayedColor(_ color: Color) -> Color {
        let rgb = NSColor(color).usingColorSpace(.deviceRGB) ?? .black
        return board.isDark && Renderer.isBlack([rgb.redComponent, rgb.greenComponent, rgb.blueComponent]) ? .white : color
    }

    // MARK: Files
    func show(_ error: Error) { NSAlert(error: error).runModal() }
    @discardableResult func save(asCopy: Bool = false) -> Bool {
        canvas?.commit()
        var target = url
        if target == nil || asCopy {
            let panel = NSSavePanel(); panel.nameFieldStringValue = name + ".slate"
            panel.allowedContentTypes = [UTType(filenameExtension: "slate") ?? .data]
            guard panel.runModal() == .OK else { return false }; target = panel.url
        }
        guard let target else { return false }
        do {
            let data = try Self.encode(board)
            try data.write(to: target, options: .atomic)
            url = target; name = target.deletingPathExtension().lastPathComponent; isDirty = false
            inputStatus = "Board saved"
            return true
        } catch { show(error); return false }
    }
    func confirmReplace() -> Bool {
        guard isDirty else { return true }
        let alert = NSAlert(); alert.messageText = "Save this board before continuing?"
        alert.informativeText = "Your latest changes have not been saved to a named .slate file."
        alert.addButton(withTitle: "Save"); alert.addButton(withTitle: "Discard"); alert.addButton(withTitle: "Cancel")
        switch alert.runModal() {
        case .alertFirstButtonReturn: return save()
        case .alertSecondButtonReturn: return true
        default: return false
        }
    }
    func newBoard() {
        canvas?.commit(); guard confirmReplace() else { return }
        board = Board.blank; undoHistory = []; redoHistory = []; url = nil; name = "Untitled board"; isDirty = false; zoom = 1
        canvas?.selectedImageID = nil; canvas?.resizeToBoard(); changed(markDirty: false)
    }
    func open() {
        canvas?.commit()
        let panel = NSOpenPanel(); panel.allowedContentTypes = [UTType(filenameExtension: "slate") ?? .data]; panel.allowsMultipleSelection = false
        guard panel.runModal() == .OK, let target = panel.url else { return }
        do {
            let incoming = try Self.loadBoard(from: target)
            guard confirmReplace() else { return }
            // A freshly opened file starts a new history, so undo cannot remove the saved content.
            board = incoming; undoHistory = []; redoHistory = []; url = target; name = target.deletingPathExtension().lastPathComponent; isDirty = false
            canvas?.selectedImageID = nil; canvas?.resizeToBoard(); changed(markDirty: false)
        } catch { show(error) }
    }
    /// Renders the whole board, at its full pixel size, as PNG data.
    func renderPNG() -> Data? {
        let exportWidth = Int(board.size.width), exportHeight = Int(board.size.height)
        guard let ctx = CGContext(data: nil, width: exportWidth, height: exportHeight, bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        ctx.translateBy(x: 0, y: CGFloat(exportHeight)); ctx.scaleBy(x: 1, y: -1)
        Renderer.board(board, active: nil, in: ctx)
        guard let image = ctx.makeImage() else { return nil }
        return NSBitmapImageRep(cgImage: image).representation(using: .png, properties: [:])
    }
    func export() {
        canvas?.commit()
        let panel = NSSavePanel(); panel.allowedContentTypes = [.png]; panel.nameFieldStringValue = name + ".png"
        guard panel.runModal() == .OK, let target = panel.url else { return }
        guard let data = renderPNG() else { NSSound.beep(); return }
        do { try data.write(to: target, options: .atomic); inputStatus = "PNG exported" } catch { show(error) }
    }
    func copyImage() {
        canvas?.commit()
        guard let data = renderPNG() else { NSSound.beep(); return }
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setData(data, forType: .png)
        inputStatus = "Board copied as an image · paste it into any app"
    }
}

enum Renderer {
    static func paper(_ board: Board, in ctx: CGContext, rect: CGRect? = nil) {
        ctx.saveGState()
        let canvas = CGRect(origin: .zero, size: board.size)
        let area = (rect ?? canvas).intersection(canvas)
        guard !area.isNull && !area.isEmpty else { ctx.restoreGState(); return }
        ctx.setFillColor((board.isDark ? NSColor.black : NSColor.white).cgColor); ctx.fill(area)
        if board.grid {
            ctx.setFillColor(NSColor(calibratedWhite: board.isDark ? 0.4 : 0, alpha: 1).cgColor)
            let startX = max(12, Int((area.minX - 12) / 24) * 24 + 12), endX = min(Int(board.size.width), Int(area.maxX) + 24)
            let startY = max(12, Int((area.minY - 12) / 24) * 24 + 12), endY = min(Int(board.size.height), Int(area.maxY) + 24)
            for x in stride(from: startX, to: endX, by: 24) { for y in stride(from: startY, to: endY, by: 24) { ctx.fillEllipse(in: CGRect(x: CGFloat(x), y: CGFloat(y), width: 1.5, height: 1.5)) } }
        }
        ctx.restoreGState()
    }
    static func board(_ board: Board, active: Ink?, in ctx: CGContext) {
        paper(board, in: ctx)
        images(board.boardImages, in: ctx)
        ctx.saveGState(); ctx.beginTransparencyLayer(auxiliaryInfo: nil)
        for ink in board.strokes { stroke(ink, dark: board.isDark, in: ctx) }
        if let active { stroke(active, dark: board.isDark, in: ctx) }
        ctx.endTransparencyLayer(); ctx.restoreGState()
    }
    static func images(_ images: [BoardImage], in ctx: CGContext) {
        for item in images {
            guard let source = NSImage(data: item.png), let cg = source.cgImage(forProposedRect: nil, context: nil, hints: nil) else { continue }
            ctx.saveGState()
            ctx.translateBy(x: item.x, y: item.y + item.height)
            ctx.scaleBy(x: 1, y: -1)
            ctx.interpolationQuality = .high
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: item.width, height: item.height))
            ctx.restoreGState()
        }
    }
    static func isBlack(_ color: [Double]) -> Bool {
        guard color.count >= 3 else { return false }
        let black = color.prefix(3).allSatisfy { abs($0) < 0.00001 }
        // The original app's default black was this exact blue-black swatch.
        let legacy = abs(color[0]-0.12) < 0.002 && abs(color[1]-0.16) < 0.002 && abs(color[2]-0.23) < 0.002
        return black || legacy
    }
    static func stroke(_ ink: Ink, dark: Bool, in ctx: CGContext, path: CGPath? = nil) {
        let shape = path ?? makePath(ink)
        ctx.saveGState()
        ctx.setBlendMode(ink.tool == .eraser ? .clear : .normal)
        ctx.setAlpha(ink.tool == .highlighter ? 0.28 : 1)
        let c = dark && isBlack(ink.color) ? [1.0, 1.0, 1.0] : ink.color
        ctx.setFillColor(CGColor(red: c[0], green: c[1], blue: c[2], alpha: 1))
        ctx.addPath(shape); ctx.fillPath(); ctx.restoreGState()
    }
    static func makePath(_ ink: Ink) -> CGPath {
        let path = CGMutablePath()
        guard let first = ink.samples.first else { return path }
        stamp(first, ink: ink, into: path)
        for (a, b) in zip(ink.samples, ink.samples.dropFirst()) { segment(a, b, ink: ink, into: path) }
        return path
    }
    static func stamp(_ s: Sample, ink: Ink, into path: CGMutablePath) {
        let w = ink.width * (ink.tool == .highlighter || ink.tool == .eraser ? 1 : 0.25 + 0.75 * s.pressure)
        if ink.tool == .chisel || ink.tool == .highlighter {
            let h = w * (ink.tool == .chisel ? 0.22 : 0.48)
            let transform = CGAffineTransform(translationX: s.x, y: s.y).rotated(by: ink.angle * .pi / 180)
            path.addRect(CGRect(x: -w/2, y: -h/2, width: w, height: h), transform: transform)
        } else { path.addEllipse(in: CGRect(x: s.x-w/2, y: s.y-w/2, width: w, height: w)) }
    }
    static func segment(_ a: Sample, _ b: Sample, ink: Ink, into path: CGMutablePath) {
        let distance = hypot(b.x-a.x, b.y-a.y)
        let steps = max(1, Int(ceil(distance / max(0.4, ink.width * 0.025))))
        for i in 1...steps {
            let t = Double(i)/Double(steps)
            stamp(Sample(x: a.x+(b.x-a.x)*t, y: a.y+(b.y-a.y)*t, pressure: a.pressure+(b.pressure-a.pressure)*t), ink: ink, into: path)
        }
    }
    /// Bounding box of a stroke, padded for its nib.
    static func bounds(_ ink: Ink) -> CGRect {
        let xs = ink.samples.map(\.x), ys = ink.samples.map(\.y)
        guard let minX = xs.min(), let maxX = xs.max(), let minY = ys.min(), let maxY = ys.max() else { return .null }
        return CGRect(x: minX, y: minY, width: maxX-minX+1, height: maxY-minY+1).insetBy(dx: -ink.width-4, dy: -ink.width-4)
    }
    /// The two samples of a straight stroke drawn with Shift, at an even pressure.
    static func straightLine(from start: Sample, to end: Sample, pressure: Double) -> [Sample] {
        [Sample(x: start.x, y: start.y, pressure: pressure), Sample(x: end.x, y: end.y, pressure: pressure)]
    }
}

// Online midpoint-quadratic smoothing: no timer or app-focus-dependent state.
struct StrokeSmoother {
    var previous: Sample
    var anchor: Sample
    init(_ first: Sample) { previous = first; anchor = first }
    mutating func add(_ raw: Sample) -> [Sample] {
        let filtered = Sample(x: raw.x, y: raw.y, pressure: previous.pressure * 0.65 + raw.pressure * 0.35)
        let end = Sample(x: (previous.x+filtered.x)/2, y: (previous.y+filtered.y)/2, pressure: (previous.pressure+filtered.pressure)/2)
        let length = hypot(previous.x-anchor.x, previous.y-anchor.y) + hypot(end.x-previous.x, end.y-previous.y)
        let count = max(1, Int(ceil(length / 2)))
        let result = (1...count).map { i -> Sample in
            let t = Double(i)/Double(count), u = 1-t
            return Sample(x: u*u*anchor.x+2*u*t*previous.x+t*t*end.x,
                          y: u*u*anchor.y+2*u*t*previous.y+t*t*end.y,
                          pressure: anchor.pressure+(end.pressure-anchor.pressure)*t)
        }
        previous = filtered; anchor = end
        return result
    }
}

final class Canvas: NSView {
    let studio: Studio
    var active: Ink?
    var activePath = CGMutablePath()
    var smoother: StrokeSmoother?
    var straight = false
    var straightPressure = 1.0
    var inkLayer: CGLayer?
    var penNear = false
    var eraserEnd = false
    var spacePan = false
    var monitor: Any?
    var observers: [NSObjectProtocol] = []
    var lastTimestamp: TimeInterval = -1
    var lastStatusTime: TimeInterval = -1
    var selectedImageID: UUID?
    var imageStartRect: CGRect?
    var imageStartPoint: CGPoint?
    var resizingImage = false
    var panStartPoint: CGPoint?
    var panStartOrigin: CGPoint?
    var pendingInkRefresh: DispatchWorkItem?
    var cursorKey = ""
    override var isFlipped: Bool { true }
    override var acceptsFirstResponder: Bool { true }
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
    init(studio: Studio) {
        self.studio = studio; super.init(frame: CGRect(origin: .zero, size: studio.board.size)); studio.canvas = self
        registerForDraggedTypes([.fileURL, .png, .tiff])
        monitor = NSEvent.addLocalMonitorForEvents(matching: [.tabletProximity]) { [weak self] event in self?.proximity(event); return event }
        let center = NotificationCenter.default
        observers.append(center.addObserver(forName: NSApplication.willResignActiveNotification, object: nil, queue: .main) { [weak self] _ in self?.resetInput() })
        observers.append(center.addObserver(forName: NSWindow.didResignKeyNotification, object: nil, queue: .main) { [weak self] note in
            guard let self, let window = note.object as? NSWindow, window === self.window else { return }
            self.resetInput()
        })
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    deinit {
        if let monitor { NSEvent.removeMonitor(monitor) }
        for observer in observers { NotificationCenter.default.removeObserver(observer) }
    }
    override func viewDidMoveToWindow() { super.viewDidMoveToWindow(); window?.makeFirstResponder(self) }
    override func viewDidChangeBackingProperties() { super.viewDidChangeBackingProperties(); invalidateInk() }
    func resizeToBoard() {
        setFrameSize(studio.board.size); invalidateInk()
        enclosingScrollView?.contentView.scroll(to: .zero)
        if let scroll = enclosingScrollView { scroll.reflectScrolledClipView(scroll.contentView) }
    }
    func resetInput() {
        commit(); endPan(); penNear = false; eraserEnd = false; spacePan = false; lastTimestamp = -1; lastStatusTime = -1
        studio.inputStatus = Studio.readyStatus; refreshCursor()
    }
    func proximity(_ event: NSEvent) {
        penNear = event.isEnteringProximity
        eraserEnd = penNear && event.pointingDeviceType == .eraser
        studio.inputStatus = penNear ? (eraserEnd ? "Tablet eraser detected" : "Tablet pen detected · pressure ready") : Studio.readyStatus
    }
    override func tabletProximity(with event: NSEvent) { proximity(event) }
    func sample(_ event: NSEvent) -> Sample {
        let location = event.window == nil ? (window?.convertPoint(fromScreen: event.locationInWindow) ?? event.locationInWindow) : event.locationInWindow
        let p = convert(location, from: nil)
        let tablet = event.type == .tabletPoint || event.subtype == .tabletPoint
        if tablet && event.timestamp-lastStatusTime > 0.2 {
            studio.inputStatus = "Tablet pen · pressure \(Int(event.pressure * 100))%"
            lastStatusTime = event.timestamp
        }
        let force = tablet && studio.pressure ? max(0.01, min(1, Double(event.pressure))) : 1
        return Sample(x: min(studio.board.size.width, max(0, p.x)), y: min(studio.board.size.height, max(0, p.y)), pressure: force)
    }

    // MARK: Pointer input
    override func mouseDown(with event: NSEvent) {
        commit(); window?.makeFirstResponder(self)
        if studio.tool == .pan || spacePan { beginPan(event); return }
        if studio.tool == .select {
            beginImageInteraction(at: convert(event.locationInWindow, from: nil))
            return
        }
        // A fresh stroke always starts with fresh timing and smoothing state.
        lastTimestamp = event.timestamp; lastStatusTime = -1; straight = false
        if event.subtype != .tabletPoint { eraserEnd = false }
        let color = NSColor(studio.color).usingColorSpace(.deviceRGB) ?? .black
        let tool = eraserEnd ? Tool.eraser : studio.tool
        let first = sample(event)
        let ink = Ink(tool: tool, color: [color.redComponent, color.greenComponent, color.blueComponent, 1], width: tool == .eraser ? max(20, studio.width) : studio.width, angle: studio.angle, samples: [first])
        active = ink; activePath = CGMutablePath(); smoother = StrokeSmoother(first)
        Renderer.stamp(first, ink: ink, into: activePath)
        setNeedsDisplay(CGRect(x: first.x, y: first.y, width: 1, height: 1).insetBy(dx: -ink.width-4, dy: -ink.width-4))
    }
    override func mouseDragged(with event: NSEvent) {
        if panStartPoint != nil { pan(to: event.locationInWindow); return }
        if studio.tool == .select { dragImage(to: convert(event.locationInWindow, from: nil)); return }
        append(event)
    }
    override func mouseUp(with event: NSEvent) {
        if panStartPoint != nil { endPan(); return }
        if studio.tool == .select { finishImageInteraction(); return }
        append(event, lifting: true); commit()
    }
    // The middle mouse button pans with any tool.
    override func otherMouseDown(with event: NSEvent) { commit(); beginPan(event) }
    override func otherMouseDragged(with event: NSEvent) { pan(to: event.locationInWindow) }
    override func otherMouseUp(with event: NSEvent) { endPan() }
    override func tabletPoint(with event: NSEvent) { if active != nil && event.pressure > 0 { append(event) } }
    func append(_ event: NSEvent, lifting: Bool = false) {
        guard active != nil, event.timestamp > lastTimestamp else { return }
        lastTimestamp = event.timestamp
        var s = sample(event)
        // Lift-off events often report zero pressure; do not punch a thin notch into the endpoint.
        if lifting { s.pressure = smoother?.previous.pressure ?? s.pressure }
        if straight || event.modifierFlags.contains(.shift) { drawStraight(to: s); return }
        if let last = smoother?.previous, hypot(last.x-s.x, last.y-s.y) < 0.15 { return }
        let points = smoother?.add(s) ?? [s]
        for point in points { addPoint(point) }
        if let first = points.first, let last = points.last, let ink = active {
            let area = CGRect(x: min(first.x,last.x), y: min(first.y,last.y), width: abs(last.x-first.x)+1, height: abs(last.y-first.y)+1)
            setNeedsDisplay(area.insetBy(dx: -ink.width-4, dy: -ink.width-4))
        }
    }
    /// Holding Shift turns the current stroke into a straight line from where it started.
    func drawStraight(to end: Sample) {
        guard var ink = active, let first = ink.samples.first else { return }
        let previous = Renderer.bounds(ink)
        if !straight {
            straight = true; smoother = nil
            straightPressure = ink.samples.map(\.pressure).reduce(0, +) / Double(ink.samples.count)
        }
        ink.samples = Renderer.straightLine(from: first, to: end, pressure: straightPressure)
        active = ink
        activePath = Renderer.makePath(ink).mutableCopy() ?? CGMutablePath()
        setNeedsDisplay(previous.union(Renderer.bounds(ink)))
    }
    func addPoint(_ point: Sample) {
        guard let last = active?.samples.last else { return }
        Renderer.segment(last, point, ink: active!, into: activePath)
        active?.samples.append(point)
    }
    func commit() {
        guard active != nil else { return }
        if let endpoint = smoother?.previous { addPoint(endpoint) }
        if let ink = active {
            let area = Renderer.bounds(ink)
            if !area.isNull { setNeedsDisplay(area) }
            active = nil; smoother = nil; straight = false; studio.finish(ink)
        }
        activePath = CGMutablePath()
    }

    // MARK: Panning and zoom
    func beginPan(_ event: NSEvent) {
        panStartPoint = event.locationInWindow
        panStartOrigin = enclosingScrollView?.contentView.bounds.origin
        NSCursor.closedHand.set()
    }
    func endPan() {
        guard panStartPoint != nil else { return }
        panStartPoint = nil; panStartOrigin = nil
        currentCursor().set()
    }
    func pan(to point: CGPoint) {
        guard let scroll = enclosingScrollView, let start = panStartPoint, let origin = panStartOrigin else { return }
        let scale = max(scroll.magnification, 0.01)
        var bounds = scroll.contentView.bounds
        bounds.origin = CGPoint(x: origin.x-(point.x-start.x)/scale, y: origin.y+(point.y-start.y)/scale)
        scroll.contentView.scroll(to: scroll.contentView.constrainBoundsRect(bounds).origin)
        scroll.reflectScrolledClipView(scroll.contentView)
    }
    func fitZoom() -> CGFloat? {
        guard let scroll = enclosingScrollView, studio.board.size.width > 0, studio.board.size.height > 0 else { return nil }
        let available = scroll.contentSize
        return min(available.width / studio.board.size.width, available.height / studio.board.size.height) * 0.96
    }
    /// Command-scroll zooms around the pointer; the ink cache is rebuilt once scrolling settles.
    override func scrollWheel(with event: NSEvent) {
        guard event.modifierFlags.contains(.command), let scroll = enclosingScrollView else { super.scrollWheel(with: event); return }
        let delta = event.hasPreciseScrollingDeltas ? event.scrollingDeltaY * 0.01 : event.scrollingDeltaY * 0.1
        let target = min(Studio.maxZoom, max(Studio.minZoom, scroll.magnification * exp(delta)))
        scroll.setMagnification(target, centeredAt: convert(event.locationInWindow, from: nil))
        studio.zoom = scroll.magnification
        scheduleInkRefresh()
    }
    func scheduleInkRefresh() {
        pendingInkRefresh?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.invalidateInk(); self?.refreshCursor() }
        pendingInkRefresh = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: work)
    }

    // MARK: Drawing
    func invalidateInk() { inkLayer = nil; needsDisplay = true }
    func cacheFinished(_ ink: Ink) {
        // Append only the new stroke. Existing geometry is never rebuilt during pen movement.
        if let ctx = inkLayer?.context { Renderer.stroke(ink, dark: studio.board.isDark, in: ctx, path: activePath) }
    }
    override func draw(_ dirtyRect: NSRect) {
        guard let ctx = NSGraphicsContext.current?.cgContext else { return }
        if inkLayer == nil, let layer = CGLayer(ctx, size: studio.board.size, auxiliaryInfo: nil), let cache = layer.context {
            for ink in studio.board.strokes { Renderer.stroke(ink, dark: studio.board.isDark, in: cache) }
            inkLayer = layer
        }
        Renderer.paper(studio.board, in: ctx, rect: dirtyRect)
        Renderer.images(studio.board.boardImages, in: ctx)
        ctx.saveGState(); ctx.beginTransparencyLayer(auxiliaryInfo: nil)
        if let inkLayer { ctx.draw(inkLayer, at: .zero) }
        else { for ink in studio.board.strokes { Renderer.stroke(ink, dark: studio.board.isDark, in: ctx) } }
        if let active { Renderer.stroke(active, dark: studio.board.isDark, in: ctx, path: activePath) }
        ctx.endTransparencyLayer(); ctx.restoreGState()
        drawSelection(in: ctx)
    }

    // MARK: Images
    static func imageFileURLs(_ pasteboard: NSPasteboard) -> [URL] {
        let options: [NSPasteboard.ReadingOptionKey: Any] = [.urlReadingFileURLsOnly: true]
        let urls = (pasteboard.readObjects(forClasses: [NSURL.self], options: options) as? [NSURL])?.map { $0 as URL } ?? []
        return urls.filter { url in UTType(filenameExtension: url.pathExtension)?.conforms(to: .image) ?? false }
    }
    static func holdsImage(_ pasteboard: NSPasteboard) -> Bool {
        !imageFileURLs(pasteboard).isEmpty || pasteboard.data(forType: .png) != nil || pasteboard.data(forType: .tiff) != nil
    }
    func pasteImage() { insertImage(from: NSPasteboard.general, centeredAt: nil) }
    /// Adds the image on a pasteboard to the board, centered on a point or on the visible area.
    @discardableResult func insertImage(from pasteboard: NSPasteboard, centeredAt center: CGPoint?) -> Bool {
        commit()
        var pastedImage: NSImage?
        // Finder exposes a copied file both as a file URL and as its generic icon.
        // Resolve the actual image file before asking AppKit for an NSImage object.
        let urlOptions: [NSPasteboard.ReadingOptionKey: Any] = [.urlReadingFileURLsOnly: true]
        let copiedFileURLs = (pasteboard.readObjects(forClasses: [NSURL.self], options: urlOptions) as? [NSURL])?.map { $0 as URL } ?? []
        if let url = Self.imageFileURLs(pasteboard).first {
            let byteCount = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
            guard byteCount <= 25_000_000 else { studio.inputStatus = "Image is too large (25 MB maximum)"; return false }
            pastedImage = NSImage(contentsOf: url)
        }
        // Screenshots, browser images and pixel selections usually provide PNG/TIFF bytes.
        if copiedFileURLs.isEmpty, pastedImage == nil, let data = pasteboard.data(forType: .png) ?? pasteboard.data(forType: .tiff) {
            guard data.count <= 25_000_000 else { studio.inputStatus = "Image is too large (25 MB maximum)"; return false }
            pastedImage = NSImage(data: data)
        }
        if copiedFileURLs.isEmpty, pastedImage == nil {
            pastedImage = pasteboard.readObjects(forClasses: [NSImage.self], options: [:])?.first as? NSImage
        }
        guard let image = pastedImage,
              let source = image.cgImage(forProposedRect: nil, context: nil, hints: nil),
              Int64(source.width) * Int64(source.height) <= 32_000_000,
              let tiff = image.tiffRepresentation,
              let bitmap = NSBitmapImageRep(data: tiff),
              let png = bitmap.representation(using: .png, properties: [:]) else {
            NSSound.beep(); studio.inputStatus = pastedImage == nil ? "Clipboard does not contain an image" : "Image is invalid or exceeds 32 megapixels"; return false
        }
        guard png.count <= 25_000_000 else { studio.inputStatus = "Image is too large (25 MB maximum)"; return false }
        let images = studio.board.boardImages
        guard images.count < 100, images.reduce(0, { $0 + $1.png.count }) + png.count <= 100_000_000 else {
            studio.inputStatus = "Board image limit reached (100 images / 100 MB)"; return false
        }
        var size = image.size
        let maxWidth = min(900, studio.board.size.width), maxHeight = min(700, studio.board.size.height)
        let scale = min(1, min(maxWidth / max(size.width, 1), maxHeight / max(size.height, 1)))
        size = CGSize(width: max(1, size.width * scale), height: max(1, size.height * scale))
        let visible = enclosingScrollView?.documentVisibleRect ?? bounds
        let middle = center ?? CGPoint(x: visible.midX, y: visible.midY)
        let x = min(max(0, studio.board.size.width-size.width), max(0, middle.x-size.width/2))
        let y = min(max(0, studio.board.size.height-size.height), max(0, middle.y-size.height/2))
        let item = BoardImage(png: png, x: x, y: y, width: size.width, height: size.height)
        studio.board.images = studio.board.boardImages + [item]
        studio.undoHistory.append(.addImage(item)); studio.redoHistory.removeAll()
        studio.select(.select); selectedImageID = item.id
        studio.inputStatus = "Image added · drag to move, corner handle to resize"
        needsDisplay = true
        studio.changed(invalidate: false)
        return true
    }
    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { Self.holdsImage(sender.draggingPasteboard) ? .copy : [] }
    override func prepareForDragOperation(_ sender: NSDraggingInfo) -> Bool { Self.holdsImage(sender.draggingPasteboard) }
    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let point = convert(sender.draggingLocation, from: nil)
        let added = insertImage(from: sender.draggingPasteboard, centeredAt: point)
        if added { window?.makeKeyAndOrderFront(nil); window?.makeFirstResponder(self) }
        return added
    }
    func beginImageInteraction(at point: CGPoint) {
        if let selected = selectedImage, resizeHandle(for: selected.rect).insetBy(dx: -6, dy: -6).contains(point) {
            imageStartRect = selected.rect; imageStartPoint = point; resizingImage = true; return
        }
        selectedImageID = studio.board.boardImages.reversed().first(where: { $0.rect.contains(point) })?.id
        imageStartRect = selectedImage?.rect; imageStartPoint = point; resizingImage = false; needsDisplay = true
    }
    func dragImage(to point: CGPoint) {
        guard let id = selectedImageID, let start = imageStartRect, let origin = imageStartPoint else { return }
        var rect = start
        if resizingImage {
            let ratio = start.width / max(start.height, 1)
            let maximumWidth = max(1, min(studio.board.size.width-start.minX, (studio.board.size.height-start.minY)*ratio))
            let proposedWidth = max(point.x-start.minX, (point.y-start.minY)*ratio)
            let width = min(maximumWidth, max(min(40, maximumWidth), proposedWidth))
            rect.size = CGSize(width: width, height: width/ratio)
        } else {
            rect.origin.x += point.x-origin.x; rect.origin.y += point.y-origin.y
        }
        rect.origin.x = min(max(0, studio.board.size.width-rect.width), max(0, rect.origin.x))
        rect.origin.y = min(max(0, studio.board.size.height-rect.height), max(0, rect.origin.y))
        studio.updateImage(id, rect: rect); needsDisplay = true
    }
    func finishImageInteraction() {
        defer { imageStartRect = nil; imageStartPoint = nil; resizingImage = false }
        guard let id = selectedImageID, let before = imageStartRect, let after = selectedImage?.rect, before != after else { return }
        studio.undoHistory.append(.moveImage(id: id, before: before, after: after)); studio.redoHistory.removeAll(); needsDisplay = true; studio.changed(invalidate: false)
    }
    var selectedImage: BoardImage? { studio.board.boardImages.first { $0.id == selectedImageID } }
    func resizeHandle(for rect: CGRect) -> CGRect { CGRect(x: rect.maxX-6, y: rect.maxY-6, width: 12, height: 12) }
    func drawSelection(in ctx: CGContext) {
        guard studio.tool == .select, let rect = selectedImage?.rect else { return }
        let accent = NSColor(calibratedRed: 0.086, green: 0.773, blue: 0.812, alpha: 1).cgColor
        ctx.saveGState(); ctx.setStrokeColor(accent); ctx.setLineWidth(2); ctx.setLineDash(phase: 0, lengths: [7, 4]); ctx.stroke(rect.insetBy(dx: -2, dy: -2))
        ctx.setLineDash(phase: 0, lengths: []); ctx.setFillColor(NSColor.white.cgColor); ctx.fill(resizeHandle(for: rect)); ctx.setStrokeColor(accent); ctx.stroke(resizeHandle(for: rect)); ctx.restoreGState()
    }
    func deleteSelection() {
        guard let id = selectedImageID, let index = studio.board.boardImages.firstIndex(where: { $0.id == id }) else { return }
        let item = studio.board.boardImages[index]
        studio.board.images?.removeAll { $0.id == id }; studio.undoHistory.append(.removeImage(item, index: index)); studio.redoHistory.removeAll(); selectedImageID = nil; needsDisplay = true; studio.changed(invalidate: false)
    }
    func nudgeSelection(dx: Double, dy: Double) -> Bool {
        guard studio.tool == .select, let id = selectedImage?.id else { return false }
        if studio.nudgeImage(id, dx: dx, dy: dy) { needsDisplay = true }
        return true
    }

    // MARK: Keyboard
    override func keyDown(with event: NSEvent) {
        let step: Double = event.modifierFlags.contains(.shift) ? 10 : 1
        switch event.keyCode {
        case 51, 117: deleteSelection()
        case 53: selectedImageID = nil; needsDisplay = true
        case 49:
            if !spacePan { commit(); spacePan = true; refreshCursor(); NSCursor.openHand.set() }
        case 123: if !nudgeSelection(dx: -step, dy: 0) { super.keyDown(with: event) }
        case 124: if !nudgeSelection(dx: step, dy: 0) { super.keyDown(with: event) }
        case 125: if !nudgeSelection(dx: 0, dy: step) { super.keyDown(with: event) }
        case 126: if !nudgeSelection(dx: 0, dy: -step) { super.keyDown(with: event) }
        default:
            switch event.charactersIgnoringModifiers {
            case "[": studio.stepWidth(-1)
            case "]": studio.stepWidth(1)
            default: super.keyDown(with: event)
            }
        }
    }
    override func keyUp(with event: NSEvent) {
        guard event.keyCode == 49 else { super.keyUp(with: event); return }
        spacePan = false; endPan(); refreshCursor(); currentCursor().set()
    }

    // MARK: Cursor
    func currentCursor() -> NSCursor {
        if spacePan || studio.tool == .pan { return panStartPoint == nil ? .openHand : .closedHand }
        switch studio.tool {
        case .select: return .arrow
        case .eraser: return Self.ringCursor(diameter: max(20, studio.width) * studio.zoom)
        default: return .crosshair
        }
    }
    /// Shows the eraser at its real on-screen size.
    static func ringCursor(diameter: CGFloat) -> NSCursor {
        let d = min(160, max(8, diameter)), size = NSSize(width: d + 4, height: d + 4)
        let image = NSImage(size: size, flipped: false) { rect in
            let ring = NSBezierPath(ovalIn: rect.insetBy(dx: 2, dy: 2))
            ring.lineWidth = 2.5; NSColor.black.withAlphaComponent(0.55).setStroke(); ring.stroke()
            ring.lineWidth = 1; NSColor.white.setStroke(); ring.stroke()
            return true
        }
        return NSCursor(image: image, hotSpot: NSPoint(x: size.width/2, y: size.height/2))
    }
    func refreshCursor() {
        cursorKey = "\(studio.tool)-\(spacePan)-\(Int(studio.width))-\(Int(studio.zoom * 100))"
        window?.invalidateCursorRects(for: self)
    }
    override func resetCursorRects() { addCursorRect(bounds, cursor: currentCursor()) }
}

/// Keeps a board that is smaller than the window centered instead of pinned to a corner.
final class CenteringClipView: NSClipView {
    override func constrainBoundsRect(_ proposedBounds: NSRect) -> NSRect {
        var rect = super.constrainBoundsRect(proposedBounds)
        guard let document = documentView else { return rect }
        if rect.width > document.frame.width { rect.origin.x = (document.frame.width - rect.width) / 2 }
        if rect.height > document.frame.height { rect.origin.y = (document.frame.height - rect.height) / 2 }
        return rect
    }
}

struct BoardView: NSViewRepresentable {
    @ObservedObject var studio: Studio
    final class Coordinator {
        var magnifying = false
        var tokens: [NSObjectProtocol] = []
        deinit { tokens.forEach { NotificationCenter.default.removeObserver($0) } }
    }
    func makeCoordinator() -> Coordinator { Coordinator() }
    static func surroundColor(dark: Bool) -> NSColor { dark ? NSColor(calibratedWhite: 0.09, alpha: 1) : NSColor(calibratedWhite: 0.86, alpha: 1) }
    func makeNSView(context: Context) -> NSScrollView {
        let scroll = NSScrollView()
        scroll.contentView = CenteringClipView()
        scroll.hasVerticalScroller = true; scroll.hasHorizontalScroller = true
        scroll.scrollerStyle = .overlay; scroll.autohidesScrollers = true
        scroll.borderType = .noBorder; scroll.drawsBackground = false
        scroll.horizontalScrollElasticity = .none; scroll.verticalScrollElasticity = .none
        scroll.contentView.drawsBackground = true
        // Pinch to zoom on a trackpad.
        scroll.allowsMagnification = true; scroll.minMagnification = Studio.minZoom; scroll.maxMagnification = Studio.maxZoom
        scroll.documentView = Canvas(studio: studio)
        scroll.contentView.backgroundColor = Self.surroundColor(dark: studio.board.isDark)
        scroll.horizontalScroller?.knobStyle = studio.board.isDark ? .light : .dark
        scroll.verticalScroller?.knobStyle = studio.board.isDark ? .light : .dark
        let center = NotificationCenter.default, coordinator = context.coordinator, model = studio
        coordinator.tokens = [
            center.addObserver(forName: NSScrollView.willStartLiveMagnifyNotification, object: scroll, queue: .main) { [weak coordinator] _ in coordinator?.magnifying = true },
            center.addObserver(forName: NSScrollView.didEndLiveMagnifyNotification, object: scroll, queue: .main) { [weak coordinator, weak scroll, weak model] _ in
                coordinator?.magnifying = false
                guard let scroll, let model else { return }
                model.zoom = scroll.magnification
                (scroll.documentView as? Canvas)?.invalidateInk()
                (scroll.documentView as? Canvas)?.refreshCursor()
            }
        ]
        return scroll
    }
    func updateNSView(_ view: NSScrollView, context: Context) {
        view.contentView.backgroundColor = Self.surroundColor(dark: studio.board.isDark)
        view.horizontalScroller?.knobStyle = studio.board.isDark ? .light : .dark
        view.verticalScroller?.knobStyle = studio.board.isDark ? .light : .dark
        guard let canvas = view.documentView as? Canvas else { return }
        if canvas.frame.size != studio.board.size { canvas.resizeToBoard() }
        if !context.coordinator.magnifying, abs(view.magnification - studio.zoom) > 0.001 {
            let visible = view.documentVisibleRect
            view.setMagnification(studio.zoom, centeredAt: CGPoint(x: visible.midX, y: visible.midY))
            canvas.invalidateInk()
        }
        let key = "\(studio.tool)-\(canvas.spacePan)-\(Int(studio.width))-\(Int(studio.zoom * 100))"
        if key != canvas.cursorKey { canvas.refreshCursor() }
    }
}

// MARK: - Interface

enum Theme {
    static let accent = Color(red: 0.086, green: 0.773, blue: 0.812)
    static let header = Color(red: 0.035, green: 0.035, blue: 0.04)
    static let panel = Color(white: 0.085)
    static let statusBar = Color(white: 0.07)
}
struct ToolButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.opacity(configuration.isPressed ? 0.65 : 1)
            .contentShape(Rectangle())
    }
}
/// Rounded dark buttons for the header, sidebar and status bar.
struct ChromeButtonStyle: ButtonStyle {
    var prominent = false
    var active = false
    var compact = false
    func makeBody(configuration: Configuration) -> some View {
        ChromeButton(configuration: configuration, prominent: prominent, active: active, compact: compact)
    }
    struct ChromeButton: View {
        let configuration: ButtonStyleConfiguration
        let prominent: Bool
        let active: Bool
        let compact: Bool
        @Environment(\.isEnabled) private var isEnabled
        @State private var hovering = false
        var fill: Color {
            if prominent { return Color.white.opacity(configuration.isPressed ? 0.72 : hovering ? 0.88 : 1) }
            if active { return Theme.accent.opacity(configuration.isPressed ? 0.3 : 0.2) }
            return Color.white.opacity(configuration.isPressed ? 0.16 : hovering ? 0.1 : 0.055)
        }
        var body: some View {
            configuration.label
                .font(.system(size: compact ? 11 : 12, weight: prominent ? .semibold : .medium))
                .foregroundStyle(prominent ? Color.black : Color.white.opacity(0.92))
                .padding(.horizontal, compact ? 7 : 10)
                .frame(minHeight: compact ? 22 : 30)
                .background(RoundedRectangle(cornerRadius: compact ? 6 : 7).fill(fill))
                .overlay(RoundedRectangle(cornerRadius: compact ? 6 : 7).strokeBorder(active ? Theme.accent.opacity(0.75) : Color.white.opacity(prominent ? 0 : 0.09), lineWidth: 1))
                .opacity(isEnabled ? 1 : 0.35)
                .contentShape(Rectangle())
                .onHover { hovering = $0 }
        }
    }
}
struct SharedIcon: View {
    let name: String
    var body: some View {
        let packaged = Bundle.main.resourceURL.flatMap { Bundle(url: $0.appendingPathComponent("Slate_Slate.bundle")) }
        Image(name, bundle: packaged ?? .module).resizable().scaledToFit()
    }
}
struct BrandMark: View {
    var body: some View {
        HStack(spacing: 11) {
            SharedIcon(name: "Brand").frame(width: 34, height: 34)
            Text("problem-slate")
                .font(.system(size: 19, weight: .bold, design: .monospaced))
                .tracking(0.2)
                .foregroundStyle(.white)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("problem-slate")
    }
}
struct SectionHeader: View {
    let title: String
    init(_ title: String) { self.title = title }
    var body: some View {
        Text(title).font(.system(size: 10, weight: .semibold, design: .monospaced)).tracking(0.8)
            .foregroundStyle(.secondary).padding(.top, 14).padding(.bottom, 2)
    }
}
struct SwitchRow: View {
    let title: String
    @Binding var isOn: Bool
    var body: some View {
        HStack {
            Text(title).font(.system(size: 12))
            Spacer()
            Toggle(title, isOn: $isOn).labelsHidden().toggleStyle(.switch).controlSize(.mini)
        }
    }
}
struct KeyCap: View {
    let label: String
    var body: some View {
        Text(label).font(.system(size: 10, weight: .medium, design: .monospaced)).foregroundStyle(.secondary)
            .padding(.horizontal, 5).padding(.vertical, 1)
            .background(RoundedRectangle(cornerRadius: 4).fill(Color.white.opacity(0.08)))
    }
}
struct TipRow: View {
    let key: String
    let text: String
    var body: some View {
        HStack(spacing: 7) { KeyCap(label: key); Text(text).font(.system(size: 11)).foregroundStyle(.secondary) }
    }
}
/// A live sample stroke drawn with the real renderer and the current tool settings.
struct BrushPreview: View {
    @ObservedObject var studio: Studio
    var previewInk: Ink {
        let tool: Tool = [.select, .pan].contains(studio.tool) ? .pen : studio.tool
        let varies = studio.pressure && (tool == .pen || tool == .chisel)
        let samples = (0...48).map { i -> Sample in
            let t = Double(i) / 48
            return Sample(x: 22 + t * 152, y: 29 - sin(t * .pi * 2) * 9, pressure: varies ? 0.25 + 0.75 * sin(t * .pi) : 1)
        }
        return Ink(tool: tool, color: [0, 0, 0, 1], width: min(studio.width, 30), angle: studio.angle, samples: samples)
    }
    var body: some View {
        let dark = studio.board.isDark
        ZStack {
            RoundedRectangle(cornerRadius: 8).fill(dark ? Color.black : Color.white)
            if studio.tool == .eraser {
                let diameter = min(46, max(20, studio.width))
                Circle().stroke(dark ? Color.white : Color.black, style: StrokeStyle(lineWidth: 1.2, dash: [4, 3])).frame(width: diameter, height: diameter)
            } else {
                Path(Renderer.makePath(previewInk)).fill(studio.displayedColor(studio.color))
                    .opacity(previewInk.tool == .highlighter ? 0.28 : 1)
            }
        }
        .frame(width: 196, height: 58)
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(Color.white.opacity(0.1)))
        .accessibilityHidden(true)
    }
}
struct ContentView: View {
    @ObservedObject var studio: Studio
    static let palette: [(name: String, hex: UInt32)] = [("Black", 0x000000), ("Gray", 0x8e8e93), ("Blue", 0x0095ff), ("Purple", 0xd32ee8), ("Red", 0xff404a), ("Orange", 0xff952b), ("Yellow", 0xffdb00), ("Green", 0x28cd53)]
    static func color(_ hex: UInt32) -> Color { Color(red: Double((hex >> 16) & 255)/255, green: Double((hex >> 8) & 255)/255, blue: Double(hex & 255)/255) }
    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            HStack(spacing: 0) {
                sidebar.frame(width: 224).background(Theme.panel)
                Divider()
                BoardView(studio: studio)
            }
            Divider()
            statusBar
        }
        .frame(minWidth: 1000, minHeight: 660)
        .background(Color(nsColor: .windowBackgroundColor))
        .preferredColorScheme(.dark)
        .tint(Theme.accent)
    }
    var header: some View {
        HStack(spacing: 8) {
            BrandMark()
            Divider().frame(height: 22).padding(.horizontal, 8)
            if studio.isDirty { Circle().fill(Theme.accent).frame(width: 7, height: 7).help("Unsaved changes") }
            Text(studio.name).font(.system(size: 12, weight: .medium)).foregroundStyle(.white.opacity(0.62)).lineLimit(1).truncationMode(.middle)
            Spacer(minLength: 12)
            Button { studio.undo() } label: { SharedIcon(name: "Undo").frame(width: 15, height: 15) }
                .buttonStyle(ChromeButtonStyle()).disabled(studio.undoHistory.isEmpty).help("Undo (⌘Z)")
            Button { studio.redo() } label: { SharedIcon(name: "Redo").frame(width: 15, height: 15) }
                .buttonStyle(ChromeButtonStyle()).disabled(studio.redoHistory.isEmpty).help("Redo (⇧⌘Z)")
            Divider().frame(height: 22).padding(.horizontal, 4)
            Button { studio.newBoard() } label: { Label("New", systemImage: "doc.badge.plus") }.buttonStyle(ChromeButtonStyle()).help("New board (⌘N)")
            Button { studio.open() } label: { Label("Open", systemImage: "folder") }.buttonStyle(ChromeButtonStyle()).help("Open a .slate board (⌘O)")
            Button { studio.save() } label: { Label("Save", systemImage: "square.and.arrow.down") }.buttonStyle(ChromeButtonStyle()).help("Save (⌘S) · Save As (⇧⌘S)")
            Button { studio.copyImage() } label: { Label("Copy", systemImage: "doc.on.doc") }.buttonStyle(ChromeButtonStyle()).help("Copy the whole board as an image (⇧⌘C)")
            Button { studio.export() } label: { Label("Export PNG", systemImage: "square.and.arrow.up") }.buttonStyle(ChromeButtonStyle(prominent: true)).help("Export the whole board (⇧⌘E)")
        }
        .labelStyle(.titleAndIcon)
        .padding(.horizontal, 16).padding(.vertical, 10)
        .foregroundStyle(.white)
        .background(Theme.header)
    }
    var sidebar: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: 6) {
                SectionHeader("TOOLS")
                ForEach(Tool.allCases, id: \.self) { tool in toolRow(tool) }
                SectionHeader("COLOR")
                LazyVGrid(columns: Array(repeating: GridItem(.fixed(42), spacing: 6), count: 4), alignment: .leading, spacing: 4) {
                    ForEach(Array(Self.palette.enumerated()), id: \.offset) { index, entry in swatchButton(index: index, name: entry.name, color: Self.color(entry.hex)) }
                }
                ColorPicker("Custom color", selection: Binding(get: { studio.color }, set: { studio.choose(color: $0, swatch: nil) }), supportsOpacity: false)
                    .font(.system(size: 12))
                SectionHeader("BRUSH")
                BrushPreview(studio: studio).padding(.bottom, 4)
                HStack { Text("Size"); Spacer(); Text("\(Int(studio.width)) px").monospacedDigit().foregroundStyle(.secondary) }.font(.system(size: 12))
                Slider(value: $studio.width, in: 1...60, step: 1).controlSize(.small).help("Brush size ([ and ] keys)")
                HStack(spacing: 5) {
                    ForEach([2, 4, 8, 16, 32], id: \.self) { size in
                        Button("\(size)") { studio.width = Double(size); studio.canvas?.refreshCursor() }
                            .buttonStyle(ChromeButtonStyle(active: Int(studio.width) == size, compact: true))
                            .frame(maxWidth: .infinity)
                    }
                }
                if studio.tool == .chisel || studio.tool == .highlighter {
                    HStack { Text("Nib angle"); Spacer(); Text("\(Int(studio.angle))°").monospacedDigit().foregroundStyle(.secondary) }.font(.system(size: 12)).padding(.top, 4)
                    Slider(value: $studio.angle, in: 0...180, step: 1).controlSize(.small)
                }
                SwitchRow(title: "Pen pressure", isOn: $studio.pressure).padding(.top, 4)
                SectionHeader("BOARD")
                SwitchRow(title: "Black background", isOn: Binding(get: { studio.board.isDark }, set: { studio.setDark($0) }))
                SwitchRow(title: "Dot grid", isOn: Binding(get: { studio.board.grid }, set: { studio.setGrid($0) }))
                Button { studio.chooseCanvasSize() } label: {
                    Label("\(Int(studio.board.size.width)) × \(Int(studio.board.size.height))", systemImage: "aspectratio").frame(maxWidth: .infinity)
                }.buttonStyle(ChromeButtonStyle()).help("Change canvas size").padding(.top, 4)
                Button { studio.clearBoard() } label: {
                    HStack { SharedIcon(name: "Clear").frame(width: 15, height: 15); Text("Clear board") }.frame(maxWidth: .infinity)
                }.buttonStyle(ChromeButtonStyle()).disabled(studio.board.isEmpty).help("Erase everything (⇧⌘K). Undo with ⌘Z.")
                VStack(alignment: .leading, spacing: 5) {
                    TipRow(key: "⇧", text: "+ draw: straight line")
                    TipRow(key: "Space", text: "+ drag: pan")
                    TipRow(key: "[ ]", text: "brush size")
                    TipRow(key: "⌘V", text: "or drop: add image")
                    TipRow(key: "Pinch", text: "or ⌘-scroll: zoom")
                }
                .padding(10).frame(maxWidth: .infinity, alignment: .leading)
                .background(RoundedRectangle(cornerRadius: 8).fill(Color.white.opacity(0.035)))
                .padding(.top, 12)
            }.padding(.horizontal, 14).padding(.bottom, 16)
        }
    }
    func toolRow(_ tool: Tool) -> some View {
        let selected = studio.tool == tool
        return Button { studio.select(tool) } label: {
            HStack(spacing: 9) {
                SharedIcon(name: tool.rawValue).frame(width: 16, height: 16)
                Text(tool.rawValue).font(.system(size: 12, weight: .semibold))
                Spacer(minLength: 4)
                KeyCap(label: String(tool.key.character).uppercased())
            }
            .padding(.horizontal, 10).frame(maxWidth: .infinity, minHeight: 34)
            .background(RoundedRectangle(cornerRadius: 8).fill(selected ? Theme.accent.opacity(0.18) : Color.white.opacity(0.04)))
            .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(selected ? Theme.accent.opacity(0.7) : Color.white.opacity(0.08), lineWidth: 1))
            .contentShape(Rectangle())
        }
        .buttonStyle(ToolButtonStyle()).keyboardShortcut(tool.key, modifiers: [])
        .help(tool.help)
        .accessibilityLabel(tool.rawValue)
        .accessibilityValue(selected ? "Selected" : "")
    }
    func swatchButton(index: Int, name: String, color: Color) -> some View {
        Button { studio.choose(color: color, swatch: index) } label: {
            ZStack {
                Circle().strokeBorder(Theme.accent, lineWidth: 2).frame(width: 30, height: 30).opacity(studio.swatch == index ? 1 : 0)
                Circle().fill(studio.displayedColor(color)).frame(width: 22, height: 22)
                    .overlay(Circle().strokeBorder(Color.gray.opacity(0.45), lineWidth: 1))
            }.frame(width: 42, height: 34).contentShape(Rectangle())
        }
        .buttonStyle(.plain).help(name)
        .accessibilityLabel(name).accessibilityValue(studio.swatch == index ? "Selected" : "")
    }
    var statusBar: some View {
        HStack(spacing: 8) {
            Circle().fill(studio.inputStatus.hasPrefix("Tablet") ? Color.green : Color.gray).frame(width: 6, height: 6)
            Text(studio.inputStatus).font(.caption)
            Text(studio.tool.hint).font(.caption).foregroundStyle(.secondary).lineLimit(1).padding(.leading, 12)
            Spacer(minLength: 8)
            Text("\(Int(studio.board.size.width)) × \(Int(studio.board.size.height))").font(.caption.monospacedDigit()).foregroundStyle(.secondary).padding(.trailing, 6)
            Button("Fit") { studio.zoomToFit() }.buttonStyle(ChromeButtonStyle(compact: true)).help("Zoom to fit (⌘9)")
            Button { studio.zoomOut() } label: { Image(systemName: "minus") }.buttonStyle(ChromeButtonStyle(compact: true)).help("Zoom out (⌘−)")
            Button("\(Int((studio.zoom * 100).rounded()))%") { studio.setZoom(1) }.buttonStyle(ChromeButtonStyle(compact: true)).frame(minWidth: 52).help("Actual size (⌘0)")
            Button { studio.zoomIn() } label: { Image(systemName: "plus") }.buttonStyle(ChromeButtonStyle(compact: true)).help("Zoom in (⌘=)")
        }
        .padding(.horizontal, 14).padding(.vertical, 6)
        .background(Theme.statusBar)
    }
}
final class AppDelegate: NSObject, NSApplicationDelegate {
    var studio: Studio?
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply { studio?.canvas?.commit(); studio?.flush(); return .terminateNow }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}
@main struct SlateApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject var studio = Studio()
    var body: some Scene {
        Window("problem-slate", id: "main") {
            ContentView(studio: studio).onAppear { delegate.studio = studio }
        }.defaultSize(width: 1280, height: 840)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("New Board") { studio.newBoard() }.keyboardShortcut("n")
                Button("Open…") { studio.open() }.keyboardShortcut("o")
            }
            CommandGroup(replacing: .saveItem) {
                Button("Save") { studio.save() }.keyboardShortcut("s")
                Button("Save As…") { studio.save(asCopy: true) }.keyboardShortcut("s", modifiers: [.command, .shift])
                Button("Export PNG…") { studio.export() }.keyboardShortcut("e", modifiers: [.command, .shift])
            }
            CommandMenu("Board") {
                Button("Paste Image") { studio.pasteImage() }.keyboardShortcut("v", modifiers: .command)
                Button("Copy Board as Image") { studio.copyImage() }.keyboardShortcut("c", modifiers: [.command, .shift])
                // Delete/Backspace is handled by the board itself, so typing in text fields is never intercepted.
                Button("Delete Selected Image  ⌫") { studio.deleteSelection() }
                Divider()
                Button("Clear Board") { studio.clearBoard() }.keyboardShortcut("k", modifiers: [.command, .shift]).disabled(studio.board.isEmpty)
                Toggle("Black Background", isOn: Binding(get: { studio.board.isDark }, set: { studio.setDark($0) }))
                Toggle("Dot Grid", isOn: Binding(get: { studio.board.grid }, set: { studio.setGrid($0) }))
                Button("Canvas Size…") { studio.chooseCanvasSize() }
            }
            CommandGroup(after: .toolbar) {
                Button("Zoom In") { studio.zoomIn() }.keyboardShortcut("=", modifiers: .command)
                Button("Zoom Out") { studio.zoomOut() }.keyboardShortcut("-", modifiers: .command)
                Button("Actual Size") { studio.setZoom(1) }.keyboardShortcut("0", modifiers: .command)
                Button("Zoom to Fit") { studio.zoomToFit() }.keyboardShortcut("9", modifiers: .command)
                Divider()
            }
            CommandGroup(replacing: .undoRedo) {
                Button("Undo") { studio.undo() }.keyboardShortcut("z").disabled(studio.undoHistory.isEmpty)
                Button("Redo") { studio.redo() }.keyboardShortcut("z", modifiers: [.command, .shift]).disabled(studio.redoHistory.isEmpty)
            }
        }
    }
}
