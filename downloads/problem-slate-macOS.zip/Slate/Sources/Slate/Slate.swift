import SwiftUI
import AppKit
import UniformTypeIdentifiers

enum Tool: String, Codable, CaseIterable {
    case select = "Select", pan = "Pan", pen = "Pen", chisel = "Chisel", highlighter = "Highlighter", eraser = "Eraser"
    var icon: String { switch self { case .select: return "arrow.up.left.and.arrow.down.right"; case .pan: return "hand.draw"; case .pen: return "pencil.tip"; case .chisel: return "paintbrush.pointed"; case .highlighter: return "highlighter"; case .eraser: return "eraser" } }
    var key: KeyEquivalent { switch self { case .select: return "v"; case .pan: return "m"; case .pen: return "p"; case .chisel: return "c"; case .highlighter: return "h"; case .eraser: return "e" } }
}
struct Sample: Codable { var x: Double; var y: Double; var pressure: Double }
struct Ink: Codable { var tool: Tool; var color: [Double]; var width: Double; var angle: Double; var samples: [Sample] }
struct BoardImage: Codable, Identifiable {
    var id = UUID()
    var png: Data
    var x: Double
    var y: Double
    var width: Double
    var height: Double
    var rect: CGRect { CGRect(x: x, y: y, width: width, height: height) }
}
struct Board: Codable {
    var version = 1
    var strokes: [Ink] = []
    var grid = true
    // Optional for backward-compatible decoding of version 1 boards.
    var dark: Bool? = nil
    // Optional so boards saved by Slate 1.0/1.1 continue to open.
    var images: [BoardImage]? = nil
    // Missing dimensions identify boards created before adjustable canvases.
    var canvasWidth: Double? = nil
    var canvasHeight: Double? = nil
    var isDark: Bool { dark ?? false }
    var boardImages: [BoardImage] { images ?? [] }
    var size: CGSize { CGSize(width: canvasWidth ?? 2400, height: canvasHeight ?? 1600) }
    static var blank: Board {
        var board = Board(); board.canvasWidth = 4096; board.canvasHeight = 4096
        return board
    }
}
enum Edit {
    case stroke(Ink)
    case clear(strokes: [Ink], images: [BoardImage])
    case addImage(BoardImage)
    case removeImage(BoardImage, index: Int)
    case moveImage(id: UUID, before: CGRect, after: CGRect)
    case resizeCanvas(before: CGSize, after: CGSize)
    case dark(before: Bool, after: Bool)
    case grid(before: Bool, after: Bool)
}

final class Studio: ObservableObject {
    @Published var tool: Tool = .pen
    @Published var color: Color = .black
    @Published var width: Double = 4
    @Published var angle: Double = 40
    @Published var pressure = true
    @Published var board = Board.blank
    @Published var undoHistory: [Edit] = []
    @Published var redoHistory: [Edit] = []
    @Published var inputStatus = "Mouse / trackpad · tablet ready"
    @Published var name = "Untitled board"
    @Published var isDirty = false
    @Published var zoom: CGFloat = 1
    var url: URL?
    weak var canvas: Canvas?
    var pendingSave: DispatchWorkItem?
    let saveQueue = DispatchQueue(label: "app.madhup.slate.recovery", qos: .utility)
    let recovery: URL
    init(recoveryURL: URL? = nil) {
        let base = recoveryURL?.deletingLastPathComponent() ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Slate", isDirectory: true)
        recovery = recoveryURL ?? base.appendingPathComponent("Recovery.slate")
        do {
            try FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: recovery.path) {
                board = try Self.loadBoard(from: recovery)
                undoHistory = board.strokes.map { .stroke($0) }
                isDirty = true
            }
        } catch { inputStatus = "Recovery unavailable: \(error.localizedDescription)" }
    }
    static let maximumBoardBytes = 160_000_000
    static func loadBoard(from url: URL) throws -> Board {
        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size <= maximumBoardBytes else {
            throw NSError(domain: "Slate", code: 2, userInfo: [NSLocalizedDescriptionKey: "This board is larger than the 160 MB limit."])
        }
        return try decode(Data(contentsOf: url))
    }
    static func encode(_ board: Board) throws -> Data {
        let data = try JSONEncoder().encode(board)
        guard data.count <= maximumBoardBytes else {
            throw NSError(domain: "Slate", code: 3, userInfo: [NSLocalizedDescriptionKey: "This board is larger than the 160 MB limit."])
        }
        return data
    }
    static func validImageData(_ data: Data) -> Bool {
        guard let image = NSImage(data: data), let source = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return false }
        return Int64(source.width) * Int64(source.height) <= 32_000_000
    }
    static func decode(_ data: Data) throws -> Board {
        let value = try JSONDecoder().decode(Board.self, from: data)
        guard value.version == 1, value.strokes.allSatisfy({ s in
            s.color.count == 4 && s.color.allSatisfy { $0.isFinite && (0...1).contains($0) } && s.width.isFinite && (0.5...100).contains(s.width) && s.angle.isFinite && s.samples.allSatisfy { $0.x.isFinite && $0.y.isFinite && $0.pressure.isFinite && (0...1).contains($0.pressure) }
        }), (512...8192).contains(value.size.width), (512...8192).contains(value.size.height),
              value.boardImages.count <= 100, value.boardImages.reduce(0, { $0 + $1.png.count }) <= 100_000_000,
              value.boardImages.allSatisfy({ image in
                  image.png.count <= 25_000_000 && image.x.isFinite && image.y.isFinite && image.width.isFinite && image.height.isFinite && image.width > 0 && image.height > 0 && image.width <= 8192 && image.height <= 8192 && validImageData(image.png)
              }) else { throw NSError(domain: "Slate", code: 1, userInfo: [NSLocalizedDescriptionKey: "This board has an unsupported format or invalid drawing data."]) }
        return value
    }
    func changed(invalidate: Bool = true, markDirty: Bool = true) {
        if markDirty { isDirty = true }
        if invalidate { canvas?.invalidateInk() }
        pendingSave?.cancel()
        let snapshot = board
        let path = recovery
        let work = DispatchWorkItem { [weak self] in
            do { try Self.encode(snapshot).write(to: path, options: .atomic) }
            catch { DispatchQueue.main.async { self?.inputStatus = "Autosave failed — use Save" } }
        }
        pendingSave = work
        saveQueue.asyncAfter(deadline: .now() + 0.4, execute: work)
    }
    func flush() {
        pendingSave?.cancel()
        do { try saveQueue.sync { try Self.encode(board).write(to: recovery, options: .atomic) } } catch { show(error) }
    }
    func finish(_ ink: Ink) {
        board.strokes.append(ink); undoHistory.append(.stroke(ink)); redoHistory.removeAll()
        canvas?.cacheFinished(ink)
        changed(invalidate: false)
    }
    func undo() {
        canvas?.commit()
        guard let edit = undoHistory.popLast() else { return }
        switch edit {
        case .stroke: if !board.strokes.isEmpty { board.strokes.removeLast() }
        case .clear(let strokes, let images): board.strokes = strokes; board.images = images
        case .addImage(let image): board.images?.removeAll { $0.id == image.id }
        case .removeImage(let image, let index):
            var images = board.boardImages
            images.insert(image, at: min(index, images.count))
            board.images = images
        case .moveImage(let id, let before, _): updateImage(id, rect: before)
        case .resizeCanvas(let before, _): applyCanvasSize(before)
        case .dark(let before, _): board.dark = before
        case .grid(let before, _): board.grid = before
        }
        if let selected = canvas?.selectedImageID, !board.boardImages.contains(where: { $0.id == selected }) { canvas?.selectedImageID = nil }
        redoHistory.append(edit); changed()
    }
    func redo() {
        canvas?.commit()
        guard let edit = redoHistory.popLast() else { return }
        switch edit {
        case .stroke(let ink): board.strokes.append(ink)
        case .clear: board.strokes.removeAll(); board.images = []
        case .addImage(let image): board.images = board.boardImages + [image]
        case .removeImage(let image, _): board.images?.removeAll { $0.id == image.id }
        case .moveImage(let id, _, let after): updateImage(id, rect: after)
        case .resizeCanvas(_, let after): applyCanvasSize(after)
        case .dark(_, let after): board.dark = after
        case .grid(_, let after): board.grid = after
        }
        if let selected = canvas?.selectedImageID, !board.boardImages.contains(where: { $0.id == selected }) { canvas?.selectedImageID = nil }
        undoHistory.append(edit); changed()
    }
    func clearBoard() {
        canvas?.commit()
        guard !board.strokes.isEmpty || !board.boardImages.isEmpty else { return }
        undoHistory.append(.clear(strokes: board.strokes, images: board.boardImages)); redoHistory.removeAll()
        board.strokes.removeAll(); board.images = []; canvas?.selectedImageID = nil; changed()
    }
    func updateImage(_ id: UUID, rect: CGRect) {
        guard let index = board.images?.firstIndex(where: { $0.id == id }) else { return }
        board.images![index].x = rect.minX; board.images![index].y = rect.minY
        board.images![index].width = rect.width; board.images![index].height = rect.height
    }
    func pasteImage() { canvas?.pasteImage() }
    func deleteSelection() { canvas?.deleteSelection() }
    func applyCanvasSize(_ size: CGSize) {
        board.canvasWidth = size.width; board.canvasHeight = size.height
        canvas?.resizeToBoard()
    }
    func chooseCanvasSize() {
        canvas?.commit()
        let alert = NSAlert(); alert.messageText = "Canvas size"
        alert.informativeText = "Choose a width and height from 512 to 8192 pixels. Content outside a smaller canvas stays saved but will be hidden."
        let widthField = NSTextField(string: String(Int(board.size.width)))
        let heightField = NSTextField(string: String(Int(board.size.height)))
        widthField.alignment = .right; heightField.alignment = .right
        let row = NSStackView(views: [NSTextField(labelWithString: "Width"), widthField, NSTextField(labelWithString: "Height"), heightField])
        row.spacing = 8; row.frame = NSRect(x: 0, y: 0, width: 310, height: 26)
        alert.accessoryView = row; alert.addButton(withTitle: "Resize"); alert.addButton(withTitle: "Cancel")
        guard alert.runModal() == .alertFirstButtonReturn,
              let width = Double(widthField.stringValue), let height = Double(heightField.stringValue),
              (512...8192).contains(width), (512...8192).contains(height) else { return }
        let before = board.size, after = CGSize(width: width.rounded(), height: height.rounded())
        guard before != after else { return }
        applyCanvasSize(after); undoHistory.append(.resizeCanvas(before: before, after: after)); redoHistory.removeAll(); changed()
    }
    func setDark(_ dark: Bool) {
        canvas?.commit()
        let before = board.isDark
        guard before != dark else { return }
        board.dark = dark; undoHistory.append(.dark(before: before, after: dark)); redoHistory.removeAll(); changed()
    }
    func setGrid(_ grid: Bool) {
        canvas?.commit()
        let before = board.grid
        guard before != grid else { return }
        board.grid = grid; undoHistory.append(.grid(before: before, after: grid)); redoHistory.removeAll(); changed()
    }
    func displayedColor(_ color: Color) -> Color {
        let rgb = NSColor(color).usingColorSpace(.deviceRGB) ?? .black
        return board.isDark && Renderer.isBlack([rgb.redComponent, rgb.greenComponent, rgb.blueComponent]) ? .white : color
    }
    func show(_ error: Error) { NSAlert(error: error).runModal() }
    @discardableResult func save(asCopy: Bool = false) -> Bool {
        canvas?.commit()
        var target = url
        if target == nil || asCopy {
            let panel = NSSavePanel(); panel.nameFieldStringValue = name + ".slate"
            panel.allowedContentTypes = [UTType(filenameExtension: "slate") ?? .data]
            guard panel.runModal() == .OK else { return false }; target = panel.url
        }
        guard let target else { return false }
        do {
            let data = try Self.encode(board)
            try data.write(to: target, options: .atomic)
            url = target; name = target.deletingPathExtension().lastPathComponent; isDirty = false
            return true
        } catch { show(error); return false }
    }
    func confirmReplace() -> Bool {
        guard isDirty else { return true }
        let alert = NSAlert(); alert.messageText = "Save this board before continuing?"
        alert.informativeText = "Your latest changes have not been saved to a named .slate file."
        alert.addButton(withTitle: "Save"); alert.addButton(withTitle: "Discard"); alert.addButton(withTitle: "Cancel")
        switch alert.runModal() {
        case .alertFirstButtonReturn: return save()
        case .alertSecondButtonReturn: return true
        default: return false
        }
    }
    func newBoard() {
        canvas?.commit(); guard confirmReplace() else { return }
        board = Board.blank; undoHistory = []; redoHistory = []; url = nil; name = "Untitled board"; isDirty = false; zoom = 1
        canvas?.selectedImageID = nil; canvas?.resizeToBoard(); changed(markDirty: false)
    }
    func open() {
        canvas?.commit()
        let panel = NSOpenPanel(); panel.allowedContentTypes = [UTType(filenameExtension: "slate") ?? .data]; panel.allowsMultipleSelection = false
        guard panel.runModal() == .OK, let target = panel.url else { return }
        do {
            let incoming = try Self.loadBoard(from: target)
            guard confirmReplace() else { return }
            board = incoming; undoHistory = incoming.strokes.map { .stroke($0) }; redoHistory = []; url = target; name = target.deletingPathExtension().lastPathComponent; isDirty = false
            canvas?.selectedImageID = nil; canvas?.resizeToBoard(); changed(markDirty: false)
        } catch { show(error) }
    }
    func export() {
        canvas?.commit()
        let panel = NSSavePanel(); panel.allowedContentTypes = [.png]; panel.nameFieldStringValue = name + ".png"
        guard panel.runModal() == .OK, let target = panel.url else { return }
        let exportWidth = Int(board.size.width), exportHeight = Int(board.size.height)
        guard let ctx = CGContext(data: nil, width: exportWidth, height: exportHeight, bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
        ctx.translateBy(x: 0, y: CGFloat(exportHeight)); ctx.scaleBy(x: 1, y: -1)
        Renderer.board(board, active: nil, in: ctx)
        guard let image = ctx.makeImage(), let data = NSBitmapImageRep(cgImage: image).representation(using: .png, properties: [:]) else { return }
        do { try data.write(to: target, options: .atomic) } catch { show(error) }
    }
}

enum Renderer {
    static func paper(_ board: Board, in ctx: CGContext, rect: CGRect? = nil) {
        ctx.saveGState()
        let canvas = CGRect(origin: .zero, size: board.size)
        let area = (rect ?? canvas).intersection(canvas)
        guard !area.isNull && !area.isEmpty else { ctx.restoreGState(); return }
        ctx.setFillColor((board.isDark ? NSColor.black : NSColor.white).cgColor); ctx.fill(area)
        if board.grid {
            ctx.setFillColor(NSColor(calibratedWhite: board.isDark ? 0.4 : 0, alpha: 1).cgColor)
            let startX = max(12, Int((area.minX - 12) / 24) * 24 + 12), endX = min(Int(board.size.width), Int(area.maxX) + 24)
            let startY = max(12, Int((area.minY - 12) / 24) * 24 + 12), endY = min(Int(board.size.height), Int(area.maxY) + 24)
            for x in stride(from: startX, to: endX, by: 24) { for y in stride(from: startY, to: endY, by: 24) { ctx.fillEllipse(in: CGRect(x: CGFloat(x), y: CGFloat(y), width: 1.5, height: 1.5)) } }
        }
        ctx.restoreGState()
    }
    static func board(_ board: Board, active: Ink?, in ctx: CGContext) {
        paper(board, in: ctx)
        images(board.boardImages, in: ctx)
        ctx.saveGState(); ctx.beginTransparencyLayer(auxiliaryInfo: nil)
        for ink in board.strokes { stroke(ink, dark: board.isDark, in: ctx) }
        if let active { stroke(active, dark: board.isDark, in: ctx) }
        ctx.endTransparencyLayer(); ctx.restoreGState()
    }
    static func images(_ images: [BoardImage], in ctx: CGContext) {
        for item in images {
            guard let source = NSImage(data: item.png), let cg = source.cgImage(forProposedRect: nil, context: nil, hints: nil) else { continue }
            ctx.saveGState()
            ctx.translateBy(x: item.x, y: item.y + item.height)
            ctx.scaleBy(x: 1, y: -1)
            ctx.interpolationQuality = .high
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: item.width, height: item.height))
            ctx.restoreGState()
        }
    }
    static func isBlack(_ color: [Double]) -> Bool {
        guard color.count >= 3 else { return false }
        let black = color.prefix(3).allSatisfy { abs($0) < 0.00001 }
        // The original app's default black was this exact blue-black swatch.
        let legacy = abs(color[0]-0.12) < 0.002 && abs(color[1]-0.16) < 0.002 && abs(color[2]-0.23) < 0.002
        return black || legacy
    }
    static func stroke(_ ink: Ink, dark: Bool, in ctx: CGContext, path: CGPath? = nil) {
        let shape = path ?? makePath(ink)
        ctx.saveGState()
        ctx.setBlendMode(ink.tool == .eraser ? .clear : .normal)
        ctx.setAlpha(ink.tool == .highlighter ? 0.28 : 1)
        let c = dark && isBlack(ink.color) ? [1.0, 1.0, 1.0] : ink.color
        ctx.setFillColor(CGColor(red: c[0], green: c[1], blue: c[2], alpha: 1))
        ctx.addPath(shape); ctx.fillPath(); ctx.restoreGState()
    }
    static func makePath(_ ink: Ink) -> CGPath {
        let path = CGMutablePath()
        guard let first = ink.samples.first else { return path }
        stamp(first, ink: ink, into: path)
        for (a, b) in zip(ink.samples, ink.samples.dropFirst()) { segment(a, b, ink: ink, into: path) }
        return path
    }
    static func stamp(_ s: Sample, ink: Ink, into path: CGMutablePath) {
        let w = ink.width * (ink.tool == .highlighter || ink.tool == .eraser ? 1 : 0.25 + 0.75 * s.pressure)
        if ink.tool == .chisel || ink.tool == .highlighter {
            let h = w * (ink.tool == .chisel ? 0.22 : 0.48)
            let transform = CGAffineTransform(translationX: s.x, y: s.y).rotated(by: ink.angle * .pi / 180)
            path.addRect(CGRect(x: -w/2, y: -h/2, width: w, height: h), transform: transform)
        } else { path.addEllipse(in: CGRect(x: s.x-w/2, y: s.y-w/2, width: w, height: w)) }
    }
    static func segment(_ a: Sample, _ b: Sample, ink: Ink, into path: CGMutablePath) {
        let distance = hypot(b.x-a.x, b.y-a.y)
        let steps = max(1, Int(ceil(distance / max(0.4, ink.width * 0.025))))
        for i in 1...steps {
            let t = Double(i)/Double(steps)
            stamp(Sample(x: a.x+(b.x-a.x)*t, y: a.y+(b.y-a.y)*t, pressure: a.pressure+(b.pressure-a.pressure)*t), ink: ink, into: path)
        }
    }
}

// Online midpoint-quadratic smoothing: no timer or app-focus-dependent state.
struct StrokeSmoother {
    var previous: Sample
    var anchor: Sample
    init(_ first: Sample) { previous = first; anchor = first }
    mutating func add(_ raw: Sample) -> [Sample] {
        let filtered = Sample(x: raw.x, y: raw.y, pressure: previous.pressure * 0.65 + raw.pressure * 0.35)
        let end = Sample(x: (previous.x+filtered.x)/2, y: (previous.y+filtered.y)/2, pressure: (previous.pressure+filtered.pressure)/2)
        let length = hypot(previous.x-anchor.x, previous.y-anchor.y) + hypot(end.x-previous.x, end.y-previous.y)
        let count = max(1, Int(ceil(length / 2)))
        let result = (1...count).map { i -> Sample in
            let t = Double(i)/Double(count), u = 1-t
            return Sample(x: u*u*anchor.x+2*u*t*previous.x+t*t*end.x,
                          y: u*u*anchor.y+2*u*t*previous.y+t*t*end.y,
                          pressure: anchor.pressure+(end.pressure-anchor.pressure)*t)
        }
        previous = filtered; anchor = end
        return result
    }
}

final class Canvas: NSView {
    let studio: Studio
    var active: Ink?
    var activePath = CGMutablePath()
    var smoother: StrokeSmoother?
    var inkLayer: CGLayer?
    var penNear = false
    var eraserEnd = false
    var monitor: Any?
    var observers: [NSObjectProtocol] = []
    var lastTimestamp: TimeInterval = -1
    var lastStatusTime: TimeInterval = -1
    var selectedImageID: UUID?
    var imageStartRect: CGRect?
    var imageStartPoint: CGPoint?
    var resizingImage = false
    var panStartPoint: CGPoint?
    var panStartOrigin: CGPoint?
    override var isFlipped: Bool { true }
    override var acceptsFirstResponder: Bool { true }
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
    init(studio: Studio) {
        self.studio = studio; super.init(frame: CGRect(origin: .zero, size: studio.board.size)); studio.canvas = self
        monitor = NSEvent.addLocalMonitorForEvents(matching: [.tabletProximity]) { [weak self] event in self?.proximity(event); return event }
        let center = NotificationCenter.default
        observers.append(center.addObserver(forName: NSApplication.willResignActiveNotification, object: nil, queue: .main) { [weak self] _ in self?.resetInput() })
        observers.append(center.addObserver(forName: NSWindow.didResignKeyNotification, object: nil, queue: .main) { [weak self] note in
            guard let self, let window = note.object as? NSWindow, window === self.window else { return }
            self.resetInput()
        })
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    deinit {
        if let monitor { NSEvent.removeMonitor(monitor) }
        for observer in observers { NotificationCenter.default.removeObserver(observer) }
    }
    override func viewDidChangeBackingProperties() { super.viewDidChangeBackingProperties(); invalidateInk() }
    func resizeToBoard() {
        setFrameSize(studio.board.size); invalidateInk()
        enclosingScrollView?.contentView.scroll(to: .zero)
        if let scroll = enclosingScrollView { scroll.reflectScrolledClipView(scroll.contentView) }
    }
    func resetInput() {
        commit(); penNear = false; eraserEnd = false; lastTimestamp = -1; lastStatusTime = -1
        studio.inputStatus = "Mouse / trackpad · tablet ready"
    }
    func proximity(_ event: NSEvent) {
        penNear = event.isEnteringProximity
        eraserEnd = penNear && event.pointingDeviceType == .eraser
        studio.inputStatus = penNear ? (eraserEnd ? "Tablet eraser detected" : "Tablet pen detected · pressure ready") : "Mouse / trackpad · tablet ready"
    }
    override func tabletProximity(with event: NSEvent) { proximity(event) }
    func sample(_ event: NSEvent) -> Sample {
        let location = event.window == nil ? (window?.convertPoint(fromScreen: event.locationInWindow) ?? event.locationInWindow) : event.locationInWindow
        let p = convert(location, from: nil)
        let tablet = event.type == .tabletPoint || event.subtype == .tabletPoint
        if tablet && event.timestamp-lastStatusTime > 0.2 {
            studio.inputStatus = "Tablet pen · pressure \(Int(event.pressure * 100))%"
            lastStatusTime = event.timestamp
        }
        let force = tablet && studio.pressure ? max(0.01, min(1, Double(event.pressure))) : 1
        return Sample(x: min(studio.board.size.width, max(0, p.x)), y: min(studio.board.size.height, max(0, p.y)), pressure: force)
    }
    override func mouseDown(with event: NSEvent) {
        commit(); window?.makeFirstResponder(self)
        if studio.tool == .select {
            beginImageInteraction(at: convert(event.locationInWindow, from: nil))
            return
        }
        if studio.tool == .pan {
            panStartPoint = event.locationInWindow
            panStartOrigin = enclosingScrollView?.contentView.bounds.origin
            NSCursor.closedHand.set()
            return
        }
        // A fresh stroke always starts with fresh timing and smoothing state.
        lastTimestamp = event.timestamp; lastStatusTime = -1
        if event.subtype != .tabletPoint { eraserEnd = false }
        let color = NSColor(studio.color).usingColorSpace(.deviceRGB) ?? .black
        let tool = eraserEnd ? Tool.eraser : studio.tool
        let first = sample(event)
        let ink = Ink(tool: tool, color: [color.redComponent, color.greenComponent, color.blueComponent, 1], width: tool == .eraser ? max(20, studio.width) : studio.width, angle: studio.angle, samples: [first])
        active = ink; activePath = CGMutablePath(); smoother = StrokeSmoother(first)
        Renderer.stamp(first, ink: ink, into: activePath)
        setNeedsDisplay(CGRect(x: first.x, y: first.y, width: 1, height: 1).insetBy(dx: -ink.width-4, dy: -ink.width-4))
    }
    override func mouseDragged(with event: NSEvent) {
        if studio.tool == .select { dragImage(to: convert(event.locationInWindow, from: nil)); return }
        if studio.tool == .pan { pan(to: event.locationInWindow); return }
        append(event)
    }
    override func mouseUp(with event: NSEvent) {
        if studio.tool == .select { finishImageInteraction(); return }
        if studio.tool == .pan { panStartPoint = nil; panStartOrigin = nil; NSCursor.openHand.set(); return }
        append(event, lifting: true); commit()
    }
    override func tabletPoint(with event: NSEvent) { if active != nil && event.pressure > 0 { append(event) } }
    func append(_ event: NSEvent, lifting: Bool = false) {
        guard active != nil, event.timestamp > lastTimestamp else { return }
        lastTimestamp = event.timestamp
        var s = sample(event)
        // Lift-off events often report zero pressure; do not punch a thin notch into the endpoint.
        if lifting { s.pressure = smoother?.previous.pressure ?? s.pressure }
        if let last = smoother?.previous, hypot(last.x-s.x, last.y-s.y) < 0.15 { return }
        let points = smoother?.add(s) ?? [s]
        for point in points { addPoint(point) }
        if let first = points.first, let last = points.last, let ink = active {
            let area = CGRect(x: min(first.x,last.x), y: min(first.y,last.y), width: abs(last.x-first.x)+1, height: abs(last.y-first.y)+1)
            setNeedsDisplay(area.insetBy(dx: -ink.width-4, dy: -ink.width-4))
        }
    }
    func addPoint(_ point: Sample) {
        guard let last = active?.samples.last else { return }
        Renderer.segment(last, point, ink: active!, into: activePath)
        active?.samples.append(point)
    }
    func commit() {
        guard active != nil else { return }
        if let endpoint = smoother?.previous { addPoint(endpoint) }
        if let ink = active {
            let xs = ink.samples.map(\.x), ys = ink.samples.map(\.y)
            if let minX = xs.min(), let maxX = xs.max(), let minY = ys.min(), let maxY = ys.max() {
                setNeedsDisplay(CGRect(x: minX, y: minY, width: maxX-minX+1, height: maxY-minY+1).insetBy(dx: -ink.width-4, dy: -ink.width-4))
            }
            active = nil; smoother = nil; studio.finish(ink)
        }
        activePath = CGMutablePath()
    }
    func invalidateInk() { inkLayer = nil; needsDisplay = true }
    func cacheFinished(_ ink: Ink) {
        // Append only the new stroke. Existing geometry is never rebuilt during pen movement.
        if let ctx = inkLayer?.context { Renderer.stroke(ink, dark: studio.board.isDark, in: ctx, path: activePath) }
    }
    override func draw(_ dirtyRect: NSRect) {
        guard let ctx = NSGraphicsContext.current?.cgContext else { return }
        if inkLayer == nil, let layer = CGLayer(ctx, size: studio.board.size, auxiliaryInfo: nil), let cache = layer.context {
            for ink in studio.board.strokes { Renderer.stroke(ink, dark: studio.board.isDark, in: cache) }
            inkLayer = layer
        }
        Renderer.paper(studio.board, in: ctx, rect: dirtyRect)
        Renderer.images(studio.board.boardImages, in: ctx)
        ctx.saveGState(); ctx.beginTransparencyLayer(auxiliaryInfo: nil)
        if let inkLayer { ctx.draw(inkLayer, at: .zero) }
        else { for ink in studio.board.strokes { Renderer.stroke(ink, dark: studio.board.isDark, in: ctx) } }
        if let active { Renderer.stroke(active, dark: studio.board.isDark, in: ctx, path: activePath) }
        ctx.endTransparencyLayer(); ctx.restoreGState()
        drawSelection(in: ctx)
    }
    func pasteImage() {
        commit()
        let pasteboard = NSPasteboard.general
        var pastedImage: NSImage?
        // Finder exposes a copied file both as a file URL and as its generic icon.
        // Resolve the actual image file before asking AppKit for an NSImage object.
        let urlOptions: [NSPasteboard.ReadingOptionKey: Any] = [.urlReadingFileURLsOnly: true]
        let copiedFileURLs = (pasteboard.readObjects(forClasses: [NSURL.self], options: urlOptions) as? [NSURL])?.map { $0 as URL } ?? []
        if let url = copiedFileURLs.first(where: { url in
               guard let type = UTType(filenameExtension: url.pathExtension) else { return false }
               return type.conforms(to: .image)
           }) {
            let byteCount = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
            guard byteCount <= 25_000_000 else { studio.inputStatus = "Image is too large (25 MB maximum)"; return }
            pastedImage = NSImage(contentsOf: url)
        }
        // Screenshots, browser images and pixel selections usually provide PNG/TIFF bytes.
        if copiedFileURLs.isEmpty, pastedImage == nil, let data = pasteboard.data(forType: .png) ?? pasteboard.data(forType: .tiff) {
            guard data.count <= 25_000_000 else { studio.inputStatus = "Image is too large (25 MB maximum)"; return }
            pastedImage = NSImage(data: data)
        }
        if copiedFileURLs.isEmpty, pastedImage == nil {
            pastedImage = pasteboard.readObjects(forClasses: [NSImage.self], options: [:])?.first as? NSImage
        }
        guard let image = pastedImage,
              let source = image.cgImage(forProposedRect: nil, context: nil, hints: nil),
              Int64(source.width) * Int64(source.height) <= 32_000_000,
              let tiff = image.tiffRepresentation,
              let bitmap = NSBitmapImageRep(data: tiff),
              let png = bitmap.representation(using: .png, properties: [:]) else {
            NSSound.beep(); studio.inputStatus = pastedImage == nil ? "Clipboard does not contain an image" : "Image is invalid or exceeds 32 megapixels"; return
        }
        guard png.count <= 25_000_000 else { studio.inputStatus = "Image is too large (25 MB maximum)"; return }
        let images = studio.board.boardImages
        guard images.count < 100, images.reduce(0, { $0 + $1.png.count }) + png.count <= 100_000_000 else {
            studio.inputStatus = "Board image limit reached (100 images / 100 MB)"; return
        }
        var size = image.size
        let maxWidth = min(900, studio.board.size.width), maxHeight = min(700, studio.board.size.height)
        let scale = min(1, min(maxWidth / max(size.width, 1), maxHeight / max(size.height, 1)))
        size = CGSize(width: max(1, size.width * scale), height: max(1, size.height * scale))
        let visible = enclosingScrollView?.documentVisibleRect ?? bounds
        let x = min(max(0, studio.board.size.width-size.width), max(0, visible.midX-size.width/2))
        let y = min(max(0, studio.board.size.height-size.height), max(0, visible.midY-size.height/2))
        let item = BoardImage(png: png, x: x, y: y, width: size.width, height: size.height)
        studio.board.images = studio.board.boardImages + [item]
        studio.undoHistory.append(.addImage(item)); studio.redoHistory.removeAll()
        selectedImageID = item.id; studio.tool = .select
        studio.inputStatus = "Image pasted · drag to move, corner handle to resize"
        needsDisplay = true
        studio.changed(invalidate: false)
    }
    func beginImageInteraction(at point: CGPoint) {
        if let selected = selectedImage, resizeHandle(for: selected.rect).insetBy(dx: -6, dy: -6).contains(point) {
            imageStartRect = selected.rect; imageStartPoint = point; resizingImage = true; return
        }
        selectedImageID = studio.board.boardImages.reversed().first(where: { $0.rect.contains(point) })?.id
        imageStartRect = selectedImage?.rect; imageStartPoint = point; resizingImage = false; needsDisplay = true
    }
    func dragImage(to point: CGPoint) {
        guard let id = selectedImageID, let start = imageStartRect, let origin = imageStartPoint else { return }
        var rect = start
        if resizingImage {
            let ratio = start.width / max(start.height, 1)
            let maximumWidth = max(1, min(studio.board.size.width-start.minX, (studio.board.size.height-start.minY)*ratio))
            let proposedWidth = max(point.x-start.minX, (point.y-start.minY)*ratio)
            let width = min(maximumWidth, max(min(40, maximumWidth), proposedWidth))
            rect.size = CGSize(width: width, height: width/ratio)
        } else {
            rect.origin.x += point.x-origin.x; rect.origin.y += point.y-origin.y
        }
        rect.origin.x = min(max(0, studio.board.size.width-rect.width), max(0, rect.origin.x))
        rect.origin.y = min(max(0, studio.board.size.height-rect.height), max(0, rect.origin.y))
        studio.updateImage(id, rect: rect); needsDisplay = true
    }
    func finishImageInteraction() {
        defer { imageStartRect = nil; imageStartPoint = nil; resizingImage = false }
        guard let id = selectedImageID, let before = imageStartRect, let after = selectedImage?.rect, before != after else { return }
        studio.undoHistory.append(.moveImage(id: id, before: before, after: after)); studio.redoHistory.removeAll(); needsDisplay = true; studio.changed(invalidate: false)
    }
    var selectedImage: BoardImage? { studio.board.boardImages.first { $0.id == selectedImageID } }
    func resizeHandle(for rect: CGRect) -> CGRect { CGRect(x: rect.maxX-6, y: rect.maxY-6, width: 12, height: 12) }
    func drawSelection(in ctx: CGContext) {
        guard studio.tool == .select, let rect = selectedImage?.rect else { return }
        ctx.saveGState(); ctx.setStrokeColor(NSColor.systemTeal.cgColor); ctx.setLineWidth(2); ctx.setLineDash(phase: 0, lengths: [7, 4]); ctx.stroke(rect.insetBy(dx: -2, dy: -2))
        ctx.setLineDash(phase: 0, lengths: []); ctx.setFillColor(NSColor.white.cgColor); ctx.fill(resizeHandle(for: rect)); ctx.setStrokeColor(NSColor.systemTeal.cgColor); ctx.stroke(resizeHandle(for: rect)); ctx.restoreGState()
    }
    func deleteSelection() {
        guard let id = selectedImageID, let index = studio.board.boardImages.firstIndex(where: { $0.id == id }) else { return }
        let item = studio.board.boardImages[index]
        studio.board.images?.removeAll { $0.id == id }; studio.undoHistory.append(.removeImage(item, index: index)); studio.redoHistory.removeAll(); selectedImageID = nil; needsDisplay = true; studio.changed(invalidate: false)
    }
    override func keyDown(with event: NSEvent) {
        if event.keyCode == 51 || event.keyCode == 117 { deleteSelection() } else { super.keyDown(with: event) }
    }
    func pan(to point: CGPoint) {
        guard let scroll = enclosingScrollView, let start = panStartPoint, let origin = panStartOrigin else { return }
        let scale = max(scroll.magnification, 0.01)
        var bounds = scroll.contentView.bounds
        bounds.origin = CGPoint(x: origin.x-(point.x-start.x)/scale, y: origin.y+(point.y-start.y)/scale)
        scroll.contentView.scroll(to: scroll.contentView.constrainBoundsRect(bounds).origin)
        scroll.reflectScrolledClipView(scroll.contentView)
    }
    override func resetCursorRects() {
        addCursorRect(bounds, cursor: studio.tool == .pan ? .openHand : .crosshair)
    }
}
struct BoardView: NSViewRepresentable {
    @ObservedObject var studio: Studio
    func makeNSView(context: Context) -> NSScrollView {
        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true; scroll.hasHorizontalScroller = true
        scroll.scrollerStyle = .overlay; scroll.autohidesScrollers = true
        scroll.borderType = .noBorder; scroll.drawsBackground = false
        scroll.horizontalScrollElasticity = .none; scroll.verticalScrollElasticity = .none
        scroll.contentView.drawsBackground = true
        scroll.allowsMagnification = false; scroll.minMagnification = 0.25; scroll.maxMagnification = 3
        scroll.documentView = Canvas(studio: studio)
        scroll.contentView.backgroundColor = studio.board.isDark ? .black : NSColor(calibratedWhite: 0.92, alpha: 1)
        scroll.horizontalScroller?.knobStyle = studio.board.isDark ? .light : .dark
        scroll.verticalScroller?.knobStyle = studio.board.isDark ? .light : .dark
        return scroll
    }
    func updateNSView(_ view: NSScrollView, context: Context) {
        view.contentView.backgroundColor = studio.board.isDark ? .black : NSColor(calibratedWhite: 0.92, alpha: 1)
        view.horizontalScroller?.knobStyle = studio.board.isDark ? .light : .dark
        view.verticalScroller?.knobStyle = studio.board.isDark ? .light : .dark
        if view.documentView?.frame.size != studio.board.size { (view.documentView as? Canvas)?.resizeToBoard() }
        if abs(view.magnification - studio.zoom) > 0.001 { view.magnification = studio.zoom; (view.documentView as? Canvas)?.invalidateInk() }
    }
}
struct ToolButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.opacity(configuration.isPressed ? 0.65 : 1)
            .contentShape(Rectangle())
    }
}
struct SharedIcon: View {
    let name: String
    var body: some View {
        let packaged = Bundle.main.resourceURL.flatMap { Bundle(url: $0.appendingPathComponent("Slate_Slate.bundle")) }
        Image(name, bundle: packaged ?? .module).resizable().scaledToFit()
    }
}
struct BrandMark: View {
    var body: some View {
        HStack(spacing: 12) {
            SharedIcon(name: "Brand").frame(width: 42, height: 42)
            Text("problem-slate")
                .font(.system(size: 22, weight: .bold, design: .monospaced))
                .tracking(0.4)
                .foregroundStyle(.white)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("problem-slate")
    }
}
struct ContentView: View {
    @ObservedObject var studio: Studio
    let palette: [Color] = [0x000000, 0x0095ff, 0xd32ee8, 0xff404a, 0xff952b, 0xffdb00, 0x28cd53].map { hex in Color(red: Double((hex >> 16) & 255)/255, green: Double((hex >> 8) & 255)/255, blue: Double(hex & 255)/255) }
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                BrandMark()
                Text(studio.name + (studio.isDirty ? " *" : "")).font(.caption).foregroundStyle(.white.opacity(0.62)).padding(.leading, 6)
                Spacer()
                Button { studio.undo() } label: { SharedIcon(name: "Undo").frame(width: 18, height: 18) }.buttonStyle(.bordered).disabled(studio.undoHistory.isEmpty).help("Undo (⌘Z)")
                Button { studio.redo() } label: { SharedIcon(name: "Redo").frame(width: 18, height: 18) }.buttonStyle(.bordered).disabled(studio.redoHistory.isEmpty).help("Redo (⇧⌘Z)")
                Divider().frame(height: 20)
                Button("Open") { studio.open() }.buttonStyle(.bordered)
                Button("Save") { studio.save() }.buttonStyle(.bordered)
                Button("Export PNG") { studio.export() }.buttonStyle(.borderedProminent).tint(.white).foregroundStyle(.black)
            }.padding(.horizontal, 18).padding(.vertical, 12).foregroundStyle(.white).background(Color(red: 0.035, green: 0.035, blue: 0.04))
            Divider()
            HStack(spacing: 0) {
                ScrollView(.vertical) {
                VStack(alignment: .leading, spacing: 12) {
                    Text("YOUR TOOLS").font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
                    ForEach(Tool.allCases, id: \.self) { tool in
                        Button {
                            studio.canvas?.commit()
                            studio.tool = tool
                            if let canvas = studio.canvas { canvas.window?.invalidateCursorRects(for: canvas) }
                            switch tool { case .select, .pan: break; case .pen: studio.width = 4; case .chisel: studio.width = 12; case .highlighter: studio.width = 28; case .eraser: studio.width = 36 }
                        } label: {
                            HStack(spacing: 8) {
                                SharedIcon(name: tool.rawValue).frame(width: 18, height: 18)
                                Text(tool.rawValue).font(.system(size: 12, weight: .semibold))
                                Spacer(minLength: 4)
                                if studio.tool == tool { Image(systemName: "checkmark.circle.fill").foregroundStyle(.teal) }
                                else { Text(String(tool.key.character).uppercased()).font(.caption2).foregroundStyle(.secondary) }
                            }
                            .padding(.horizontal, 10).frame(maxWidth: .infinity, minHeight: 38)
                            .background(studio.tool == tool ? Color.teal.opacity(0.18) : Color.primary.opacity(0.045), in: RoundedRectangle(cornerRadius: 8))
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(studio.tool == tool ? Color.teal.opacity(0.6) : Color.primary.opacity(0.1), lineWidth: 1))
                            .contentShape(Rectangle())
                        }.buttonStyle(ToolButtonStyle()).keyboardShortcut(tool.key, modifiers: [])
                         .accessibilityLabel(tool.rawValue)
                         .accessibilityValue(studio.tool == tool ? "Selected" : "")
                    }
                    Divider()
                    Text("INK COLOR").font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
                    LazyVGrid(columns: Array(repeating: GridItem(.fixed(28)), count: 4), spacing: 9) {
                        ForEach(Array(palette.enumerated()), id: \.offset) { _, color in
                            Button { studio.color = color } label: { Circle().fill(studio.displayedColor(color)).frame(width: 23, height: 23).overlay(Circle().strokeBorder(.gray.opacity(0.4), lineWidth: 1)).frame(width: 28, height: 30).contentShape(Rectangle()) }.buttonStyle(.plain)
                        }
                    }
                    ColorPicker("Custom", selection: $studio.color, supportsOpacity: false)
                    Divider()
                    HStack { Text("Size"); Spacer(); Text("\(Int(studio.width)) px").foregroundStyle(.secondary) }.font(.caption)
                    Slider(value: $studio.width, in: 1...60)
                    if studio.tool == .chisel || studio.tool == .highlighter {
                        Text("Nib angle · \(Int(studio.angle))°").font(.caption)
                        Slider(value: $studio.angle, in: 0...180)
                    }
                    Toggle("Pen pressure", isOn: $studio.pressure).font(.caption)
                    Toggle("Black background", isOn: Binding(get: { studio.board.isDark }, set: { studio.setDark($0) })).font(.caption)
                    Toggle("Dot grid", isOn: Binding(get: { studio.board.grid }, set: { studio.setGrid($0) })).font(.caption)
                    Button { studio.chooseCanvasSize() } label: {
                        Label("\(Int(studio.board.size.width)) × \(Int(studio.board.size.height))", systemImage: "rectangle.arrowtriangle.2.outward").frame(maxWidth: .infinity, minHeight: 30).contentShape(Rectangle())
                    }.buttonStyle(.bordered).font(.caption).help("Change canvas size")
                    Spacer()
                    Button { studio.clearBoard() } label: {
                        HStack { SharedIcon(name: "Clear").frame(width: 18, height: 18); Text("Clear board") }.frame(maxWidth: .infinity, minHeight: 32).contentShape(Rectangle())
                    }.buttonStyle(.bordered).disabled(studio.board.strokes.isEmpty && studio.board.boardImages.isEmpty).help("Erase everything. Undo with ⌘Z.")
                    Button("New board") { studio.newBoard() }.frame(maxWidth: .infinity)
                    Text("Room for your next idea.").font(.caption2).foregroundStyle(.secondary)
                }.padding(16)
                }.frame(width: 200)
                Divider()
                BoardView(studio: studio)
            }
            Divider()
            HStack {
                Circle().fill(studio.inputStatus.hasPrefix("Tablet") ? .green : .gray).frame(width: 6, height: 6)
                Text(studio.inputStatus).font(.caption)
                Spacer()
                Text("\(Int(studio.board.size.width)) × \(Int(studio.board.size.height)) · Pan with M").font(.caption).foregroundStyle(.secondary)
                Button("−") { studio.zoom = max(0.25, studio.zoom - 0.25) }
                Text("\(Int(studio.zoom * 100))%").font(.caption).frame(width: 38)
                Button("+") { studio.zoom = min(3, studio.zoom + 0.25) }
            }.padding(.horizontal, 16).padding(.vertical, 9)
        }.frame(minWidth: 950, minHeight: 650).background(Color(nsColor: .windowBackgroundColor)).preferredColorScheme(.dark)
    }
}
final class AppDelegate: NSObject, NSApplicationDelegate {
    var studio: Studio?
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply { studio?.canvas?.commit(); studio?.flush(); return .terminateNow }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}
@main struct SlateApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject var studio = Studio()
    var body: some Scene {
        Window("problem-slate", id: "main") {
            ContentView(studio: studio).onAppear { delegate.studio = studio }
        }.defaultSize(width: 1200, height: 820)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("New Board") { studio.newBoard() }.keyboardShortcut("n")
                Button("Open…") { studio.open() }.keyboardShortcut("o")
            }
            CommandGroup(replacing: .saveItem) {
                Button("Save") { studio.save() }.keyboardShortcut("s")
                Button("Save As…") { studio.save(asCopy: true) }.keyboardShortcut("s", modifiers: [.command, .shift])
                Button("Export PNG…") { studio.export() }.keyboardShortcut("e", modifiers: [.command, .shift])
            }
            CommandMenu("Board") {
                Button("Paste Image") { studio.pasteImage() }.keyboardShortcut("v", modifiers: .command)
                Button("Delete Selected Image") { studio.deleteSelection() }.keyboardShortcut(.delete, modifiers: [])
                Divider()
                Button("Clear Board") { studio.clearBoard() }.keyboardShortcut("k", modifiers: [.command, .shift]).disabled(studio.board.strokes.isEmpty && studio.board.boardImages.isEmpty)
                Toggle("Black Background", isOn: Binding(get: { studio.board.isDark }, set: { studio.setDark($0) }))
            }
            CommandGroup(replacing: .undoRedo) {
                Button("Undo") { studio.undo() }.keyboardShortcut("z").disabled(studio.undoHistory.isEmpty)
                Button("Redo") { studio.redo() }.keyboardShortcut("z", modifiers: [.command, .shift]).disabled(studio.redoHistory.isEmpty)
            }
        }
    }
}
